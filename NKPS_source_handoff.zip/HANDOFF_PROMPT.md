# Handoff prompt — Nanhe Kadam School fee-delete behavior and same-link deployment

You are maintaining an **existing** Nanhe Kadam Public School website and management system. Work from the supplied project source; do not rebuild it, replace its database, or create a second site.

## Existing production resources

- Existing Cloudflare Worker: `nanhe-kadam-school`
- Existing production URL: `https://nanhe-kadam-school.nanhe-kadam.workers.dev`
- Existing D1 database: `nanhe-kadam-db` (`542d8371-b578-450e-bdb9-dabbf3574631`)
- Project folder in the shared workspace: `/home/user/nanhe-kadam-school`
- The same `wrangler.toml` must continue to target this Worker and D1. A deploy should publish a new version to the **same URL**; do not delete the Worker or create a new Worker/database. Keep the ability to roll back to an earlier Worker version.

## What is happening with the fee total

The admin screenshot from the production `workers.dev` URL shows 0 total students, 0 active students, but ₹1,500 in pending fees. This is consistent with a due-fee row remaining for a student who has been soft-deleted. The exact production row has **not** been inspected, so verify before claiming which student/fee it is.

The local source already contains a dashboard safeguard in `src/routes-admin.js`: the pending-fee aggregate joins `fees` to `students` and includes only fees whose student has `deleted_at IS NULL`. The student DELETE route has now also been updated locally to atomically soft-delete the student and only that student's unpaid `due` fee rows, while revoking the parent session. Paid fee records/results remain for financial history. The admin removal confirmation/toast now describes this. The production screenshot is consistent with the old Worker version; the exact production fee row has not been inspected. These local changes have not yet been deployed.

The implementation is narrowly scoped:

- Keep the existing student soft-delete model; do not hard-delete the student.
- Soft-delete only that student's **unpaid `due` fee rows** using `fees.deleted_at`, in the same D1 batch as the student soft-delete.
- Preserve paid fee records and other history. Do not affect fees for any other student.
- Keep the dashboard join as defense-in-depth so legacy orphan due rows for previously deleted students cannot inflate the total.
- Regression tests now create a student with both a due and paid fee, remove the student, verify the amount/count fall to baseline, verify the due row is no longer active, verify paid history remains, and verify parent access is revoked.

## Do not perform a broad reset or cleanup

- **Do not reset/truncate/replace the production D1 database or wipe existing students, classes, enquiries, website content, users, or fees.** The owner's phrase about resetting the website is ambiguous; ask for explicit confirmation and scope before any whole-site/data reset. Treat “redeploy/reset the old deployment” as publishing a new Worker version, not resetting school data.
- Do not run a blanket command that sets `deleted_at` on every due fee for every soft-deleted student. It would hide fees across multiple students and alter financial history. If a one-time cleanup of an old row is specifically requested, first identify the exact student/fee, make a verified backup, and limit the change to that record after confirmation.
- Do not create or seed a demo child. The owner said no demo child is wanted.
- Do not change unrelated code, APIs, portal login flows, authentication, or page design. Preserve admin/parent/teacher behavior and the existing mobile/tablet layout and margin polish. Only make the targeted fee-removal behavior and necessary tests/UI wording changes.

## Deployment and verification

- A recent `npx wrangler whoami` in this workspace returned: **“You are not authenticated. Please run `wrangler login`.”** The confirmed blocker is missing Cloudflare authentication; do not claim that outbound networking is disabled unless separately tested.
- Do not request or print Cloudflare tokens, admin passwords, or Gemini keys in chat. Ask the owner to authenticate Wrangler in the correct project workspace, then verify with `npx wrangler whoami`.
- Before deploying, inspect `wrangler.toml` and pending D1 migration status. Do not recreate D1 or apply destructive migrations. Apply an existing additive migration only if it is required and explain why; back up before any production data mutation.
- Run the relevant local API and UI tests, reporting any authenticated tests that were skipped. Latest API suite: **76/76 passed**, including the authenticated fee-removal regression, against an isolated temporary local D1 database that was removed after testing. Latest UI suite: **45 passed, 0 failed**; mobile scrolling/reveal checks passed at 320, 360, 375, 390, 412, and 430 CSS px. Authenticated browser portal-flow tests were skipped without UI test credentials.
- Once authenticated, deploy with Wrangler to the existing Worker, then verify the same production URL and the admin overview when an authorized admin session is available. Do not claim production is fixed until the deployed version is verified.
- The workspace also contains the earlier mobile CSS polish; include it in the same existing-Worker deploy and do not revert it.

## Secret handling

Previously exposed Gemini/admin credentials should be rotated. Never put replacement secrets in this prompt, source files, ZIP archives, logs, or chat. Exclude `.data`, `.wrangler`, `node_modules`, `.env`, `.dev.vars`, credentials, and test artifacts from any source ZIP.
