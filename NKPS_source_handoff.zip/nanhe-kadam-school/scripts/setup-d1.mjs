// One-command Cloudflare D1 setup: creates the database (or finds it), writes the
// database_id into wrangler.toml, and applies migrations remotely.
// Usage: npm run db:create   (requires `npx wrangler login` first)
import { execSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';

const DB_NAME = 'nanhe-kadam-db';
const run = (cmd) => execSync(cmd, { stdio: ['ignore', 'pipe', 'pipe'], encoding: 'utf8' });

function findDatabaseId() {
  // Try create first
  try {
    const out = run(`npx wrangler d1 create ${DB_NAME}`);
    const m = out.match(/database_id\s*=\s*"([0-9a-f-]{36})"/i) || out.match(/"uuid"\s*:\s*"([0-9a-f-]{36})"/i);
    if (m) return m[1];
  } catch (e) {
    const msg = String(e.stdout || '') + String(e.stderr || '') + String(e.message || '');
    if (!/already exists|already in use/i.test(msg)) {
      console.error('Could not create the database. Are you logged in? Run: npx wrangler login');
      console.error(msg.slice(0, 800));
      process.exit(1);
    }
  }
  // Already exists → look it up
  try {
    const list = JSON.parse(run('npx wrangler d1 list --json'));
    const db = list.find((d) => d.name === DB_NAME);
    if (db) return db.uuid;
  } catch {}
  console.error(`Database "${DB_NAME}" seems to exist but its ID could not be read. Run 'npx wrangler d1 list' and paste the uuid into wrangler.toml manually.`);
  process.exit(1);
}

console.log(`→ Creating/locating D1 database "${DB_NAME}"…`);
const id = findDatabaseId();
console.log(`✓ Database ID: ${id}`);

const toml = readFileSync('wrangler.toml', 'utf8');
writeFileSync('wrangler.toml', toml.replace(/database_id\s*=\s*"[^"]*"/, `database_id = "${id}"`));
console.log('✓ wrangler.toml updated');

console.log('→ Applying migrations to the remote database…');
execSync(`npx wrangler d1 migrations apply ${DB_NAME} --remote`, { stdio: 'inherit' });
console.log('\n✅ Database ready. Next: npm run deploy');
console.log('   Then open https://<your-worker>.workers.dev/admin/ and create the owner account (one-time).');
