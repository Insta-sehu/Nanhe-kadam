// Browser UI tests: horizontal-overflow checks at required widths, portal login flows,
// console-error capture and screenshots. Usage: npm run test:ui (server on :8787)
import { chromium } from 'playwright';
import { mkdirSync } from 'node:fs';
import { execSync } from 'node:child_process';

const BASE = process.env.BASE_URL || 'http://127.0.0.1:8787';
const ADMIN_USER = process.env.ADMIN_USER, ADMIN_PASS = process.env.ADMIN_PASS;
mkdirSync('test-artifacts', { recursive: true });
if (/127\.0\.0\.1|localhost/.test(BASE)) {
  try { execSync('npx wrangler d1 execute nanhe-kadam-db --local --persist-to .data --command "DELETE FROM rate_limits;"', { stdio: 'ignore' }); } catch {}
}

const browser = await chromium.launch();
let passed = 0, failed = 0;
const report = [];
const ok = (name, extra = '') => { passed++; report.push(`✅ ${name}${extra ? ' — ' + extra : ''}`); };
const bad = (name, why) => { failed++; report.push(`❌ ${name} — ${why}`); };

async function newPage(width, height = 900) {
  const page = await browser.newPage({ viewport: { width, height } });
  page.errors = [];
  page.on('pageerror', (e) => page.errors.push(e.message));
  return page;
}
async function overflowCheck(page, label) {
  const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: window.innerWidth, bsw: document.body.scrollWidth }));
  if (m.sw <= m.iw + 1 && m.bsw <= m.iw + 1) ok(label, `scrollWidth ${m.sw} ≤ viewport ${m.iw}`);
  else bad(label, `horizontal overflow: scrollWidth ${m.sw} > viewport ${m.iw}`);
}
async function revealContainmentCheck(page, label) {
  const m = await page.evaluate(() => {
    document.body.classList.remove('low-motion'); // exercise the normal reveal path
    const elements = [...document.querySelectorAll('.reveal-l, .reveal-r')];
    const outside = elements.map((el) => {
      const r = el.getBoundingClientRect();
      return { className: el.className, left: +r.left.toFixed(1), right: +r.right.toFixed(1) };
    }).filter((r) => r.left < -1 || r.right > innerWidth + 1);
    return { viewport: innerWidth, checked: elements.length, outside };
  });
  m.outside.length === 0
    ? ok(label, `${m.checked} side reveals stay inside ${m.viewport}px viewport`)
    : bad(label, JSON.stringify(m.outside));
}
async function scrollMotionCheck(page, label) {
  const samples = await page.evaluate(async () => {
    document.body.classList.remove('low-motion');
    document.documentElement.style.scrollBehavior = 'auto';
    const sides = [...document.querySelectorAll('.reveal-l, .reveal-r')];
    sides.forEach((el) => el.classList.remove('in'));
    void document.body.offsetWidth;
    const stops = [...document.querySelectorAll('main > section'), document.querySelector('footer')].filter(Boolean);
    const out = [];
    for (const stop of stops) {
      const top = stop.getBoundingClientRect().top + scrollY - 96;
      window.scrollTo(0, Math.max(0, top));
      await new Promise((resolve) => setTimeout(resolve, 50));
      const outside = sides.map((el) => {
        const r = el.getBoundingClientRect();
        return { left: +r.left.toFixed(1), right: +r.right.toFixed(1), className: el.className };
      }).filter((r) => r.left < -1 || r.right > innerWidth + 1);
      const sample = {
        section: stop.id || stop.tagName.toLowerCase(), viewport: innerWidth, x: scrollX,
        documentWidth: document.documentElement.scrollWidth, bodyWidth: document.body.scrollWidth, outside,
      };
      if (stop.id === 'contact') {
        const card = document.querySelector('.contact-card').getBoundingClientRect();
        const form = document.querySelector('.form-card').getBoundingClientRect();
        sample.contact = { left: +card.left.toFixed(1), right: +card.right.toFixed(1), formLeft: +form.left.toFixed(1), formRight: +form.right.toFixed(1) };
      }
      out.push(sample);
    }
    window.scrollTo(0, 0);
    return out;
  });
  const failures = samples.filter((s) => s.x > 1 || s.documentWidth > s.viewport + 1 || s.bodyWidth > s.viewport + 1 || s.outside.length
    || (s.contact && (s.contact.left < 19 || s.contact.formLeft < 19 || s.contact.right > s.viewport - 19 || s.contact.formRight > s.viewport - 19)));
  failures.length === 0
    ? ok(label, `scrolled ${samples.length} sections at ${samples[0]?.viewport}px; no side drift or overflow`)
    : bad(label, JSON.stringify(failures));
}

// ---- 1. Public homepage at all required widths ----
for (const w of [320, 360, 375, 390, 412, 430, 768, 1024, 1440]) {
  const page = await newPage(w);
  await page.goto(BASE + '/', { waitUntil: 'networkidle' });
  await page.waitForTimeout(900);
  await overflowCheck(page, `Homepage @ ${w}px`);
  await revealContainmentCheck(page, `Side-reveal alignment @ ${w}px`);
  if (w <= 430) {
    await page.setViewportSize({ width: w, height: 803 });
    await scrollMotionCheck(page, `Mobile scrolling @ ${w}px`);
    await page.setViewportSize({ width: w, height: 900 });
  }
  if (w === 390) {
    await page.evaluate(() => {
      document.body.classList.remove('low-motion');
      document.documentElement.style.scrollBehavior = 'auto';
      const cards = [...document.querySelectorAll('#contact .reveal-l, #contact .reveal-r')];
      cards.forEach((el) => el.classList.remove('in'));
      void document.body.offsetWidth;
      window.scrollTo(0, document.querySelector('#contact').offsetTop);
      // Start both contact-card transitions at the same moment to test the moving state.
      cards.forEach((el) => el.classList.add('in'));
      void document.body.offsetWidth;
    });
    await page.waitForTimeout(70);
    const contactMotion = await page.evaluate(() => {
      const card = document.querySelector('.contact-card').getBoundingClientRect();
      const form = document.querySelector('.form-card').getBoundingClientRect();
      return {
        viewport: innerWidth, x: scrollX,
        documentWidth: document.documentElement.scrollWidth,
        bodyWidth: document.body.scrollWidth,
        cardLeft: +card.left.toFixed(1), cardRight: +card.right.toFixed(1),
        formLeft: +form.left.toFixed(1), formRight: +form.right.toFixed(1),
      };
    });
    const contactContained = contactMotion.x <= 1
      && contactMotion.documentWidth <= contactMotion.viewport + 1
      && contactMotion.bodyWidth <= contactMotion.viewport + 1
      && contactMotion.cardLeft >= 19 && contactMotion.formLeft >= 19
      && contactMotion.cardRight <= contactMotion.viewport - 19
      && contactMotion.formRight <= contactMotion.viewport - 19;
    contactContained
      ? ok('Contact cards stay in the 20px gutters during reveal', JSON.stringify(contactMotion))
      : bad('Contact reveal alignment', JSON.stringify(contactMotion));

    const gal = await page.evaluate(() => document.querySelectorAll('.gal-card').length);
    gal === 4 ? ok('Gallery shows exactly 4 featured photos', `${gal} cards`) : bad('Gallery count', `${gal} cards (expected 4)`);
    const contained = await page.evaluate(() => [...document.querySelectorAll('.gal-card')].every((c) => { const img = c.querySelector('img'); if (!img) return true; const a = img.getBoundingClientRect(), b = c.getBoundingClientRect(); return a.left >= b.left - 1 && a.right <= b.right + 1; }));
    contained ? ok('Gallery images stay inside their cards') : bad('Gallery image containment', 'image escapes card');
    await page.evaluate(() => document.getElementById('gallery').scrollIntoView());
    await page.waitForTimeout(1200);
    const loaded = await page.evaluate(() => [...document.querySelectorAll('.gal-card img')].every((i) => i.complete && i.naturalWidth > 0));
    loaded ? ok('All gallery images actually load (naturalWidth > 0)') : bad('Gallery image loading', 'broken image detected');
    await page.evaluate(() => window.scrollTo(0, 0));
    await page.waitForTimeout(400);
    await page.screenshot({ path: 'test-artifacts/home-mobile-390.png', fullPage: false });
    await page.evaluate(() => {
      const fab = document.getElementById('chat-fab');
      fab.hidden = false; // exercise the widget even when AI is disabled in local test data
      fab.click();
    });
    await page.waitForTimeout(320); // let the widget's entrance animation settle before measuring
    const chat = await page.evaluate(() => {
      const panel = document.getElementById('chat-panel');
      const r = panel.getBoundingClientRect();
      return { open: panel.classList.contains('open'), height: r.height, max: Math.min(420, innerHeight - 182), bottom: r.bottom, viewport: innerHeight };
    });
    chat.open && chat.height <= chat.max + 1 && chat.bottom <= chat.viewport - 80
      ? ok('Mobile chat panel stays compact and in viewport', `${Math.round(chat.height)}px tall`)
      : bad('Mobile chat panel sizing', JSON.stringify(chat));
  }
  if (w === 1440) {
    await page.screenshot({ path: 'test-artifacts/home-desktop-1440.png', fullPage: false });
    await page.evaluate(() => document.getElementById('gallery').scrollIntoView());
    await page.waitForTimeout(900);
    await page.screenshot({ path: 'test-artifacts/home-gallery-1440.png' });
    const fabHidden = await page.evaluate(() => document.getElementById('chat-fab').hidden);
    fabHidden ? ok('AI chat hidden while assistant disabled') : bad('AI chat visibility', 'visible although disabled');
  }
  page.errors.length === 0 ? ok(`No JS errors on homepage @ ${w}px`) : bad(`JS errors @ ${w}px`, page.errors.join(' | '));
  await page.close();
}

// ---- 2. Portal login pages overflow ----
for (const [path, name] of [['/admin/', 'Admin'], ['/teacher/', 'Teacher'], ['/parent/', 'Parent']]) {
  for (const w of [320, 390]) {
    const page = await newPage(w);
    await page.goto(BASE + path, { waitUntil: 'networkidle' });
    await page.waitForTimeout(500);
    await overflowCheck(page, `${name} login @ ${w}px`);
    if (w === 390 && path === '/admin/') await page.screenshot({ path: 'test-artifacts/admin-login-390.png' });
    await page.close();
  }
}

// ---- 3. Admin flow ----
if (ADMIN_USER && ADMIN_PASS) {
  const page = await newPage(1440);
  await page.goto(BASE + '/admin/', { waitUntil: 'networkidle' });
  await page.fill('#l-user', ADMIN_USER);
  await page.fill('#l-pass', ADMIN_PASS);
  await page.click('#login-form button[type=submit]');
  try {
    await page.waitForSelector('#app-view:not([hidden])', { timeout: 15000 });
    await page.waitForSelector('.stats .stat', { timeout: 15000 });
    ok('Admin login → dashboard renders');
    await page.waitForTimeout(600);
    await page.screenshot({ path: 'test-artifacts/admin-dashboard-1440.png' });
    for (const [tab, sel] of [['students', '#st-add'], ['gallery', '#g-add'], ['notices', '#n-add'], ['content', '[data-save=brand]'], ['fees', '#fe-student'], ['health', '.stats']]) {
      await page.click(`[data-nav=${tab}]`);
      await page.waitForSelector(sel, { timeout: 10000 });
      ok(`Admin tab renders: ${tab}`);
    }
    await overflowCheck(page, 'Admin app @ 1440px');
  } catch (e) { bad('Admin flow', e.message.split('\n')[0]); }
  page.errors.length === 0 ? ok('No JS errors in admin app') : bad('Admin JS errors', page.errors.join(' | '));
  await page.close();

  // ---- 4. Parent flow (mobile) ----
  const pp = await newPage(390, 844);
  await pp.goto(BASE + '/parent/', { waitUntil: 'networkidle' });
  await pp.fill('#l-adm', 'NKPS001');
  await pp.fill('#l-dob', '2021-03-15');
  await pp.click('#login-form button[type=submit]');
  try {
    await pp.waitForSelector('#app-view:not([hidden])', { timeout: 15000 });
    await pp.waitForSelector('.stats .stat', { timeout: 15000 });
    ok('Parent login (admission no + DOB) → dashboard');
    await pp.waitForTimeout(500);
    await pp.screenshot({ path: 'test-artifacts/parent-dashboard-390.png' });
    await overflowCheck(pp, 'Parent app @ 390px');
    for (const [tab, sel] of [['fees', '.table-wrap'], ['results', '.card'], ['attendance', '#at-month']]) {
      await pp.click('#menu-btn'); // mobile: open the sidebar first
      await pp.waitForTimeout(350);
      await pp.click(`[data-nav=${tab}]`);
      await pp.waitForSelector(sel, { timeout: 10000 });
      ok(`Parent tab renders: ${tab}`);
    }
  } catch (e) { bad('Parent flow', e.message.split('\n')[0]); }
  pp.errors.length === 0 ? ok('No JS errors in parent app') : bad('Parent JS errors', pp.errors.join(' | '));
  await pp.close();

  // ---- 5. Teacher flow ----
  const tp = await newPage(1440);
  await tp.goto(BASE + '/teacher/', { waitUntil: 'networkidle' });
  await tp.fill('#l-user', 'sunita.teacher');
  await tp.fill('#l-pass', 'Teacher@1234');
  await tp.click('#login-form button[type=submit]');
  try {
    await tp.waitForSelector('#app-view:not([hidden])', { timeout: 15000 });
    await tp.waitForSelector('#cl-sel', { timeout: 15000 });
    ok('Teacher login → my classes render');
    await tp.click('[data-nav=attendance]');
    await tp.waitForSelector('#a-table table', { timeout: 10000 });
    ok('Teacher attendance register renders');
    await tp.screenshot({ path: 'test-artifacts/teacher-attendance-1440.png' });
  } catch (e) { bad('Teacher flow', e.message.split('\n')[0]); }
  tp.errors.length === 0 ? ok('No JS errors in teacher app') : bad('Teacher JS errors', tp.errors.join(' | '));
  await tp.close();
} else {
  report.push('⚠️ Portal flow tests skipped (set ADMIN_USER / ADMIN_PASS)');
}

await browser.close();
console.log('\n═══════════════════════════════════════════════');
console.log('  NANHE KADAM — BROWSER UI TEST RESULTS');
console.log('═══════════════════════════════════════════════');
report.forEach((r) => console.log(r));
console.log(`\n  Passed: ${passed}   Failed: ${failed}`);
console.log('  Screenshots: test-artifacts/');
console.log('═══════════════════════════════════════════════\n');
process.exit(failed > 0 ? 1 : 0);
