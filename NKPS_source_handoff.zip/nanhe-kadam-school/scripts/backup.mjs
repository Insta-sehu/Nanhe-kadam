// Manual database backup (full SQL export of D1, including images).
// Usage: npm run db:backup            → backs up the LIVE database
//        npm run db:backup -- --local → backs up the local dev database
import { execSync } from 'node:child_process';
import { mkdirSync } from 'node:fs';

mkdirSync('backups', { recursive: true });
const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
const file = `backups/nkps-backup-${stamp}.sql`;
const flag = process.argv.includes('--local') ? '--local --persist-to .data' : '--remote';
console.log(`→ Exporting database to ${file} …`);
execSync(`npx wrangler d1 export nanhe-kadam-db ${flag} --output=${file}`, { stdio: 'inherit' });
console.log(`\n✅ Backup saved: ${file}`);
console.log('Keep backups OUT of git (the backups/ folder is gitignored).');
console.log('Restore procedure: see docs/BACKUP.md');
