// Seed demo data for local development / preview.
// Credentials are passed via environment variables so nothing secret lives in the repo:
//   ADMIN_USER='Rakesh@1' ADMIN_PASS='your-password' npm run demo:seed
// (server must be running: npm run dev)
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8787';
const ADMIN_USER = process.env.ADMIN_USER;
const ADMIN_PASS = process.env.ADMIN_PASS;
if (!ADMIN_USER || !ADMIN_PASS) {
  console.error('Set ADMIN_USER and ADMIN_PASS environment variables first.');
  console.error("Example: ADMIN_USER='Rakesh@1' ADMIN_PASS='your-password' npm run demo:seed");
  process.exit(1);
}
let cookie = '';

async function req(path, opts = {}) {
  const res = await fetch(BASE + path, {
    method: opts.method || 'GET',
    headers: { 'Content-Type': 'application/json', 'X-NKPS-Client': 'fetch', Cookie: cookie },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const sc = res.headers.get('set-cookie');
  if (sc) cookie = sc.split(';')[0];
  let data = {};
  try { data = await res.json(); } catch {}
  if (!res.ok) throw new Error(`${path}: ${data.error || res.status}`);
  return data;
}

// Setup admin if needed
const { needed } = await req('/api/setup-status');
if (needed) {
  await req('/api/setup', { method: 'POST', body: { name: 'School Owner', username: ADMIN_USER, password: ADMIN_PASS } });
  console.log(`✓ Admin created: ${ADMIN_USER}`);
} else {
  await req('/api/auth/login', { method: 'POST', body: { username: ADMIN_USER, password: ADMIN_PASS } });
  console.log(`✓ Logged in as ${ADMIN_USER}`);
}

// Classes already seeded by migration; get them
const { classes } = await req('/api/admin/classes');
const cid = (name) => classes.find((c) => c.name === name)?.id;
console.log('✓ Classes:', classes.map((c) => c.name).join(', '));

// Demo students
const students = [
  { name: 'Aarav Kumar', admission_no: 'NKPS001', class_id: cid('Play Group'), dob: '2021-03-15', guardian_name: 'Rajesh Kumar', guardian_phone: '9876543210', admission_date: '2026-04-01' },
  { name: 'Priya Sharma', admission_no: 'NKPS002', class_id: cid('Nursery'), dob: '2020-07-22', guardian_name: 'Sunita Sharma', guardian_phone: '9876543211', admission_date: '2026-04-01' },
  { name: 'Rohan Singh', admission_no: 'NKPS003', class_id: cid('LKG'), dob: '2019-11-08', guardian_name: 'Vikram Singh', guardian_phone: '9876543212', admission_date: '2026-04-01' },
  { name: 'Ananya Gupta', admission_no: 'NKPS004', class_id: cid('UKG'), dob: '2018-05-30', guardian_name: 'Meera Gupta', guardian_phone: '9876543213', admission_date: '2026-04-01' },
  { name: 'Arjun Yadav', admission_no: 'NKPS005', class_id: cid('Class 1'), dob: '2017-09-12', guardian_name: 'Ramesh Yadav', guardian_phone: '9876543214', admission_date: '2026-04-01' },
];
const sids = [];
for (const s of students) {
  try { const r = await req('/api/admin/students', { method: 'POST', body: s }); sids.push(r.id); console.log(`✓ Student: ${s.name} (${s.admission_no})`); }
  catch (e) { if (e.message.includes('already exists')) { const { students: list } = await req('/api/admin/students'); sids.push(list.find((x) => x.admission_no === s.admission_no)?.id); console.log(`  (exists: ${s.name})`); } else throw e; }
}

// Demo teacher
try {
  await req('/api/admin/teachers', { method: 'POST', body: { name: 'Sunita Devi', phone: '9876500001', email: '', qualification: 'B.Ed, NTT', username: 'sunita.teacher', password: 'Teacher@1234', class_ids: [cid('Play Group'), cid('Nursery')] } });
  console.log('✓ Teacher: sunita.teacher / Teacher@1234');
} catch (e) { console.log('  (teacher exists)'); }

// Fees for first student
if (sids[0]) {
  await req('/api/admin/fees', { method: 'POST', body: { student_id: sids[0], title: 'Monthly Fee — April 2026', amount: 1500, due_date: '2026-04-10', status: 'paid', paid_on: '2026-04-08' } });
  await req('/api/admin/fees', { method: 'POST', body: { student_id: sids[0], title: 'Monthly Fee — May 2026', amount: 1500, due_date: '2026-05-10', status: 'due' } });
  console.log('✓ Fees added for Aarav');
}

// Results for first student
if (sids[0]) {
  for (const [sub, marks] of [['English', 88], ['Maths', 92], ['EVS', 85], ['Hindi', 79]]) {
    await req('/api/admin/results', { method: 'POST', body: { student_id: sids[0], exam: 'Unit Test 1', subject: sub, marks, max_marks: 100, term: 'Term 1' } });
  }
  console.log('✓ Results added for Aarav');
}

// Attendance for Play Group (last 5 days)
const pgId = cid('Play Group');
const { students: pgStudents } = await req(`/api/admin/attendance?class_id=${pgId}&date=2026-11-07`);
for (let d = 3; d <= 7; d++) {
  const date = `2026-11-0${d}`;
  const records = pgStudents.map((s, i) => ({ student_id: s.id, status: i === 0 && d === 5 ? 'A' : 'P' }));
  if (records.length) await req('/api/admin/attendance', { method: 'POST', body: { class_id: pgId, date, records } });
}
console.log('✓ Attendance marked for Play Group');

// Homework
await req('/api/admin/homework', { method: 'POST', body: { class_id: pgId, title: 'Practice writing A–E', details: 'Write each letter 5 times in the notebook. Colour the pictures.', due_date: '2026-11-12' } });
await req('/api/admin/homework', { method: 'POST', body: { class_id: cid('Nursery'), title: 'Count and colour 1–10', details: 'Colour the fruits and count them. Say the numbers aloud.', due_date: '2026-11-13' } });
console.log('✓ Homework added');

// Gallery demo photos (use the generated illustrations)
import { readFileSync } from 'node:fs';
const toDataUrl = (path) => 'data:image/webp;base64,' + readFileSync(path).toString('base64');
const galleryItems = [
  { file: 'public/assets/img/hero-3d.webp', title: 'Our Learning World', caption: 'Every day is a new adventure at Nanhe Kadam.', photo_date: '2026-11-01', sort_order: 10 },
  { file: 'public/assets/img/care-3d.webp', title: 'Story Time with Teacher', caption: 'Learning through stories, songs and smiles.', photo_date: '2026-11-03', sort_order: 20 },
  { file: 'demo-assets/play-3d.webp', title: 'Block Play & Building', caption: 'Little hands, big ideas — building together.', photo_date: '2026-11-05', sort_order: 30 },
  { file: 'demo-assets/art-3d.webp', title: 'Art & Craft Day', caption: 'Colours, creativity and joy in every stroke.', photo_date: '2026-11-07', sort_order: 40 },
];
for (const g of galleryItems) {
  try {
    await req('/api/admin/gallery', { method: 'POST', body: { image: toDataUrl(g.file), title: g.title, caption: g.caption, photo_date: g.photo_date, sort_order: g.sort_order, published: true } });
    console.log(`✓ Gallery: ${g.title}`);
  } catch (e) { console.log(`  gallery skip: ${e.message}`); }
}

console.log('\n✅ Demo data seeded!');
console.log(`   Admin:   /admin/   → ${ADMIN_USER} (your password)`);
console.log('   Teacher: /teacher/ → sunita.teacher / Teacher@1234  (demo only — delete before real use)');
console.log('   Parent:  /parent/  → NKPS001 + DOB 2021-03-15  (demo only — delete before real use)');
