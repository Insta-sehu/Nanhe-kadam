// Secure admin creation / password recovery WITHOUT putting credentials in code.
// Usage:
//   npm run admin:create -- --username "Rakesh@1" --password "your-strong-password" --name "Rakesh"
//   (add --local to target the local dev database instead of the live one)
// If the username exists, its password is reset and the account re-activated.
import { pbkdf2Sync, randomBytes } from 'node:crypto';
import { execSync } from 'node:child_process';
import { writeFileSync, unlinkSync } from 'node:fs';
import readline from 'node:readline';

const args = Object.fromEntries(process.argv.slice(2).map((a, i, arr) => a.startsWith('--') ? [a.slice(2), arr[i + 1]?.startsWith('--') ? true : arr[i + 1]] : []).filter(Boolean));
const ask = (q, hidden = false) => new Promise((res) => {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  rl.question(q, (a) => { rl.close(); res(a.trim()); });
});

const username = args.username || await ask('Admin username: ');
const password = args.password || await ask('Admin password (min 8 chars): ');
const name = args.name || await ask('Display name: ');
if (!username || !/^[A-Za-z0-9@._-]{3,32}$/.test(username)) { console.error('Invalid username.'); process.exit(1); }
if (!password || password.length < 8) { console.error('Password must be at least 8 characters.'); process.exit(1); }

const salt = randomBytes(16);
const hash = pbkdf2Sync(password, salt, 100000, 32, 'sha256');
const b64url = (b) => b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const stored = `pbkdf2:100000:${b64url(salt)}:${b64url(hash)}`;
const esc = (s) => String(s).replace(/'/g, "''");

const sql = `
INSERT INTO users (role, username, password_hash, name, active) VALUES ('admin', '${esc(username)}', '${stored}', '${esc(name || username)}', 1)
ON CONFLICT(username) DO UPDATE SET password_hash=excluded.password_hash, active=1, failed_attempts=0, locked_until=0;
DELETE FROM sessions WHERE user_type='staff' AND user_id IN (SELECT id FROM users WHERE username='${esc(username)}');
`;
const tmp = `.admin-create-${Date.now()}.sql`;
writeFileSync(tmp, sql);
try {
  const flag = args.local ? '--local --persist-to .data' : '--remote';
  execSync(`npx wrangler d1 execute nanhe-kadam-db ${flag} --file=${tmp}`, { stdio: 'inherit' });
  console.log(`\n✅ Admin "${username}" is ready. Sign in at /admin/ — change the password after first login if it was shared.`);
} finally { unlinkSync(tmp); }
