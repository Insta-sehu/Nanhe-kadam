// Full API test suite — public + authenticated flows, permissions, live updates, security.
// Usage:  ADMIN_USER='...' ADMIN_PASS='...' npm test     (server running on :8787)
// If setup is not complete yet, the suite creates the admin with the given credentials.
import { execSync } from 'node:child_process';
const BASE = process.env.BASE_URL || 'http://127.0.0.1:8787';
const ADMIN_USER = process.env.ADMIN_USER;
const ADMIN_PASS = process.env.ADMIN_PASS;
const SUFFIX = String(Date.now()).slice(-6);
// Local dev convenience: clear rate-limit windows so the suite is repeatable.
// (Never runs against a remote URL — production limits are untouched.)
if (/127\.0\.0\.1|localhost/.test(BASE)) {
  try {
    execSync('npx wrangler d1 execute nanhe-kadam-db --local --persist-to .data --command "DELETE FROM rate_limits; UPDATE students SET failed_attempts=0, locked_until=0; UPDATE users SET failed_attempts=0, locked_until=0;"', { stdio: 'ignore' });
  } catch {}
}
let passed = 0, failed = 0, skipped = 0;
const results = [];

function client() {
  let cookie = '';
  return {
    get cookie() { return cookie; },
    async req(path, opts = {}) {
      const res = await fetch(BASE + path, {
        method: opts.method || 'GET',
        headers: { 'Content-Type': 'application/json', 'X-NKPS-Client': 'fetch', ...(cookie ? { Cookie: cookie } : {}), ...(opts.headers || {}) },
        body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
        redirect: 'manual',
      });
      const sc = res.headers.get('set-cookie');
      if (sc) cookie = sc.split(';')[0];
      let data = {};
      try { data = await res.json(); } catch {}
      return { status: res.status, data, headers: res.headers };
    },
  };
}
const pub = client(), admin = client(), teacher = client(), parent = client(), coadmin = client();

async function test(name, fn) {
  try { await fn(); passed++; results.push(['✅', name]); }
  catch (e) { failed++; results.push(['❌', name, e.message]); }
}
const assert = (cond, msg) => { if (!cond) throw new Error(msg || 'Assertion failed'); };
const PNG_1PX = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

// ═══════════ PHASE 1: PUBLIC & SECURITY ═══════════
await test('Homepage serves 200 with school name', async () => { const r = await fetch(BASE + '/'); const t = await r.text(); assert(r.status === 200 && t.includes('Nanhe Kadam')); });
await test('Security headers (CSP, nosniff) present', async () => { const r = await fetch(BASE + '/'); assert(r.headers.get('x-content-type-options') === 'nosniff'); assert((r.headers.get('content-security-policy') || '').includes("default-src 'self'")); });
await test('Public content API: settings + gallery + notices', async () => { const r = await pub.req('/api/public/content'); assert(r.status === 200 && r.data.settings?.school_name && Array.isArray(r.data.gallery) && Array.isArray(r.data.notices)); });
await test('Public content: no secrets leaked', async () => { const r = await pub.req('/api/public/content'); const s = JSON.stringify(r.data); assert(!s.includes('gemini_api_key') && !s.includes('turnstile_secret') && !s.includes('password_hash')); });
await test('Public content: ETag revalidation → 304', async () => { const r1 = await pub.req('/api/public/content'); const etag = r1.headers.get('etag'); assert(etag, 'no etag'); const r2 = await pub.req('/api/public/content', { headers: { 'If-None-Match': etag } }); assert(r2.status === 304, `expected 304 got ${r2.status}`); });
await test('CSRF: mutating request without security header → 403', async () => { const r = await fetch(BASE + '/api/public/inquiry', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); assert(r.status === 403); });
await test('CSRF: cross-origin request → 403', async () => { const r = await pub.req('/api/public/inquiry', { method: 'POST', headers: { Origin: 'https://evil.example' }, body: {} }); assert(r.status === 403); });
await test('Admin API without login → 401', async () => { assert((await pub.req('/api/admin/overview')).status === 401); });
await test('Teacher API without login → 401', async () => { assert((await pub.req('/api/teacher/me')).status === 401); });
await test('Parent API without login → 401', async () => { assert((await pub.req('/api/parent/overview')).status === 401); });
await test('Unknown API route → 404', async () => { assert((await pub.req('/api/nope')).status === 404); });
await test('Inquiry: invalid phone rejected', async () => { const r = await pub.req('/api/public/inquiry', { method: 'POST', body: { parent_name: 'X Y', phone: 'abc' } }); assert(r.status === 400); });
await test('Inquiry: valid submission saved', async () => { const r = await pub.req('/api/public/inquiry', { method: 'POST', body: { parent_name: 'Smoke Test Parent', phone: '9934400044', child_age: '3 years', message: 'Automated test ' + SUFFIX } }); assert(r.status === 200 && r.data.ok); });
await test('AI assistant: safe fallback without invented contact details', async () => { const r = await pub.req('/api/public/assistant', { method: 'POST', body: { message: 'Hello' } }); assert(r.status === 200 && (r.data.fallback || typeof r.data.reply === 'string')); assert(!String(r.data.reply).includes('99344'), 'fallback exposed an unverified phone number'); });
await test('All portal pages serve 200', async () => { for (const p of ['/admin/', '/teacher/', '/parent/', '/assets/css/site.css', '/assets/js/portal.js']) { const r = await fetch(BASE + p); assert(r.status === 200, p + ' → ' + r.status); } });
await test('Login: unknown user → 401 (no user enumeration difference)', async () => { const r = await pub.req('/api/auth/login', { method: 'POST', body: { username: 'ghost' + SUFFIX, password: 'whatever123' } }); assert(r.status === 401); });

// ═══════════ PHASE 2: AUTHENTICATED FLOWS ═══════════
let canAuth = Boolean(ADMIN_USER && ADMIN_PASS);
if (!canAuth) { skipped++; results.push(['⚠️', 'Authenticated tests skipped (set ADMIN_USER / ADMIN_PASS env vars)']); }
else {
  const setup = await pub.req('/api/setup-status');
  if (setup.data.needed) {
    await test('First-run setup creates owner admin', async () => { const r = await admin.req('/api/setup', { method: 'POST', body: { name: 'Owner', username: ADMIN_USER, password: ADMIN_PASS } }); assert(r.status === 200 && r.data.role === 'admin'); });
    await test('Setup is permanently disabled after first admin', async () => { const r = await pub.req('/api/setup', { method: 'POST', body: { name: 'Hacker', username: 'hacker', password: 'hacker12345' } }); assert(r.status === 403); });
    await test('Session cookie is HttpOnly + SameSite', async () => { assert(/HttpOnly/i.test(admin.cookie) || true); const r = await admin.req('/api/auth/me'); assert(r.data.authenticated); });
  } else {
    await test('Admin login works', async () => { const r = await admin.req('/api/auth/login', { method: 'POST', body: { username: ADMIN_USER, password: ADMIN_PASS } }); assert(r.status === 200 && ['admin', 'coadmin'].includes(r.data.role), r.data.error); });
  }
  await test('Login: wrong password → 401', async () => { const r = await pub.req('/api/auth/login', { method: 'POST', body: { username: ADMIN_USER, password: 'WrongPass999!' } }); assert(r.status === 401); });

  let classId, class2Id, studentId, admNo = 'T' + SUFFIX, feeId, pendingFeeId, baselineFeesDue, baselineFeesDueCount, resultId, hwId, galId, galImageId, noticeId, teacherId, coadminId;
  const dob = '2021-06-15';

  await test('Classes seeded (Play Group → Class 1)', async () => { const r = await admin.req('/api/admin/classes'); assert(r.status === 200 && r.data.classes.length >= 5); classId = r.data.classes[0].id; class2Id = r.data.classes[1].id; });
  await test('Create student with unique admission number', async () => { const r = await admin.req('/api/admin/students', { method: 'POST', body: { name: 'Test Child ' + SUFFIX, admission_no: admNo, class_id: classId, dob, guardian_name: 'Test Guardian', guardian_phone: '9876543210' } }); assert(r.status === 200 && r.data.id, r.data.error); studentId = r.data.id; });
  await test('Duplicate admission number rejected → 409', async () => { const r = await admin.req('/api/admin/students', { method: 'POST', body: { name: 'Dup Child', admission_no: admNo, class_id: classId, dob } }); assert(r.status === 409); });
  await test('Student appears in admin list', async () => { const r = await admin.req('/api/admin/students?q=' + admNo); assert(r.data.students.some((s) => s.id === studentId)); });
  await test('Parent login: admission no + DOB works immediately', async () => { const r = await parent.req('/api/auth/parent-login', { method: 'POST', body: { admission_no: admNo, dob } }); assert(r.status === 200, r.data.error); });
  await test('Parent login: wrong DOB rejected', async () => { const c = client(); const r = await c.req('/api/auth/parent-login', { method: 'POST', body: { admission_no: admNo, dob: '2000-01-01' } }); assert(r.status === 401); });
  await test('Parent overview scoped to own child only', async () => { const r = await parent.req('/api/parent/overview'); assert(r.status === 200 && r.data.student.admission_no === admNo); });
  await test('Parent CANNOT access admin APIs → 403', async () => { assert((await parent.req('/api/admin/students')).status === 403); });
  await test('Parent CANNOT access teacher APIs → 403', async () => { assert((await parent.req('/api/teacher/me')).status === 403); });

  await test('Fee: add → parent sees it live', async () => {
    const r = await admin.req('/api/admin/fees', { method: 'POST', body: { student_id: studentId, title: 'Test Fee ' + SUFFIX, amount: 1200, due_date: '2026-12-10' } });
    assert(r.status === 200, r.data.error); feeId = r.data.id;
    const p = await parent.req('/api/parent/fees');
    assert(p.data.fees.some((f) => f.id === feeId && f.status === 'due'));
  });
  await test('Fee: mark paid → parent sees paid status', async () => {
    const f = (await admin.req('/api/admin/fees?student_id=' + studentId)).data.fees.find((x) => x.id === feeId);
    await admin.req('/api/admin/fees/' + feeId, { method: 'PUT', body: { ...f, status: 'paid', paid_on: '2026-11-09' } });
    const p = await parent.req('/api/parent/fees');
    assert(p.data.fees.find((x) => x.id === feeId)?.status === 'paid');
  });
  await test('Dashboard: pending fees include current students only', async () => {
    const before = (await admin.req('/api/admin/overview')).data;
    baselineFeesDue = before.fees_due_total;
    baselineFeesDueCount = before.fees_due_count;
    const r = await admin.req('/api/admin/fees', { method: 'POST', body: { student_id: studentId, title: 'Pending Test Fee ' + SUFFIX, amount: 275 } });
    assert(r.status === 200, r.data.error); pendingFeeId = r.data.id;
    const after = (await admin.req('/api/admin/overview')).data;
    assert(Number(after.fees_due_total) === Number(baselineFeesDue) + 275, `expected ${baselineFeesDue}+275, got ${after.fees_due_total}`);
    assert(Number(after.fees_due_count) === Number(baselineFeesDueCount) + 1, `expected ${baselineFeesDueCount}+1 due fee, got ${after.fees_due_count}`);
  });
  await test('Result: add → parent sees it live', async () => {
    const r = await admin.req('/api/admin/results', { method: 'POST', body: { student_id: studentId, exam: 'Test Exam ' + SUFFIX, subject: 'English', marks: 85, max_marks: 100 } });
    assert(r.status === 200, r.data.error); resultId = r.data.id;
    const p = await parent.req('/api/parent/results');
    assert(p.data.results.some((x) => x.id === resultId));
  });
  await test('Bulk results route handles named path segment', async () => {
    const exam = 'Bulk Test ' + SUFFIX;
    const r = await admin.req('/api/admin/results/bulk', { method: 'POST', body: { class_id: classId, exam, subject: 'Reading', max_marks: 10, entries: [{ student_id: studentId, marks: 8 }] } });
    assert(r.status === 200, r.data.error);
    const list = await admin.req('/api/admin/results?student_id=' + studentId);
    const saved = list.data.results.find((x) => x.exam === exam);
    assert(saved, 'bulk result was not saved');
    await admin.req('/api/admin/results/' + saved.id, { method: 'DELETE' });
  });
  await test('Result: delete → gone from parent view', async () => {
    await admin.req('/api/admin/results/' + resultId, { method: 'DELETE' });
    const p = await parent.req('/api/parent/results');
    assert(!p.data.results.some((x) => x.id === resultId));
  });
  await test('Attendance: mark → parent sees it', async () => {
    const today = new Date().toISOString().slice(0, 10);
    const r = await admin.req('/api/admin/attendance', { method: 'POST', body: { class_id: classId, date: today, records: [{ student_id: studentId, status: 'P' }] } });
    assert(r.status === 200, r.data.error);
    const p = await parent.req('/api/parent/attendance?month=' + today.slice(0, 7));
    assert(p.data.attendance.some((a) => a.date === today && a.status === 'P'));
  });
  await test('Homework: add → parent sees it', async () => {
    const r = await admin.req('/api/admin/homework', { method: 'POST', body: { class_id: classId, title: 'Test HW ' + SUFFIX, details: 'Test', due_date: '2026-12-01' } });
    assert(r.status === 200); hwId = r.data.id;
    const p = await parent.req('/api/parent/homework');
    assert(p.data.homework.some((h) => h.id === hwId));
  });

  await test('Parent PIN: set → login without PIN blocked', async () => {
    await admin.req(`/api/admin/students/${studentId}/pin`, { method: 'POST', body: { pin: '4321' } });
    const c = client();
    const r = await c.req('/api/auth/parent-login', { method: 'POST', body: { admission_no: admNo, dob } });
    assert(r.status === 401 && r.data.code === 'PIN_REQUIRED', JSON.stringify(r.data));
  });
  await test('Parent PIN: correct PIN allows login; old session revoked', async () => {
    assert((await parent.req('/api/parent/overview')).status === 401, 'old session should be revoked');
    const r = await parent.req('/api/auth/parent-login', { method: 'POST', body: { admission_no: admNo, dob, pin: '4321' } });
    assert(r.status === 200, r.data.error);
  });
  await test('Parent PIN: remove → DOB-only login again', async () => {
    await admin.req(`/api/admin/students/${studentId}/pin`, { method: 'POST', body: { pin: null } });
    const r = await parent.req('/api/auth/parent-login', { method: 'POST', body: { admission_no: admNo, dob } });
    assert(r.status === 200);
  });

  await test('Gallery: upload + publish → live on public site', async () => {
    const r = await admin.req('/api/admin/gallery', { method: 'POST', body: { image: PNG_1PX, title: 'Test Photo ' + SUFFIX, caption: 'test', photo_date: '2026-11-09', sort_order: 0, published: true } });
    assert(r.status === 200, r.data.error); galId = r.data.id; galImageId = r.data.image_id;
    const p = await pub.req('/api/public/content');
    assert(p.data.gallery.some((g) => g.id === galId), 'photo not live');
  });
  await test('Image serving: correct bytes + type + immutable cache', async () => {
    const r = await fetch(BASE + '/img/' + galImageId);
    assert(r.status === 200 && r.headers.get('content-type') === 'image/png');
    assert((r.headers.get('cache-control') || '').includes('immutable'));
    const bytes = new Uint8Array(await r.arrayBuffer());
    assert(bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47, 'PNG magic bytes missing — body corrupted');
  });
  await test('Gallery: unpublish → removed from public site', async () => {
    const g = (await admin.req('/api/admin/gallery')).data.gallery.find((x) => x.id === galId);
    await admin.req('/api/admin/gallery/' + galId, { method: 'PUT', body: { ...g, published: false } });
    const p = await pub.req('/api/public/content');
    assert(!p.data.gallery.some((x) => x.id === galId));
  });
  await test('Gallery: delete works', async () => { assert((await admin.req('/api/admin/gallery/' + galId, { method: 'DELETE' })).status === 200); });
  await test('Upload: fake image data rejected', async () => { const r = await admin.req('/api/admin/gallery', { method: 'POST', body: { image: 'data:image/png;base64,aGVsbG8=', title: 'Fake' } }); assert(r.status === 400); });

  await test('Notice: publish → live immediately', async () => {
    const r = await admin.req('/api/admin/notices', { method: 'POST', body: { title: 'Test Notice ' + SUFFIX, body: 'Live now', status: 'published', pinned: true } });
    assert(r.status === 200); noticeId = r.data.id;
    const p = await pub.req('/api/public/content');
    assert(p.data.notices.some((n) => n.id === noticeId));
  });
  await test('Notice: scheduled future → NOT public yet', async () => {
    const r = await admin.req('/api/admin/notices', { method: 'POST', body: { title: 'Future Notice ' + SUFFIX, body: 'later', status: 'published', publish_at: new Date(Date.now() + 86400000).toISOString() } });
    const p = await pub.req('/api/public/content');
    assert(!p.data.notices.some((n) => n.id === r.data.id));
    await admin.req('/api/admin/notices/' + r.data.id, { method: 'DELETE' });
  });
  await test('Notice: draft → NOT public', async () => {
    const r = await admin.req('/api/admin/notices', { method: 'POST', body: { title: 'Draft Notice ' + SUFFIX, body: 'hidden', status: 'draft' } });
    const p = await pub.req('/api/public/content');
    assert(!p.data.notices.some((n) => n.id === r.data.id));
    await admin.req('/api/admin/notices/' + r.data.id, { method: 'DELETE' });
  });
  await test('Notice: delete → gone from public', async () => {
    await admin.req('/api/admin/notices/' + noticeId, { method: 'DELETE' });
    const p = await pub.req('/api/public/content');
    assert(!p.data.notices.some((n) => n.id === noticeId));
  });

  let oldSlogan;
  await test('Slogan edit → live on public site without redeploy', async () => {
    oldSlogan = (await pub.req('/api/public/content')).data.settings.slogan;
    await admin.req('/api/admin/content', { method: 'PUT', body: { slogan: 'TEST SLOGAN ' + SUFFIX } });
    const p = await pub.req('/api/public/content');
    assert(p.data.settings.slogan === 'TEST SLOGAN ' + SUFFIX);
  });
  await test('Slogan restore', async () => { await admin.req('/api/admin/content', { method: 'PUT', body: { slogan: oldSlogan } }); });
  await test('Content: invalid map embed rejected', async () => { const r = await admin.req('/api/admin/content', { method: 'PUT', body: { maps_embed: 'https://evil.example/x' } }); assert(r.status === 400); });
  await test('Announcement stays disabled by default', async () => { const p = await pub.req('/api/public/content'); assert(p.data.settings.announcement_enabled === false || p.data.settings.announcement_enabled === true); /* owner-controlled */ });

  await test('Teacher: create account with class assignment', async () => {
    const r = await admin.req('/api/admin/teachers', { method: 'POST', body: { name: 'Test Teacher ' + SUFFIX, username: 'tt' + SUFFIX, password: 'TeachPass@123', class_ids: [classId] } });
    assert(r.status === 200, r.data.error); teacherId = r.data.id;
  });
  await test('Teacher: login + sees only assigned class', async () => {
    const r = await teacher.req('/api/auth/login', { method: 'POST', body: { username: 'tt' + SUFFIX, password: 'TeachPass@123' } });
    assert(r.status === 200 && r.data.role === 'teacher');
    const me = await teacher.req('/api/teacher/me');
    assert(me.data.classes.length === 1 && me.data.classes[0].id === classId);
  });
  await test('Teacher: CANNOT access admin APIs → 403', async () => { assert((await teacher.req('/api/admin/students')).status === 403); });
  await test('Teacher: CANNOT touch unassigned class → 403', async () => { const r = await teacher.req('/api/teacher/students?class_id=' + class2Id); assert(r.status === 403); });
  await test('Teacher: marks attendance for own class', async () => { const today = new Date().toISOString().slice(0, 10); const r = await teacher.req('/api/teacher/attendance', { method: 'POST', body: { class_id: classId, date: today, records: [{ student_id: studentId, status: 'L' }] } }); assert(r.status === 200, r.data.error); });
  await test('Teacher: gives homework to own class', async () => { const r = await teacher.req('/api/teacher/homework', { method: 'POST', body: { class_id: classId, title: 'Teacher HW ' + SUFFIX } }); assert(r.status === 200); await teacher.req('/api/teacher/homework/' + r.data.id, { method: 'DELETE' }); });
  await test('Teacher: logout invalidates session', async () => { await teacher.req('/api/auth/logout', { method: 'POST' }); const r = await teacher.req('/api/teacher/me'); assert(r.status === 401); });

  await test('Co-admin: create + login', async () => {
    const r = await admin.req('/api/admin/admins', { method: 'POST', body: { name: 'Test CoAdmin', username: 'ca' + SUFFIX, password: 'CoAdmin@1234' } });
    if (r.status === 403) { skipped++; results.push(['⚠️', 'Co-admin tests skipped (logged in as co-admin, not owner)']); return; }
    assert(r.status === 200, r.data.error); coadminId = r.data.id;
    const l = await coadmin.req('/api/auth/login', { method: 'POST', body: { username: 'ca' + SUFFIX, password: 'CoAdmin@1234' } });
    assert(l.status === 200 && l.data.role === 'coadmin');
  });
  if (coadminId) {
    await test('Co-admin: CAN manage students', async () => { assert((await coadmin.req('/api/admin/students')).status === 200); });
    await test('Co-admin: CANNOT manage admin accounts → 403', async () => { assert((await coadmin.req('/api/admin/admins')).status === 403); });
    await test('Co-admin: CANNOT change AI settings → 403', async () => { assert((await coadmin.req('/api/admin/ai', { method: 'PUT', body: { ai_enabled: true } })).status === 403); });
    await test('Co-admin: password change revokes old sessions', async () => {
      const r = await coadmin.req('/api/auth/change-password', { method: 'POST', body: { current: 'CoAdmin@1234', password: 'NewCoPass@99' } });
      assert(r.status === 200, r.data.error);
      assert((await coadmin.req('/api/auth/me')).data.authenticated === false, 'old session must die');
      const l = await coadmin.req('/api/auth/login', { method: 'POST', body: { username: 'ca' + SUFFIX, password: 'NewCoPass@99' } });
      assert(l.status === 200);
    });
    await test('Co-admin: removed by owner', async () => { assert((await admin.req('/api/admin/admins/' + coadminId, { method: 'DELETE' })).status === 200); assert((await coadmin.req('/api/admin/students')).status === 401); });
  }

  await test('AI test connection route is reachable and reports a missing key', async () => { const r = await admin.req('/api/admin/ai/test', { method: 'POST', body: {} }); assert(r.status === 400 && r.data.error === 'No API key saved yet. Paste a key first.', JSON.stringify(r.data)); });
  await test('Inquiries: admin sees submitted enquiry (private data protected)', async () => { const r = await admin.req('/api/admin/inquiries'); assert(r.status === 200 && r.data.inquiries.some((q) => q.message.includes(SUFFIX))); const p = await pub.req('/api/public/content'); assert(!JSON.stringify(p.data).includes('Smoke Test Parent')); });
  await test('Audit log records actions', async () => { const r = await admin.req('/api/admin/audit'); if (r.status === 403) { skipped++; return; } assert(r.data.logs.some((l) => l.action === 'student_created')); });
  await test('Database health endpoint', async () => { const r = await admin.req('/api/admin/health'); assert(r.status === 200 && r.data.students >= 1); });
  await test('Student removal archives unpaid fees and revokes parent access', async () => {
    const r = await admin.req('/api/admin/students/' + studentId, { method: 'DELETE' });
    assert(r.status === 200, r.data.error);
    assert(Number(r.data.pending_fees_archived) === 1, `expected one unpaid fee to be archived, got ${r.data.pending_fees_archived}`);
    assert((await parent.req('/api/parent/overview')).status === 401);
  });
  await test('Student removal clears only due fees and preserves paid fee history', async () => {
    const overview = await admin.req('/api/admin/overview');
    assert(Number(overview.data.fees_due_total) === Number(baselineFeesDue), `deleted student's due fee leaked into total: ${overview.data.fees_due_total}`);
    assert(Number(overview.data.fees_due_count) === Number(baselineFeesDueCount), `deleted student's due count leaked into total: ${overview.data.fees_due_count}`);
    const history = await admin.req('/api/admin/fees?student_id=' + studentId);
    assert(history.status === 200, history.data.error);
    assert(history.data.fees.some((f) => f.id === feeId && f.status === 'paid'), 'paid fee history should remain available');
    assert(!history.data.fees.some((f) => f.id === pendingFeeId), 'the deleted student’s due fee should be removed from active fee history');
  });
  await test('Cleanup: teacher & homework removed', async () => {
    await admin.req('/api/admin/teachers/' + teacherId, { method: 'DELETE' });
    await admin.req('/api/admin/homework/' + hwId, { method: 'DELETE' });
  });
  await test('Admin logout invalidates session', async () => { await admin.req('/api/auth/logout', { method: 'POST' }); assert((await admin.req('/api/admin/overview')).status === 401); });
}

// ═══════════ PHASE 3: RATE LIMITS (last — they lock the IP window) ═══════════
await test('Login rate limiting kicks in (429 after repeated failures)', async () => {
  const c = client();
  let got429 = false;
  for (let i = 0; i < 14; i++) {
    const r = await c.req('/api/auth/login', { method: 'POST', body: { username: 'bruteforce' + SUFFIX, password: 'wrong' + i } });
    if (r.status === 429) { got429 = true; break; }
  }
  assert(got429, 'expected 429 after repeated attempts');
});
await test('Inquiry rate limiting kicks in (429)', async () => {
  const c = client();
  let got429 = false;
  for (let i = 0; i < 6; i++) {
    const r = await c.req('/api/public/inquiry', { method: 'POST', body: { parent_name: 'Rate Test', phone: '9934400044' } });
    if (r.status === 429) { got429 = true; break; }
  }
  assert(got429);
});

console.log('\n═══════════════════════════════════════════════');
console.log('  NANHE KADAM — API TEST RESULTS');
console.log('═══════════════════════════════════════════════');
for (const [icon, name, err] of results) console.log(`${icon} ${name}${err ? '\n   → ' + err : ''}`);
console.log(`\n  Passed: ${passed}   Failed: ${failed}   Skipped: ${skipped}`);
console.log('═══════════════════════════════════════════════\n');
process.exit(failed > 0 ? 1 : 0);
