-- Upgrade the previous Gemini default for existing installs; preserve any model
-- explicitly chosen by the school owner.
UPDATE settings
SET value='"gemini-3.5-flash"', updated_at=datetime('now')
WHERE key='gemini_model' AND value='"gemini-2.5-flash"';
