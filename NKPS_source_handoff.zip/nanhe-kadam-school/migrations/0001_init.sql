-- Nanhe Kadam Public School — initial schema (Cloudflare D1 / SQLite)
-- All live website content lives in `settings` so the admin can edit it without redeploying.

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role TEXT NOT NULL CHECK (role IN ('admin','coadmin','teacher')),
  username TEXT NOT NULL COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  name TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  teacher_id INTEGER REFERENCES teachers(id),
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  last_login TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_username ON users(username);

CREATE TABLE IF NOT EXISTS classes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  sort_order INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  admission_no TEXT NOT NULL COLLATE NOCASE,
  name TEXT NOT NULL,
  class_id INTEGER REFERENCES classes(id),
  dob TEXT NOT NULL,
  guardian_name TEXT NOT NULL DEFAULT '',
  guardian_phone TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  admission_date TEXT NOT NULL DEFAULT (date('now')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','left')),
  photo_id TEXT,
  notes TEXT NOT NULL DEFAULT '',
  parent_pin_hash TEXT,
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_students_admission ON students(admission_no);
CREATE INDEX IF NOT EXISTS idx_students_class ON students(class_id);
CREATE INDEX IF NOT EXISTS idx_students_status ON students(status);

CREATE TABLE IF NOT EXISTS teachers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  qualification TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at TEXT
);

CREATE TABLE IF NOT EXISTS teacher_classes (
  teacher_id INTEGER NOT NULL REFERENCES teachers(id),
  class_id INTEGER NOT NULL REFERENCES classes(id),
  PRIMARY KEY (teacher_id, class_id)
);

CREATE TABLE IF NOT EXISTS attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id),
  class_id INTEGER NOT NULL REFERENCES classes(id),
  date TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('P','A','L')),
  marked_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (student_id, date)
);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date);
CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance(student_id);

CREATE TABLE IF NOT EXISTS homework (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id INTEGER NOT NULL REFERENCES classes(id),
  title TEXT NOT NULL,
  details TEXT NOT NULL DEFAULT '',
  due_date TEXT,
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_homework_class ON homework(class_id);

CREATE TABLE IF NOT EXISTS fees (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id),
  title TEXT NOT NULL,
  amount REAL NOT NULL CHECK (amount >= 0),
  due_date TEXT,
  status TEXT NOT NULL DEFAULT 'due' CHECK (status IN ('due','paid')),
  paid_on TEXT,
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_fees_student ON fees(student_id);

CREATE TABLE IF NOT EXISTS results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id INTEGER NOT NULL REFERENCES students(id),
  exam TEXT NOT NULL,
  subject TEXT NOT NULL,
  marks REAL NOT NULL,
  max_marks REAL NOT NULL CHECK (max_marks > 0),
  term TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_results_student ON results(student_id);

CREATE TABLE IF NOT EXISTS notices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  pinned INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  publish_at INTEGER,
  expires_at INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_notices_status ON notices(status, publish_at);

CREATE TABLE IF NOT EXISTS gallery (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  image_id TEXT NOT NULL,
  title TEXT NOT NULL,
  caption TEXT NOT NULL DEFAULT '',
  photo_date TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  published INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  deleted_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_gallery_pub ON gallery(published, sort_order);

CREATE TABLE IF NOT EXISTS images (
  id TEXT PRIMARY KEY,
  mime TEXT NOT NULL,
  size INTEGER NOT NULL,
  data BLOB NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS inquiries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  parent_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  child_age TEXT NOT NULL DEFAULT '',
  message TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new','read','archived')),
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_type TEXT NOT NULL CHECK (user_type IN ('staff','parent')),
  user_id INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  ip TEXT NOT NULL DEFAULT '',
  ua TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_type, user_id);

CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor TEXT NOT NULL DEFAULT 'system',
  role TEXT NOT NULL DEFAULT '',
  action TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '',
  ip TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_logs(created_at);

CREATE TABLE IF NOT EXISTS rate_limits (
  key TEXT PRIMARY KEY,
  window_start INTEGER NOT NULL,
  count INTEGER NOT NULL DEFAULT 0
);

-- ---------------------------------------------------------------------------
-- Default editable content (owner-verified facts only).
-- ---------------------------------------------------------------------------
INSERT OR IGNORE INTO classes (name, sort_order) VALUES
  ('Play Group', 1), ('Nursery', 2), ('LKG', 3), ('UKG', 4), ('Class 1', 5);

INSERT OR IGNORE INTO settings (key, value) VALUES
  ('school_name', '"Nanhe Kadam Public School"'),
  ('slogan', '"Little Steps. Big Dreams."'),
  ('slogan_hi', '"नन्हे कदम, बड़ी उड़ान"'),
  ('hero_subtitle', '"A caring English-medium school where children from Play Group to Class 1 learn through play, stories and discovery."'),
  ('about', '"Nanhe Kadam Public School is a warm, child-first English-medium school for our little ones — from Play Group to Class 1. We believe the first years of school should feel safe, joyful and full of curiosity.\n\nOur school is led by experienced retired DAV educators who bring decades of classroom wisdom to the youngest learners. Small groups, personal attention and everyday habits of reading, counting and caring form the heart of our day."'),
  ('director_name', '"Mr. R. P. Singh"'),
  ('director_role', '"Director · Former DAV School Mathematics Teacher (Retired)"'),
  ('director_message', '"After many years of teaching Mathematics at DAV, I wanted to build a school where learning begins the right way — with love, patience and strong foundations. At Nanhe Kadam, every child is known by name, every question is welcome, and every small step is celebrated. We invite you to visit us and see our little ones at play and at work."'),
  ('principal_name', '"Mrs. Amita"'),
  ('principal_role', '"Principal · Former DAV School Biology Teacher (Retired)"'),
  ('principal_message', '"Children are like young plants — they grow best with care, sunlight and gentle guidance. Our days are filled with stories, songs, colours and play, because that is how little children learn best. We work closely with parents, and our door is always open. Come, let us walk these first steps together."'),
  ('philosophy', '[{"title":"Learning through play","text":"Play is a child''s first language. Our rooms are set up so children learn letters, numbers and life skills while they play."},{"title":"Strong early foundations","text":"Guided by retired DAV educators, we build early reading, writing and number sense slowly, surely and without pressure."},{"title":"Care like family","text":"Caring aayas look after every child — helping with food, water and rest, so children feel as safe as they do at home."},{"title":"Values and good habits","text":"Sharing, greeting, tidying up and trying again — small everyday habits that grow into big values."}]'),
  ('activities', '[{"icon":"book","title":"Story Time","text":"Picture books, rhymes and puppets that grow vocabulary and imagination."},{"icon":"palette","title":"Art & Craft","text":"Colours, clay and paper work for little hands and big ideas."},{"icon":"music","title":"Music & Movement","text":"Songs, clapping patterns and dance that build rhythm and confidence."},{"icon":"blocks","title":"Letters & Numbers","text":"Playful early phonics and counting with blocks, cards and games."},{"icon":"ball","title":"Games & Play","text":"Indoor and outdoor play in our play room for strong, happy bodies."},{"icon":"star","title":"Festivals & Celebrations","text":"Birthdays, festivals and show-and-tell that teach sharing and joy."}]'),
  ('facilities', '["CCTV-camera monitored campus","Dedicated play room for little ones","Caring aayas (helpers) for every child","Healthy food and clean drinking water"]'),
  ('contact_phone', '"+91 99344 00044"'),
  ('contact_email', '""'),
  ('address', '"Near Cambridge School, Behind Sudha Doodh Factory, Kargil Chowk, Bihar"'),
  ('maps_url', '""'),
  ('maps_embed', '""'),
  ('announcement_enabled', 'false'),
  ('announcement_text', '""'),
  ('ai_enabled', 'false'),
  ('gemini_model', '"gemini-3.5-flash"'),
  ('gemini_api_key', '""'),
  ('ai_daily_cap', '150'),
  ('turnstile_site_key', '""'),
  ('turnstile_secret', '""'),
  ('logo_image_id', '""'),
  ('content_version', '1'),
  ('footer_note', '"An English-medium preschool & primary school · Bihar, India"');

-- Two safe, editable welcome notices (no launch/opening claims).
INSERT INTO notices (title, body, pinned, status, publish_at) VALUES
  ('Welcome to our new website', 'Welcome to the official website of Nanhe Kadam Public School. School photos, notices and updates will appear here. For any question, please call the school office.', 1, 'published', strftime('%s','now')),
  ('Admission enquiries', 'Parents may send an admission enquiry through the Contact section of this website or call the school. Our team will happily guide you about classes from Play Group to Class 1.', 0, 'published', strftime('%s','now'));
