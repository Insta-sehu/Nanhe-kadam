// Admin / co-admin API. Every route independently verifies the session + role.
// Co-admins can manage school data; only the primary admin manages accounts, AI keys and security keys.
import {
  json, err, readBody, str, int, num, dateStr, phoneStr, bool, clientIp, nowSec,
  getSettings, setSettings, saveImage, deleteImageIfUnused, audit,
} from './util.js';
import { requireAuth, hashPassword, validatePassword, validateUsername, revokeSessions, rateLimit } from './auth.js';
import { testGemini } from './gemini.js';

const ADMIN = ['admin', 'coadmin'];
const toEpoch = (v) => {
  if (v === null || v === undefined || v === '') return null;
  if (typeof v === 'number') return Number.isInteger(v) ? v : err(400, 'Invalid timestamp.');
  const t = Date.parse(v);
  if (Number.isNaN(t)) err(400, 'Invalid date/time.');
  return Math.floor(t / 1000);
};

export async function handleAdmin(request, env, path) {
  const s = await requireAuth(env, request, ADMIN);
  const ip = clientIp(request);
  const m = request.method;
  const seg = path.replace('/api/admin/', '').split('/');
  const [root, idPart, action] = seg;
  // Special endpoints use named path segments (e.g. /results/bulk and /ai/test).
  // Parse only numeric segments as record IDs so those routes remain reachable.
  const id = idPart && /^\d+$/.test(idPart) ? int(idPart, { min: 1, label: 'ID' }) : null;
  const url = new URL(request.url);
  const q = url.searchParams;
  const onlyAdmin = () => { if (s.role !== 'admin') err(403, 'Only the primary admin can do this.'); };

  // ================= OVERVIEW =================
  if (root === 'overview' && m === 'GET') {
    const r = await env.DB.batch([
      env.DB.prepare('SELECT COUNT(*) c FROM students WHERE deleted_at IS NULL'),
      env.DB.prepare("SELECT COUNT(*) c FROM students WHERE deleted_at IS NULL AND status='active'"),
      env.DB.prepare('SELECT c.id, c.name, COUNT(s.id) n FROM classes c LEFT JOIN students s ON s.class_id=c.id AND s.deleted_at IS NULL AND s.status=\'active\' WHERE c.active=1 GROUP BY c.id ORDER BY c.sort_order'),
      env.DB.prepare("SELECT id, name, admission_no, admission_date, class_id FROM students WHERE deleted_at IS NULL ORDER BY id DESC LIMIT 6"),
      env.DB.prepare("SELECT COALESCE(SUM(f.amount),0) total, COUNT(*) n FROM fees f JOIN students st ON st.id=f.student_id AND st.deleted_at IS NULL WHERE f.status='due' AND f.deleted_at IS NULL"),
      env.DB.prepare("SELECT COUNT(*) c FROM inquiries WHERE status='new'"),
      env.DB.prepare('SELECT COUNT(*) c FROM gallery WHERE published=1 AND deleted_at IS NULL'),
      env.DB.prepare('SELECT COUNT(*) c FROM teachers WHERE active=1 AND deleted_at IS NULL'),
      env.DB.prepare("SELECT COUNT(*) c FROM notices WHERE status='published' AND deleted_at IS NULL AND (expires_at IS NULL OR expires_at>?)").bind(nowSec()),
    ]);
    return json({
      total_students: r[0].results[0].c, active_students: r[1].results[0].c,
      class_counts: r[2].results, recent_admissions: r[3].results,
      fees_due_total: r[4].results[0].total, fees_due_count: r[4].results[0].n,
      new_inquiries: r[5].results[0].c, published_photos: r[6].results[0].c,
      teachers: r[7].results[0].c, active_notices: r[8].results[0].c,
    });
  }

  // ================= STUDENTS =================
  if (root === 'students') {
    if (m === 'GET' && !id) {
      const where = ['s.deleted_at IS NULL']; const binds = [];
      if (q.get('class_id')) { where.push('s.class_id=?'); binds.push(int(q.get('class_id'), { min: 1, label: 'Class' })); }
      if (q.get('status')) { where.push('s.status=?'); binds.push(str(q.get('status'), { max: 10, label: 'Status' })); }
      if (q.get('q')) { where.push('(s.name LIKE ? OR s.admission_no LIKE ?)'); const like = `%${q.get('q').slice(0, 40)}%`; binds.push(like, like); }
      const rows = (await env.DB.prepare(
        `SELECT s.id, s.admission_no, s.name, s.dob, s.class_id, c.name class_name, s.guardian_name, s.guardian_phone, s.status, s.admission_date, s.photo_id, (s.parent_pin_hash IS NOT NULL) has_pin
         FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE ${where.join(' AND ')} ORDER BY c.sort_order, s.name LIMIT 500`
      ).bind(...binds).all()).results;
      return json({ students: rows });
    }
    if (m === 'GET' && id) {
      const st = (await env.DB.prepare('SELECT s.*, c.name class_name, (s.parent_pin_hash IS NOT NULL) has_pin FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.id=? AND s.deleted_at IS NULL').bind(id).all()).results[0];
      if (!st) err(404, 'Student not found.');
      delete st.parent_pin_hash; delete st.failed_attempts; delete st.locked_until;
      return json({ student: st });
    }
    if (m === 'POST' && !id) {
      const b = await readBody(request);
      const data = await studentFields(env, b, true);
      if (b.photo) data.photo_id = await saveImage(env, b.photo, 700_000);
      if (b.parent_pin) data.pin_hash = await hashPassword(String(b.parent_pin));
      const cols = ['admission_no', 'name', 'class_id', 'dob', 'guardian_name', 'guardian_phone', 'address', 'admission_date', 'notes', 'photo_id', 'parent_pin_hash'];
      const vals = [data.admission_no, data.name, data.class_id, data.dob, data.guardian_name, data.guardian_phone, data.address, data.admission_date, data.notes, data.photo_id || null, data.pin_hash || null];
      try {
        const r = await env.DB.prepare(`INSERT INTO students (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`).bind(...vals).run();
        await audit(env, s.username, s.role, 'student_created', `${data.name} (${data.admission_no})`, ip);
        return json({ ok: true, id: r.meta.last_row_id });
      } catch (e) { if (String(e.message).includes('UNIQUE')) err(409, 'That admission number already exists. Please use a unique one.'); throw e; }
    }
    if (m === 'PUT' && id) {
      const old = (await env.DB.prepare('SELECT * FROM students WHERE id=? AND deleted_at IS NULL').bind(id).all()).results[0];
      if (!old) err(404, 'Student not found.');
      const b = await readBody(request);
      const data = await studentFields(env, b, true);
      let photo_id = old.photo_id;
      if (b.photo) { photo_id = await saveImage(env, b.photo, 700_000); }
      else if (b.photo === null) { photo_id = null; }
      try {
        await env.DB.prepare('UPDATE students SET admission_no=?, name=?, class_id=?, dob=?, guardian_name=?, guardian_phone=?, address=?, admission_date=?, notes=?, status=?, photo_id=? WHERE id=?')
          .bind(data.admission_no, data.name, data.class_id, data.dob, data.guardian_name, data.guardian_phone, data.address, data.admission_date, data.notes, ['active', 'inactive', 'left'].includes(b.status) ? b.status : old.status, photo_id, id).run();
      } catch (e) { if (String(e.message).includes('UNIQUE')) err(409, 'That admission number already exists.'); throw e; }
      if (photo_id !== old.photo_id) await deleteImageIfUnused(env, old.photo_id);
      if (old.admission_no !== data.admission_no || old.dob !== data.dob || b.status === 'inactive' || b.status === 'left') await revokeSessions(env, 'parent', id);
      await audit(env, s.username, s.role, 'student_updated', `${data.name} (${data.admission_no})`, ip);
      return json({ ok: true });
    }
    if (m === 'DELETE' && id) {
      const st = (await env.DB.prepare('SELECT name, admission_no FROM students WHERE id=? AND deleted_at IS NULL').bind(id).all()).results[0];
      if (!st) err(404, 'Student not found.');
      // Archive the student and their unpaid dues atomically. Paid fee rows remain
      // available as financial history; only open dues are removed from active views.
      const deleted = await env.DB.batch([
        env.DB.prepare("UPDATE students SET deleted_at=datetime('now'), status='inactive' WHERE id=? AND deleted_at IS NULL").bind(id),
        env.DB.prepare("UPDATE fees SET deleted_at=datetime('now') WHERE student_id=? AND status='due' AND deleted_at IS NULL").bind(id),
      ]);
      const pendingFeesArchived = deleted[1]?.meta?.changes || 0;
      await revokeSessions(env, 'parent', id);
      await audit(env, s.username, s.role, 'student_deleted', `${st.name} (${st.admission_no}); ${pendingFeesArchived} unpaid fee(s) archived`, ip);
      return json({ ok: true, pending_fees_archived: pendingFeesArchived });
    }
    if (m === 'POST' && id && action === 'pin') {
      const b = await readBody(request);
      let hash = null;
      if (b.pin) {
        const pin = String(b.pin);
        if (!/^[0-9]{4,8}$/.test(pin)) err(400, 'PIN must be 4–8 digits.');
        hash = await hashPassword(pin);
      }
      await env.DB.prepare('UPDATE students SET parent_pin_hash=? WHERE id=? AND deleted_at IS NULL').bind(hash, id).run();
      await revokeSessions(env, 'parent', id);
      await audit(env, s.username, s.role, 'parent_pin_changed', `Student #${id} PIN ${hash ? 'set' : 'removed'}`, ip);
      return json({ ok: true });
    }
  }

  if (root === 'student-attendance' && m === 'GET') {
    const sid = int(q.get('student_id'), { min: 1, label: 'Student' });
    const rows = (await env.DB.prepare('SELECT date, status FROM attendance WHERE student_id=? ORDER BY date DESC LIMIT 120').bind(sid).all()).results;
    return json({ attendance: rows });
  }

  // ================= CLASSES =================
  if (root === 'classes') {
    if (m === 'GET') return json({ classes: (await env.DB.prepare('SELECT * FROM classes WHERE active=1 ORDER BY sort_order, id').all()).results });
    if (m === 'POST') {
      const b = await readBody(request);
      const name = str(b.name, { min: 1, max: 40, label: 'Class name' });
      const order = int(b.sort_order ?? 99, { min: 0, max: 999, label: 'Order' });
      try { const r = await env.DB.prepare('INSERT INTO classes (name, sort_order) VALUES (?,?)').bind(name, order).run(); await audit(env, s.username, s.role, 'class_created', name, ip); return json({ ok: true, id: r.meta.last_row_id }); }
      catch (e) { if (String(e.message).includes('UNIQUE')) err(409, 'A class with that name already exists.'); throw e; }
    }
    if (m === 'PUT' && id) {
      const b = await readBody(request);
      const name = str(b.name, { min: 1, max: 40, label: 'Class name' });
      const order = int(b.sort_order ?? 99, { min: 0, max: 999, label: 'Order' });
      await env.DB.prepare('UPDATE classes SET name=?, sort_order=? WHERE id=?').bind(name, order, id).run();
      await audit(env, s.username, s.role, 'class_updated', name, ip);
      return json({ ok: true });
    }
    if (m === 'DELETE' && id) {
      const n = (await env.DB.prepare('SELECT COUNT(*) c FROM students WHERE class_id=? AND deleted_at IS NULL').bind(id).all()).results[0].c;
      if (n > 0) err(400, 'This class still has students. Move them to another class first.');
      await env.DB.prepare('UPDATE classes SET active=0 WHERE id=?').bind(id).run();
      await env.DB.prepare('DELETE FROM teacher_classes WHERE class_id=?').bind(id).run();
      await audit(env, s.username, s.role, 'class_deleted', `Class #${id}`, ip);
      return json({ ok: true });
    }
  }

  // ================= TEACHERS =================
  if (root === 'teachers') {
    if (m === 'GET' && !id) {
      const rows = (await env.DB.prepare(
        `SELECT t.*, u.id user_id, u.username, u.active account_active, u.last_login,
         (SELECT GROUP_CONCAT(c.name, ', ') FROM teacher_classes tc JOIN classes c ON c.id=tc.class_id WHERE tc.teacher_id=t.id) class_names
         FROM teachers t LEFT JOIN users u ON u.teacher_id=t.id WHERE t.deleted_at IS NULL ORDER BY t.name`
      ).all()).results;
      const tc = (await env.DB.prepare('SELECT * FROM teacher_classes').all()).results;
      return json({ teachers: rows, teacher_classes: tc });
    }
    if (m === 'POST' && !id) {
      const b = await readBody(request);
      const name = str(b.name, { min: 2, max: 80, label: 'Teacher name' });
      const phone = b.phone ? phoneStr(b.phone) : '';
      const email = str(b.email, { max: 120, label: 'Email', optional: true });
      const qualification = str(b.qualification, { max: 120, label: 'Qualification', optional: true });
      const username = str(b.username, { min: 3, max: 32, label: 'Username' }); validateUsername(username);
      validatePassword(b.password);
      const classIds = await validClassIds(env, b.class_ids);
      const tr = await env.DB.prepare('INSERT INTO teachers (name, phone, email, qualification) VALUES (?,?,?,?)').bind(name, phone, email, qualification).run();
      const tid = tr.meta.last_row_id;
      try {
        await env.DB.prepare("INSERT INTO users (role, username, password_hash, name, teacher_id) VALUES ('teacher',?,?,?,?)")
          .bind(username, await hashPassword(b.password), name, tid).run();
      } catch (e) { await env.DB.prepare('DELETE FROM teachers WHERE id=?').bind(tid).run(); if (String(e.message).includes('UNIQUE')) err(409, 'That username is already taken.'); throw e; }
      if (classIds.length) await env.DB.batch(classIds.map((cid) => env.DB.prepare('INSERT OR IGNORE INTO teacher_classes (teacher_id, class_id) VALUES (?,?)').bind(tid, cid)));
      await audit(env, s.username, s.role, 'teacher_created', `${name} (${username})`, ip);
      return json({ ok: true, id: tid });
    }
    if (m === 'PUT' && id) {
      const t = (await env.DB.prepare('SELECT * FROM teachers WHERE id=? AND deleted_at IS NULL').bind(id).all()).results[0];
      if (!t) err(404, 'Teacher not found.');
      const b = await readBody(request);
      const name = str(b.name, { min: 2, max: 80, label: 'Teacher name' });
      const phone = b.phone ? phoneStr(b.phone) : '';
      const email = str(b.email, { max: 120, label: 'Email', optional: true });
      const qualification = str(b.qualification, { max: 120, label: 'Qualification', optional: true });
      const active = bool(b.active) ? 1 : 0;
      await env.DB.prepare('UPDATE teachers SET name=?, phone=?, email=?, qualification=?, active=? WHERE id=?').bind(name, phone, email, qualification, active, id).run();
      await env.DB.prepare('UPDATE users SET name=?, active=? WHERE teacher_id=?').bind(name, active, id).run();
      if (Array.isArray(b.class_ids)) {
        const classIds = await validClassIds(env, b.class_ids);
        const stmts = [env.DB.prepare('DELETE FROM teacher_classes WHERE teacher_id=?').bind(id),
          ...classIds.map((cid) => env.DB.prepare('INSERT OR IGNORE INTO teacher_classes (teacher_id, class_id) VALUES (?,?)').bind(id, cid))];
        await env.DB.batch(stmts);
      }
      if (!active) { const u = (await env.DB.prepare('SELECT id FROM users WHERE teacher_id=?').bind(id).all()).results[0]; if (u) await revokeSessions(env, 'staff', u.id); }
      await audit(env, s.username, s.role, 'teacher_updated', name, ip);
      return json({ ok: true });
    }
    if (m === 'POST' && id && action === 'reset-password') {
      const b = await readBody(request); validatePassword(b.password);
      const u = (await env.DB.prepare('SELECT id, username FROM users WHERE teacher_id=?').bind(id).all()).results[0];
      if (!u) err(404, 'Teacher account not found.');
      await env.DB.prepare('UPDATE users SET password_hash=?, failed_attempts=0, locked_until=0 WHERE id=?').bind(await hashPassword(b.password), u.id).run();
      await revokeSessions(env, 'staff', u.id);
      await audit(env, s.username, s.role, 'teacher_password_reset', u.username, ip);
      return json({ ok: true });
    }
    if (m === 'DELETE' && id) {
      await env.DB.prepare("UPDATE teachers SET deleted_at=datetime('now'), active=0 WHERE id=?").bind(id).run();
      await env.DB.prepare('UPDATE users SET active=0 WHERE teacher_id=?').bind(id).run();
      const u = (await env.DB.prepare('SELECT id FROM users WHERE teacher_id=?').bind(id).all()).results[0];
      if (u) await revokeSessions(env, 'staff', u.id);
      await env.DB.prepare('DELETE FROM teacher_classes WHERE teacher_id=?').bind(id).run();
      await audit(env, s.username, s.role, 'teacher_deleted', `Teacher #${id}`, ip);
      return json({ ok: true });
    }
  }

  // ================= ATTENDANCE =================
  if (root === 'attendance') {
    if (m === 'GET') {
      const classId = int(q.get('class_id'), { min: 1, label: 'Class' });
      const date = dateStr(q.get('date'), 'Date');
      const r = await env.DB.batch([
        env.DB.prepare("SELECT id, name, admission_no FROM students WHERE class_id=? AND deleted_at IS NULL AND status='active' ORDER BY name").bind(classId),
        env.DB.prepare('SELECT student_id, status FROM attendance WHERE class_id=? AND date=?').bind(classId, date),
      ]);
      return json({ students: r[0].results, attendance: r[1].results });
    }
    if (m === 'POST') {
      const b = await readBody(request);
      const classId = int(b.class_id, { min: 1, label: 'Class' });
      const date = dateStr(b.date, 'Date');
      if (!Array.isArray(b.records) || b.records.length === 0 || b.records.length > 100) err(400, 'Attendance records are invalid.');
      const stmts = b.records.map((r) => {
        const sid = int(r.student_id, { min: 1, label: 'Student' });
        if (!['P', 'A', 'L'].includes(r.status)) err(400, 'Attendance status must be P, A or L.');
        return env.DB.prepare('INSERT INTO attendance (student_id, class_id, date, status, marked_by) VALUES (?,?,?,?,?) ON CONFLICT(student_id, date) DO UPDATE SET status=excluded.status, class_id=excluded.class_id, marked_by=excluded.marked_by')
          .bind(sid, classId, date, r.status, s.id);
      });
      await env.DB.batch(stmts);
      await audit(env, s.username, s.role, 'attendance_saved', `Class #${classId} on ${date} (${b.records.length} children)`, ip);
      return json({ ok: true });
    }
  }

  // ================= HOMEWORK =================
  if (root === 'homework') {
    if (m === 'GET') {
      const rows = (await env.DB.prepare(
        `SELECT h.*, c.name class_name FROM homework h JOIN classes c ON c.id=h.class_id WHERE h.deleted_at IS NULL ${q.get('class_id') ? 'AND h.class_id=?' : ''} ORDER BY h.created_at DESC LIMIT 100`
      ).bind(...(q.get('class_id') ? [int(q.get('class_id'), { min: 1, label: 'Class' })] : [])).all()).results;
      return json({ homework: rows });
    }
    if (m === 'POST') {
      const b = await readBody(request);
      const classId = int(b.class_id, { min: 1, label: 'Class' });
      const title = str(b.title, { min: 2, max: 140, label: 'Title' });
      const details = str(b.details, { max: 2000, label: 'Details', optional: true });
      const due = dateStr(b.due_date, 'Due date', true);
      const r = await env.DB.prepare('INSERT INTO homework (class_id, title, details, due_date, created_by) VALUES (?,?,?,?,?)').bind(classId, title, details, due, s.id).run();
      await audit(env, s.username, s.role, 'homework_created', title, ip);
      return json({ ok: true, id: r.meta.last_row_id });
    }
    if (m === 'PUT' && id) {
      const b = await readBody(request);
      await env.DB.prepare('UPDATE homework SET class_id=?, title=?, details=?, due_date=? WHERE id=? AND deleted_at IS NULL')
        .bind(int(b.class_id, { min: 1, label: 'Class' }), str(b.title, { min: 2, max: 140, label: 'Title' }), str(b.details, { max: 2000, label: 'Details', optional: true }), dateStr(b.due_date, 'Due date', true), id).run();
      await audit(env, s.username, s.role, 'homework_updated', `#${id}`, ip);
      return json({ ok: true });
    }
    if (m === 'DELETE' && id) {
      await env.DB.prepare("UPDATE homework SET deleted_at=datetime('now') WHERE id=?").bind(id).run();
      await audit(env, s.username, s.role, 'homework_deleted', `#${id}`, ip);
      return json({ ok: true });
    }
  }

  // ================= FEES =================
  if (root === 'fees') {
    if (m === 'GET') {
      const sid = int(q.get('student_id'), { min: 1, label: 'Student' });
      const rows = (await env.DB.prepare('SELECT * FROM fees WHERE student_id=? AND deleted_at IS NULL ORDER BY created_at DESC').bind(sid).all()).results;
      return json({ fees: rows });
    }
    if (m === 'POST') {
      const b = await readBody(request);
      const sid = int(b.student_id, { min: 1, label: 'Student' });
      const title = str(b.title, { min: 2, max: 100, label: 'Fee title' });
      const amount = num(b.amount, { min: 0, max: 1_000_000, label: 'Amount' });
      const due = dateStr(b.due_date, 'Due date', true);
      const note = str(b.note, { max: 300, label: 'Note', optional: true });
      const status = b.status === 'paid' ? 'paid' : 'due';
      const paidOn = status === 'paid' ? (dateStr(b.paid_on, 'Paid on', true) || new Date().toISOString().slice(0, 10)) : null;
      const r = await env.DB.prepare('INSERT INTO fees (student_id, title, amount, due_date, status, paid_on, note) VALUES (?,?,?,?,?,?,?)').bind(sid, title, amount, due, status, paidOn, note).run();
      await audit(env, s.username, s.role, 'fee_added', `${title} ₹${amount} for student #${sid}`, ip);
      return json({ ok: true, id: r.meta.last_row_id });
    }
    if (m === 'PUT' && id) {
      const f = (await env.DB.prepare('SELECT * FROM fees WHERE id=? AND deleted_at IS NULL').bind(id).all()).results[0];
      if (!f) err(404, 'Fee record not found.');
      const b = await readBody(request);
      const status = b.status === 'paid' ? 'paid' : 'due';
      const paidOn = status === 'paid' ? (dateStr(b.paid_on, 'Paid on', true) || f.paid_on || new Date().toISOString().slice(0, 10)) : null;
      await env.DB.prepare('UPDATE fees SET title=?, amount=?, due_date=?, status=?, paid_on=?, note=? WHERE id=?')
        .bind(str(b.title, { min: 2, max: 100, label: 'Fee title' }), num(b.amount, { min: 0, max: 1_000_000, label: 'Amount' }), dateStr(b.due_date, 'Due date', true), status, paidOn, str(b.note, { max: 300, label: 'Note', optional: true }), id).run();
      await audit(env, s.username, s.role, 'fee_updated', `#${id} → ${status}`, ip);
      return json({ ok: true });
    }
    if (m === 'DELETE' && id) {
      await env.DB.prepare("UPDATE fees SET deleted_at=datetime('now') WHERE id=?").bind(id).run();
      await audit(env, s.username, s.role, 'fee_deleted', `#${id}`, ip);
      return json({ ok: true });
    }
  }

  // ================= RESULTS =================
  if (root === 'results') {
    if (m === 'GET') {
      const sid = int(q.get('student_id'), { min: 1, label: 'Student' });
      const rows = (await env.DB.prepare('SELECT * FROM results WHERE student_id=? AND deleted_at IS NULL ORDER BY created_at DESC, subject').bind(sid).all()).results;
      return json({ results: rows });
    }
    if (m === 'POST' && !id && idPart !== 'bulk') {
      const b = await readBody(request);
      const r = await env.DB.prepare('INSERT INTO results (student_id, exam, subject, marks, max_marks, term) VALUES (?,?,?,?,?,?)')
        .bind(int(b.student_id, { min: 1, label: 'Student' }), str(b.exam, { min: 1, max: 80, label: 'Exam' }), str(b.subject, { min: 1, max: 60, label: 'Subject' }),
          num(b.marks, { min: 0, max: 1000, label: 'Marks' }), num(b.max_marks, { min: 1, max: 1000, label: 'Maximum marks' }), str(b.term, { max: 40, label: 'Term', optional: true })).run();
      await audit(env, s.username, s.role, 'result_added', `Student #${b.student_id}: ${b.exam} / ${b.subject}`, ip);
      return json({ ok: true, id: r.meta.last_row_id });
    }
    if (m === 'POST' && idPart === 'bulk') {
      const b = await readBody(request);
      const classId = int(b.class_id, { min: 1, label: 'Class' });
      const exam = str(b.exam, { min: 1, max: 80, label: 'Exam' });
      const subject = str(b.subject, { min: 1, max: 60, label: 'Subject' });
      const maxMarks = num(b.max_marks, { min: 1, max: 1000, label: 'Maximum marks' });
      const term = str(b.term, { max: 40, label: 'Term', optional: true });
      if (!Array.isArray(b.entries) || b.entries.length === 0 || b.entries.length > 100) err(400, 'Entries are invalid.');
      const stmts = b.entries.map((e) => env.DB.prepare('INSERT INTO results (student_id, exam, subject, marks, max_marks, term) VALUES (?,?,?,?,?,?)')
        .bind(int(e.student_id, { min: 1, label: 'Student' }), exam, subject, num(e.marks, { min: 0, max: 1000, label: 'Marks' }), maxMarks, term));
      await env.DB.batch(stmts);
      await audit(env, s.username, s.role, 'results_bulk', `Class #${classId}: ${exam} / ${subject} (${b.entries.length})`, ip);
      return json({ ok: true });
    }
    if (m === 'DELETE' && id) {
      await env.DB.prepare("UPDATE results SET deleted_at=datetime('now') WHERE id=?").bind(id).run();
      await audit(env, s.username, s.role, 'result_deleted', `#${id}`, ip);
      return json({ ok: true });
    }
  }

  // ================= GALLERY =================
  if (root === 'gallery') {
    if (m === 'GET') {
      const rows = (await env.DB.prepare('SELECT * FROM gallery WHERE deleted_at IS NULL ORDER BY sort_order ASC, id ASC').all()).results;
      return json({ gallery: rows });
    }
    if (m === 'POST') {
      const b = await readBody(request);
      const imageId = await saveImage(env, b.image);
      const r = await env.DB.prepare('INSERT INTO gallery (image_id, title, caption, photo_date, sort_order, published) VALUES (?,?,?,?,?,?)')
        .bind(imageId, str(b.title, { min: 1, max: 120, label: 'Event title' }), str(b.caption, { max: 300, label: 'Caption', optional: true }),
          dateStr(b.photo_date, 'Photo date', true), int(b.sort_order ?? 0, { min: 0, max: 9999, label: 'Order' }), bool(b.published) ? 1 : 0).run();
      await audit(env, s.username, s.role, 'gallery_added', b.title, ip);
      return json({ ok: true, id: r.meta.last_row_id, image_id: imageId });
    }
    if (m === 'PUT' && id) {
      const g = (await env.DB.prepare('SELECT * FROM gallery WHERE id=? AND deleted_at IS NULL').bind(id).all()).results[0];
      if (!g) err(404, 'Photo not found.');
      const b = await readBody(request);
      let imageId = g.image_id;
      if (b.image) imageId = await saveImage(env, b.image);
      await env.DB.prepare('UPDATE gallery SET image_id=?, title=?, caption=?, photo_date=?, sort_order=?, published=? WHERE id=?')
        .bind(imageId, str(b.title, { min: 1, max: 120, label: 'Event title' }), str(b.caption, { max: 300, label: 'Caption', optional: true }),
          dateStr(b.photo_date, 'Photo date', true), int(b.sort_order ?? 0, { min: 0, max: 9999, label: 'Order' }), bool(b.published) ? 1 : 0, id).run();
      if (imageId !== g.image_id) await deleteImageIfUnused(env, g.image_id);
      await audit(env, s.username, s.role, 'gallery_updated', `#${id}`, ip);
      return json({ ok: true });
    }
    if (m === 'DELETE' && id) {
      const g = (await env.DB.prepare('SELECT image_id FROM gallery WHERE id=? AND deleted_at IS NULL').bind(id).all()).results[0];
      if (!g) err(404, 'Photo not found.');
      await env.DB.prepare("UPDATE gallery SET deleted_at=datetime('now'), published=0 WHERE id=?").bind(id).run();
      await deleteImageIfUnused(env, g.image_id);
      await audit(env, s.username, s.role, 'gallery_deleted', `#${id}`, ip);
      return json({ ok: true });
    }
  }

  // ================= NOTICES =================
  if (root === 'notices') {
    if (m === 'GET') {
      const rows = (await env.DB.prepare('SELECT * FROM notices WHERE deleted_at IS NULL ORDER BY pinned DESC, created_at DESC LIMIT 200').all()).results;
      return json({ notices: rows, server_time: nowSec() });
    }
    if (m === 'POST') {
      const b = await readBody(request);
      const status = b.status === 'published' ? 'published' : 'draft';
      const publishAt = toEpoch(b.publish_at) ?? (status === 'published' ? nowSec() : null);
      const r = await env.DB.prepare('INSERT INTO notices (title, body, pinned, status, publish_at, expires_at) VALUES (?,?,?,?,?,?)')
        .bind(str(b.title, { min: 2, max: 140, label: 'Title' }), str(b.body, { max: 2000, label: 'Notice text', optional: true }),
          bool(b.pinned) ? 1 : 0, status, publishAt, toEpoch(b.expires_at)).run();
      await audit(env, s.username, s.role, 'notice_created', b.title, ip);
      return json({ ok: true, id: r.meta.last_row_id });
    }
    if (m === 'PUT' && id) {
      const b = await readBody(request);
      const status = b.status === 'published' ? 'published' : 'draft';
      const publishAt = toEpoch(b.publish_at) ?? (status === 'published' ? nowSec() : null);
      await env.DB.prepare("UPDATE notices SET title=?, body=?, pinned=?, status=?, publish_at=?, expires_at=?, updated_at=datetime('now') WHERE id=? AND deleted_at IS NULL")
        .bind(str(b.title, { min: 2, max: 140, label: 'Title' }), str(b.body, { max: 2000, label: 'Notice text', optional: true }),
          bool(b.pinned) ? 1 : 0, status, publishAt, toEpoch(b.expires_at), id).run();
      await audit(env, s.username, s.role, 'notice_updated', `#${id}`, ip);
      return json({ ok: true });
    }
    if (m === 'DELETE' && id) {
      await env.DB.prepare("UPDATE notices SET deleted_at=datetime('now') WHERE id=?").bind(id).run();
      await audit(env, s.username, s.role, 'notice_deleted', `#${id}`, ip);
      return json({ ok: true });
    }
  }

  // ================= WEBSITE CONTENT =================
  if (root === 'content' && m === 'GET') {
    const all = await getSettings(env);
    const keySet = Boolean(all.gemini_api_key);
    const masked = keySet ? '••••••••' + String(all.gemini_api_key).slice(-4) : '';
    delete all.gemini_api_key;
    const tsSet = Boolean(all.turnstile_secret);
    delete all.turnstile_secret;
    return json({ settings: all, ai_key_set: keySet, ai_key_masked: masked, turnstile_secret_set: tsSet });
  }
  if (root === 'content' && m === 'PUT') {
    const b = await readBody(request);
    const out = {};
    const textKeys = {
      school_name: 100, slogan: 120, slogan_hi: 120, hero_subtitle: 300, about: 3000,
      director_name: 80, director_role: 140, director_message: 2000,
      principal_name: 80, principal_role: 140, principal_message: 2000,
      contact_phone: 25, contact_email: 120, address: 300, maps_url: 500, maps_embed: 1000,
      announcement_text: 300, footer_note: 200,
    };
    for (const [k, max] of Object.entries(textKeys)) if (k in b) out[k] = str(b[k], { max, label: k, optional: true });
    if ('contact_email' in out && out.contact_email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(out.contact_email)) err(400, 'Email address looks invalid.');
    for (const k of ['maps_url', 'maps_embed']) if (k in out && out[k] && !/^https:\/\//.test(out[k])) err(400, `${k} must be an https:// link.`);
    if (out.maps_embed && !/^https:\/\/www\.google\.com\/maps\/embed/.test(out.maps_embed)) err(400, 'Map embed must be a Google Maps embed link (https://www.google.com/maps/embed…).');
    if ('announcement_enabled' in b) out.announcement_enabled = bool(b.announcement_enabled);
    if ('philosophy' in b) out.philosophy = arrItems(b.philosophy, 8, (p) => ({ title: str(p.title, { min: 1, max: 80, label: 'Pillar title' }), text: str(p.text, { max: 400, label: 'Pillar text', optional: true }) }));
    if ('activities' in b) out.activities = arrItems(b.activities, 12, (p) => ({ icon: str(p.icon, { max: 20, label: 'Icon', optional: true }) || 'star', title: str(p.title, { min: 1, max: 80, label: 'Activity title' }), text: str(p.text, { max: 300, label: 'Activity text', optional: true }) }));
    if ('facilities' in b) out.facilities = arrItems(b.facilities, 10, (f) => str(f, { min: 1, max: 120, label: 'Facility' }));
    if ('turnstile_site_key' in b || 'turnstile_secret' in b) {
      onlyAdmin();
      if ('turnstile_site_key' in b) out.turnstile_site_key = str(b.turnstile_site_key, { max: 200, label: 'Turnstile site key', optional: true });
      if ('turnstile_secret' in b && b.turnstile_secret !== null) out.turnstile_secret = str(b.turnstile_secret, { max: 200, label: 'Turnstile secret', optional: true });
    }
    if (Object.keys(out).length === 0) err(400, 'Nothing to update.');
    await setSettings(env, out);
    await audit(env, s.username, s.role, 'content_updated', Object.keys(out).join(', '), ip);
    return json({ ok: true });
  }
  if (root === 'logo' && m === 'POST') {
    const b = await readBody(request);
    const old = (await getSettings(env, ['logo_image_id'])).logo_image_id;
    const imageId = await saveImage(env, b.image);
    await setSettings(env, { logo_image_id: imageId });
    if (old) await deleteImageIfUnused(env, old);
    await audit(env, s.username, s.role, 'logo_updated', 'School logo replaced', ip);
    return json({ ok: true, image_id: imageId });
  }
  if (root === 'logo' && m === 'DELETE') {
    const old = (await getSettings(env, ['logo_image_id'])).logo_image_id;
    await setSettings(env, { logo_image_id: '' });
    if (old) await deleteImageIfUnused(env, old);
    await audit(env, s.username, s.role, 'logo_reset', 'Default logo restored', ip);
    return json({ ok: true });
  }

  // ================= INQUIRIES =================
  if (root === 'inquiries') {
    if (m === 'GET') return json({ inquiries: (await env.DB.prepare('SELECT * FROM inquiries ORDER BY created_at DESC LIMIT 300').all()).results });
    if (m === 'PUT' && id) {
      const b = await readBody(request);
      if (!['new', 'read', 'archived'].includes(b.status)) err(400, 'Invalid status.');
      await env.DB.prepare('UPDATE inquiries SET status=? WHERE id=?').bind(b.status, id).run();
      return json({ ok: true });
    }
    if (m === 'DELETE' && id) {
      await env.DB.prepare('DELETE FROM inquiries WHERE id=?').bind(id).run();
      await audit(env, s.username, s.role, 'inquiry_deleted', `#${id}`, ip);
      return json({ ok: true });
    }
  }

  // ================= ADMIN ACCOUNTS (primary admin only) =================
  if (root === 'admins') {
    onlyAdmin();
    if (m === 'GET') return json({ admins: (await env.DB.prepare("SELECT id, username, name, role, active, created_at, last_login FROM users WHERE role IN ('admin','coadmin') ORDER BY id").all()).results });
    if (m === 'POST') {
      const b = await readBody(request);
      const username = str(b.username, { min: 3, max: 32, label: 'Username' }); validateUsername(username);
      validatePassword(b.password);
      const name = str(b.name, { min: 2, max: 80, label: 'Name' });
      try {
        const r = await env.DB.prepare("INSERT INTO users (role, username, password_hash, name) VALUES ('coadmin',?,?,?)").bind(username, await hashPassword(b.password), name).run();
        await audit(env, s.username, s.role, 'coadmin_created', username, ip);
        return json({ ok: true, id: r.meta.last_row_id });
      } catch (e) { if (String(e.message).includes('UNIQUE')) err(409, 'That username is already taken.'); throw e; }
    }
    if (m === 'PUT' && id) {
      const t = (await env.DB.prepare('SELECT * FROM users WHERE id=?').bind(id).all()).results[0];
      if (!t || t.role !== 'coadmin') err(400, 'Only co-admin accounts can be modified here.');
      const b = await readBody(request);
      const active = bool(b.active) ? 1 : 0;
      const name = str(b.name, { min: 2, max: 80, label: 'Name' });
      await env.DB.prepare('UPDATE users SET name=?, active=? WHERE id=?').bind(name, active, id).run();
      if (b.password) { validatePassword(b.password); await env.DB.prepare('UPDATE users SET password_hash=?, failed_attempts=0, locked_until=0 WHERE id=?').bind(await hashPassword(b.password), id).run(); await revokeSessions(env, 'staff', id); }
      if (!active) await revokeSessions(env, 'staff', id);
      await audit(env, s.username, s.role, 'coadmin_updated', t.username, ip);
      return json({ ok: true });
    }
    if (m === 'DELETE' && id) {
      const t = (await env.DB.prepare('SELECT * FROM users WHERE id=?').bind(id).all()).results[0];
      if (!t || t.role !== 'coadmin') err(400, 'Only co-admin accounts can be removed.');
      await env.DB.prepare('DELETE FROM users WHERE id=?').bind(id).run();
      await revokeSessions(env, 'staff', id);
      await audit(env, s.username, s.role, 'coadmin_deleted', t.username, ip);
      return json({ ok: true });
    }
  }

  // ================= AI SETTINGS (primary admin only) =================
  if (root === 'ai') {
    onlyAdmin();
    if (m === 'GET') {
      const a = await getSettings(env, ['ai_enabled', 'gemini_model', 'ai_daily_cap', 'gemini_api_key']);
      return json({ ai_enabled: Boolean(a.ai_enabled), model: a.gemini_model || 'gemini-3.5-flash', daily_cap: a.ai_daily_cap || 150, key_set: Boolean(a.gemini_api_key), key_masked: a.gemini_api_key ? '••••••••' + String(a.gemini_api_key).slice(-4) : '' });
    }
    if (m === 'PUT') {
      const b = await readBody(request);
      const out = {};
      if ('ai_enabled' in b) out.ai_enabled = bool(b.ai_enabled);
      if ('model' in b) { const mm = str(b.model, { min: 3, max: 60, label: 'Model' }); if (!/^[a-zA-Z0-9.\-]+$/.test(mm)) err(400, 'Model name is invalid.'); out.gemini_model = mm; }
      if ('daily_cap' in b) out.ai_daily_cap = int(b.daily_cap, { min: 10, max: 2000, label: 'Daily cap' });
      if (typeof b.api_key === 'string') {
        const k = b.api_key.trim();
        if (k && (k.length < 20 || k.length > 200)) err(400, 'That API key looks invalid.');
        out.gemini_api_key = k;
      }
      if (Object.keys(out).length === 0) err(400, 'Nothing to update.');
      await setSettings(env, out);
      await audit(env, s.username, s.role, 'ai_settings_updated', Object.keys(out).map((k) => k === 'gemini_api_key' ? 'gemini_api_key (value hidden)' : k).join(', '), ip);
      return json({ ok: true });
    }
    if (m === 'POST' && idPart === 'test') {
      if (!(await rateLimit(env, `aitest:${s.id}`, 8, 600))) err(429, 'Too many tests. Please wait a few minutes.');
      const b = await readBody(request);
      const stored = await getSettings(env, ['gemini_api_key', 'gemini_model']);
      const key = (typeof b.api_key === 'string' && b.api_key.trim()) ? b.api_key.trim() : stored.gemini_api_key;
      if (!key) err(400, 'No API key saved yet. Paste a key first.');
      const result = await testGemini(key, b.model || stored.gemini_model);
      await audit(env, s.username, s.role, 'ai_test', result.ok ? 'success' : `failed: ${result.error}`, ip);
      return json(result);
    }
  }

  // ================= AUDIT & HEALTH =================
  if (root === 'audit' && m === 'GET') {
    onlyAdmin();
    const rows = (await env.DB.prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 200').all()).results;
    return json({ logs: rows });
  }
  if (root === 'health' && m === 'GET') {
    const r = await env.DB.batch([
      env.DB.prepare('SELECT COUNT(*) c FROM students WHERE deleted_at IS NULL'),
      env.DB.prepare('SELECT COUNT(*) c FROM images'),
      env.DB.prepare('SELECT COALESCE(SUM(size),0) b FROM images'),
      env.DB.prepare('SELECT COUNT(*) c FROM sessions WHERE expires_at > ?').bind(nowSec()),
      env.DB.prepare('SELECT COUNT(*) c FROM audit_logs'),
      env.DB.prepare('SELECT COUNT(*) c FROM notices WHERE deleted_at IS NULL'),
      env.DB.prepare('SELECT COUNT(*) c FROM gallery WHERE deleted_at IS NULL'),
    ]);
    let dbSize = null;
    try { const p = (await env.DB.prepare('SELECT page_count * page_size AS s FROM pragma_page_count(), pragma_page_size()').all()).results[0]; dbSize = p?.s ?? null; } catch { /* not supported */ }
    return json({
      students: r[0].results[0].c, images: r[1].results[0].c, media_bytes: r[2].results[0].b,
      active_sessions: r[3].results[0].c, audit_entries: r[4].results[0].c,
      notices: r[5].results[0].c, gallery_items: r[6].results[0].c, db_bytes: dbSize,
      free_tier: { d1_reads_per_day: 5_000_000, d1_writes_per_day: 100_000, d1_storage_gb: 5, workers_requests_per_day: 100_000 },
    });
  }

  err(404, 'Not found.');
}

async function studentFields(env, b, required) {
  const name = str(b.name, { min: 2, max: 80, label: 'Student name' });
  const admission_no = str(b.admission_no, { min: 2, max: 30, label: 'Admission number' });
  if (!/^[A-Za-z0-9/_-]+$/.test(admission_no)) err(400, 'Admission number can only contain letters, numbers, / _ -');
  const class_id = int(b.class_id, { min: 1, label: 'Class' });
  const cls = (await env.DB.prepare('SELECT id FROM classes WHERE id=? AND active=1').bind(class_id).all()).results[0];
  if (!cls) err(400, 'Please choose a valid class.');
  const dob = dateStr(b.dob, 'Date of birth');
  return {
    name, admission_no, class_id, dob,
    guardian_name: str(b.guardian_name, { max: 80, label: 'Guardian name', optional: true }),
    guardian_phone: b.guardian_phone ? phoneStr(b.guardian_phone, 'Guardian phone') : '',
    address: str(b.address, { max: 250, label: 'Address', optional: true }),
    admission_date: dateStr(b.admission_date, 'Admission date', true) || new Date().toISOString().slice(0, 10),
    notes: str(b.notes, { max: 1000, label: 'Notes', optional: true }),
  };
}
async function validClassIds(env, ids) {
  if (!Array.isArray(ids)) return [];
  const clean = [...new Set(ids.map((x) => int(x, { min: 1, label: 'Class' })))].slice(0, 20);
  if (!clean.length) return [];
  const rows = (await env.DB.prepare(`SELECT id FROM classes WHERE active=1 AND id IN (${clean.map(() => '?').join(',')})`).bind(...clean).all()).results;
  return rows.map((r) => r.id);
}
function arrItems(v, max, fn) {
  if (!Array.isArray(v)) err(400, 'Expected a list.');
  if (v.length > max) err(400, `Too many items (max ${max}).`);
  return v.map(fn);
}
