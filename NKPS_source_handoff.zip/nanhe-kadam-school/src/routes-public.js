// Public (unauthenticated) API: website content, gallery, notices, inquiries, AI assistant, images.
import { json, err, readBody, str, phoneStr, clientIp, nowSec, sha256Hex, getSettings, audit } from './util.js';
import { verifyTurnstile, rateLimit } from './auth.js';
import { askGemini } from './gemini.js';

const PUBLIC_KEYS = [
  'school_name', 'slogan', 'slogan_hi', 'hero_subtitle', 'about',
  'director_name', 'director_role', 'director_message',
  'principal_name', 'principal_role', 'principal_message',
  'philosophy', 'activities', 'facilities',
  'contact_phone', 'contact_email', 'address', 'maps_url', 'maps_embed',
  'announcement_enabled', 'announcement_text', 'ai_enabled', 'turnstile_site_key',
  'logo_image_id', 'footer_note', 'content_version',
];

export async function handlePublic(request, env, path, ctx) {
  const ip = clientIp(request);
  const method = request.method;

  if (path === '/api/public/content' && method === 'GET') {
    const settings = await getSettings(env, PUBLIC_KEYS);
    const now = nowSec();
    const gallery = (await env.DB.prepare(
      'SELECT id, image_id, title, caption, photo_date FROM gallery WHERE published=1 AND deleted_at IS NULL ORDER BY sort_order ASC, id ASC LIMIT 4'
    ).all()).results;
    const notices = (await env.DB.prepare(
      `SELECT id, title, body, pinned, publish_at FROM notices
       WHERE status='published' AND deleted_at IS NULL
         AND (publish_at IS NULL OR publish_at <= ?)
         AND (expires_at IS NULL OR expires_at > ?)
       ORDER BY pinned DESC, publish_at DESC, id DESC LIMIT 10`
    ).bind(now, now).all()).results;
    const body = { settings, gallery, notices, server_time: now };
    // ETag covers content only (not server_time) so unchanged content revalidates with 304.
    const etag = '"' + (await sha256Hex(JSON.stringify({ settings, gallery, notices }))).slice(0, 32) + '"';
    if (request.headers.get('If-None-Match') === etag) return new Response(null, { status: 304, headers: { ETag: etag, 'Cache-Control': 'no-cache' } });
    return json(body, 200, { ETag: etag, 'Cache-Control': 'no-cache' });
  }

  if (path === '/api/public/inquiry' && method === 'POST') {
    if (!(await rateLimit(env, `inquiry:${ip}`, 4, 3600))) err(429, 'You have sent several enquiries already. Please call the school office instead.');
    const b = await readBody(request);
    const parent_name = str(b.parent_name, { min: 2, max: 80, label: 'Parent name' });
    const phone = phoneStr(b.phone, 'Contact number');
    const child_age = str(b.child_age, { max: 20, label: "Child's age", optional: true });
    const message = str(b.message, { max: 1000, label: 'Message', optional: true });
    if (!(await verifyTurnstile(env, b.turnstile, ip))) err(400, 'Bot verification failed. Please try again.');
    await env.DB.prepare('INSERT INTO inquiries (parent_name, phone, child_age, message) VALUES (?,?,?,?)')
      .bind(parent_name, phone, child_age, message).run();
    await audit(env, parent_name, 'public', 'inquiry', `New enquiry from ${phone}`, ip);
    return json({ ok: true, message: 'Thank you! The school office will contact you soon.' });
  }

  if (path === '/api/public/assistant' && method === 'POST') {
    const s = await getSettings(env, ['ai_enabled', 'gemini_api_key', 'gemini_model', 'ai_daily_cap', 'contact_phone', 'school_name']);
    const fallback = 'The school assistant is temporarily unavailable. Please try again in a little while.';
    if (!s.ai_enabled || !s.gemini_api_key) return json({ reply: fallback, fallback: true });
    if (!(await rateLimit(env, `ai:${ip}`, 8, 60))) err(429, 'You are sending messages too quickly. Please wait a minute.');
    const day = Math.floor(nowSec() / 86400);
    if (!(await rateLimit(env, `ai-global:${day}`, Number(s.ai_daily_cap) || 150, 86400))) return json({ reply: fallback, fallback: true });
    const b = await readBody(request);
    const message = str(b.message, { min: 1, max: 500, label: 'Message' });
    let history = Array.isArray(b.history) ? b.history.slice(-6) : [];
    history = history.filter((h) => h && typeof h.text === 'string' && h.text.length <= 600 && ['user', 'assistant'].includes(h.role))
      .map((h) => ({ role: h.role, text: h.text.slice(0, 600) }));
    try {
      const reply = await askGemini(env, s, message, history);
      return json({ reply });
    } catch (e) {
      console.log('Gemini error:', e.message);
      return json({ reply: fallback, fallback: true });
    }
  }

  err(404, 'Not found.');
}

export async function serveImage(request, env, path) {
  const id = path.slice('/img/'.length).replace(/[^A-Za-z0-9_-]/g, '');
  if (!id || id.length > 40) err(404, 'Image not found.');
  const row = (await env.DB.prepare('SELECT mime, data FROM images WHERE id=?').bind(id).all()).results[0];
  if (!row) err(404, 'Image not found.');
  // D1 returns BLOBs as number[] (or ArrayBuffer depending on runtime) — normalize to bytes.
  const bytes = row.data instanceof ArrayBuffer ? new Uint8Array(row.data) : Uint8Array.from(row.data);
  return new Response(request.method === 'HEAD' ? null : bytes, {
    headers: {
      'Content-Type': row.mime,
      'Cache-Control': 'public, max-age=31536000, immutable',
      ETag: `"${id}"`,
    },
  });
}
