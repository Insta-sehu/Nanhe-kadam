// Shared helpers — no external dependencies.
export class ApiError extends Error {
  constructor(status, message, code) { super(message); this.status = status; this.code = code || undefined; }
}
export const err = (status, message, code) => { throw new ApiError(status, message, code); };

export function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers },
  });
}

export const nowSec = () => Math.floor(Date.now() / 1000);

export function clientIp(request) {
  return request.headers.get('CF-Connecting-IP') || request.headers.get('X-Forwarded-For')?.split(',')[0]?.trim() || '0.0.0.0';
}

export async function readBody(request, maxBytes = 2_500_000) {
  const len = Number(request.headers.get('Content-Length') || 0);
  if (len > maxBytes) err(413, 'Request too large.');
  const text = await request.text();
  if (text.length > maxBytes) err(413, 'Request too large.');
  try { return JSON.parse(text || '{}'); } catch { err(400, 'Invalid JSON body.'); }
}

// ---- validation helpers ----
export function str(v, { min = 0, max = 500, label = 'Field', optional = false } = {}) {
  if (v === undefined || v === null || v === '') {
    if (optional) return '';
    if (min > 0) err(400, `${label} is required.`);
    return '';
  }
  if (typeof v !== 'string') err(400, `${label} must be text.`);
  const t = v.trim();
  if (t.length < min) err(400, `${label} is too short.`);
  if (t.length > max) err(400, `${label} is too long (max ${max} characters).`);
  return t;
}
export function int(v, { min = 0, max = 1_000_000, label = 'Value', optional = false } = {}) {
  if (v === undefined || v === null || v === '') { if (optional) return null; err(400, `${label} is required.`); }
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) err(400, `${label} is invalid.`);
  return n;
}
export function num(v, { min = 0, max = 10_000_000, label = 'Value' } = {}) {
  const n = Number(v);
  if (!Number.isFinite(n) || n < min || n > max) err(400, `${label} is invalid.`);
  return n;
}
export const isDate = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s));
export function dateStr(v, label = 'Date', optional = false) {
  if (!v) { if (optional) return null; err(400, `${label} is required.`); }
  if (!isDate(v)) err(400, `${label} must be a valid date (YYYY-MM-DD).`);
  return v;
}
export function phoneStr(v, label = 'Phone number') {
  const t = str(v, { min: 8, max: 18, label });
  if (!/^\+?[0-9 ()-]{8,18}$/.test(t)) err(400, `${label} looks invalid.`);
  return t;
}
export function bool(v) { return v === true || v === 1 || v === '1' || v === 'true'; }

// ---- encoding ----
const te = new TextEncoder();
export const bytesOf = (s) => te.encode(s);
export function b64url(bytes) {
  let s = ''; const a = new Uint8Array(bytes);
  for (let i = 0; i < a.length; i++) s += String.fromCharCode(a[i]);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function b64ToBytes(b64) {
  const s = atob(b64.replace(/-/g, '+').replace(/_/g, '/'));
  const a = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) a[i] = s.charCodeAt(i);
  return a;
}
export async function sha256Hex(input) {
  const data = typeof input === 'string' ? bytesOf(input) : input;
  const digest = await crypto.subtle.digest('SHA-256', data);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}
export function randId(bytes = 16) { return b64url(crypto.getRandomValues(new Uint8Array(bytes))); }

export function parseCookies(request) {
  const out = {};
  const h = request.headers.get('Cookie') || '';
  for (const part of h.split(';')) {
    const i = part.indexOf('=');
    if (i > -1) out[part.slice(0, i).trim()] = part.slice(i + 1).trim();
  }
  return out;
}
export function sessionCookie(request, token, maxAge) {
  const secure = new URL(request.url).protocol === 'https:' ? '; Secure' : '';
  return `nkps_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secure}`;
}

// ---- settings ----
export async function getSettings(env, keys) {
  const rows = keys
    ? (await env.DB.prepare(`SELECT key, value FROM settings WHERE key IN (${keys.map(() => '?').join(',')})`).bind(...keys).all()).results
    : (await env.DB.prepare('SELECT key, value FROM settings').all()).results;
  const out = {};
  for (const r of rows) { try { out[r.key] = JSON.parse(r.value); } catch { out[r.key] = r.value; } }
  return out;
}
export async function setSettings(env, obj) {
  const stmts = Object.entries(obj).map(([k, v]) =>
    env.DB.prepare("INSERT INTO settings (key, value, updated_at) VALUES (?,?,datetime('now')) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime('now')").bind(k, JSON.stringify(v))
  );
  stmts.push(env.DB.prepare("UPDATE settings SET value = CAST(CAST(value AS INTEGER) + 1 AS TEXT), updated_at = datetime('now') WHERE key='content_version'"));
  await env.DB.batch(stmts);
}

// ---- images ----
const MAGIC = [
  { mime: 'image/jpeg', test: (b) => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { mime: 'image/png', test: (b) => b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 },
  { mime: 'image/webp', test: (b) => b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50 },
];
export async function saveImage(env, dataUrl, maxBytes = 900_000) {
  if (typeof dataUrl !== 'string') err(400, 'Image data is required.');
  const m = dataUrl.match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/);
  if (!m) err(400, 'Image must be a JPEG, PNG or WebP data URL.');
  let bytes;
  try { bytes = b64ToBytes(m[2]); } catch { err(400, 'Image data is corrupted.'); }
  if (bytes.length === 0 || bytes.length > maxBytes) err(413, `Image is too large (max ${Math.round(maxBytes / 1024)} KB). It is compressed automatically — try a smaller photo.`);
  const magic = MAGIC.find((x) => x.test(bytes));
  if (!magic || magic.mime !== m[1]) err(400, 'Image content does not match its type.');
  const id = randId(12);
  await env.DB.prepare('INSERT INTO images (id, mime, size, data) VALUES (?,?,?,?)').bind(id, magic.mime, bytes.length, bytes).run();
  return id;
}
export async function deleteImageIfUnused(env, id) {
  if (!id) return;
  const uses = await env.DB.batch([
    env.DB.prepare('SELECT COUNT(*) c FROM gallery WHERE image_id=? AND deleted_at IS NULL').bind(id),
    env.DB.prepare('SELECT COUNT(*) c FROM students WHERE photo_id=? AND deleted_at IS NULL').bind(id),
    env.DB.prepare("SELECT value FROM settings WHERE key='logo_image_id'"),
  ]);
  const logo = uses[2].results[0] ? JSON.parse(uses[2].results[0].value) : '';
  if (uses[0].results[0].c === 0 && uses[1].results[0].c === 0 && logo !== id) {
    await env.DB.prepare('DELETE FROM images WHERE id=?').bind(id).run();
  }
}

export async function audit(env, actor, role, action, detail, ip) {
  try {
    await env.DB.prepare('INSERT INTO audit_logs (actor, role, action, detail, ip) VALUES (?,?,?,?,?)')
      .bind(String(actor || 'system').slice(0, 80), String(role || '').slice(0, 20), String(action).slice(0, 80), String(detail || '').slice(0, 500), String(ip || '').slice(0, 60)).run();
  } catch (e) { console.log('audit failed', e.message); }
}
