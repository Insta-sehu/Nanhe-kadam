// Authentication, sessions, rate limiting, Turnstile.
// Passwords: PBKDF2-SHA256 (100k iterations, per-user random salt) via WebCrypto.
// Sessions: opaque 256-bit random tokens; only their SHA-256 hash is stored in D1.
import { ApiError, err, nowSec, sha256Hex, b64url, b64ToBytes, bytesOf, parseCookies, sessionCookie, clientIp, getSettings } from './util.js';

const ITERATIONS = 100_000;
export const SESSION_COOKIE = 'nkps_session';
const STAFF_TTL = 12 * 3600;       // 12 hours
const PARENT_TTL = 7 * 24 * 3600;  // 7 days

export async function hashPassword(password, iterations = ITERATIONS) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey('raw', bytesOf(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256);
  return `pbkdf2:${iterations}:${b64url(salt)}:${b64url(bits)}`;
}
export async function verifyPassword(password, stored) {
  try {
    const [scheme, iterStr, saltB64, hashB64] = String(stored).split(':');
    if (scheme !== 'pbkdf2') return false;
    const iterations = Number(iterStr);
    if (!Number.isInteger(iterations) || iterations < 1000 || iterations > 2_000_000) return false;
    const salt = b64ToBytes(saltB64);
    const key = await crypto.subtle.importKey('raw', bytesOf(password), 'PBKDF2', false, ['deriveBits']);
    const bits = new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256));
    const expected = b64ToBytes(hashB64);
    if (bits.length !== expected.length) return false;
    let diff = 0;
    for (let i = 0; i < bits.length; i++) diff |= bits[i] ^ expected[i];
    return diff === 0;
  } catch { return false; }
}

export function validatePassword(pw) {
  if (typeof pw !== 'string' || pw.length < 8 || pw.length > 128) err(400, 'Password must be 8–128 characters.');
}
export function validateUsername(u) {
  if (typeof u !== 'string' || !/^[A-Za-z0-9@._-]{3,32}$/.test(u)) err(400, 'Username must be 3–32 characters (letters, numbers, @ . _ -).');
}

// ---- sessions ----
export async function createSession(env, request, userType, userId) {
  const token = b64url(crypto.getRandomValues(new Uint8Array(32)));
  const ttl = userType === 'parent' ? PARENT_TTL : STAFF_TTL;
  const now = nowSec();
  await env.DB.batch([
    env.DB.prepare('INSERT INTO sessions (token_hash, user_type, user_id, created_at, expires_at, ip, ua) VALUES (?,?,?,?,?,?,?)')
      .bind(await sha256Hex(token), userType, userId, now, now + ttl, clientIp(request), (request.headers.get('User-Agent') || '').slice(0, 200)),
    env.DB.prepare('DELETE FROM sessions WHERE expires_at < ?').bind(now),
  ]);
  return { token, ttl };
}
export function cookieFor(request, token, ttl) { return sessionCookie(request, token, ttl); }
export function clearCookie(request) { return sessionCookie(request, '', 0); }

export async function getSession(env, request) {
  const token = parseCookies(request)[SESSION_COOKIE];
  if (!token || token.length < 20 || token.length > 100) return null;
  const hash = await sha256Hex(token);
  const s = (await env.DB.prepare('SELECT * FROM sessions WHERE token_hash=? AND expires_at > ?').bind(hash, nowSec()).all()).results[0];
  if (!s) return null;
  if (s.user_type === 'staff') {
    const u = (await env.DB.prepare('SELECT id, role, username, name, active, teacher_id FROM users WHERE id=?').bind(s.user_id).all()).results[0];
    if (!u || !u.active) return null;
    return { kind: 'staff', role: u.role, id: u.id, name: u.name, username: u.username, teacherId: u.teacher_id, tokenHash: hash };
  }
  const st = (await env.DB.prepare("SELECT id, name, admission_no, class_id, status FROM students WHERE id=? AND deleted_at IS NULL").bind(s.user_id).all()).results[0];
  if (!st || st.status !== 'active') return null;
  return { kind: 'parent', role: 'parent', id: st.id, name: st.name, studentId: st.id, tokenHash: hash };
}

export async function requireAuth(env, request, roles) {
  const s = await getSession(env, request);
  if (!s) err(401, 'Please sign in again.');
  if (roles && !roles.includes(s.role)) err(403, 'You do not have permission to do this.');
  return s;
}
export async function destroySession(env, request) {
  const token = parseCookies(request)[SESSION_COOKIE];
  if (token) await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await sha256Hex(token)).run();
}
export async function revokeSessions(env, userType, userId, exceptHash = null) {
  if (exceptHash) await env.DB.prepare('DELETE FROM sessions WHERE user_type=? AND user_id=? AND token_hash != ?').bind(userType, userId, exceptHash).run();
  else await env.DB.prepare('DELETE FROM sessions WHERE user_type=? AND user_id=?').bind(userType, userId).run();
}

// ---- CSRF: custom header required on every mutating request; Origin must match when present ----
export function csrfCheck(request) {
  const method = request.method.toUpperCase();
  if (['GET', 'HEAD', 'OPTIONS'].includes(method)) return;
  const origin = request.headers.get('Origin');
  if (origin && origin !== new URL(request.url).origin) err(403, 'Cross-origin request blocked.');
  if (request.headers.get('X-NKPS-Client') !== 'fetch') err(403, 'Missing security header.');
}

// ---- rate limiting (fixed window, stored in D1) ----
export async function rateLimit(env, key, limit, windowSec) {
  const now = nowSec();
  const win = now - (now % windowSec);
  await env.DB.prepare(
    'INSERT INTO rate_limits (key, window_start, count) VALUES (?,?,1) ON CONFLICT(key) DO UPDATE SET count = CASE WHEN window_start=? THEN count+1 ELSE 1 END, window_start=?'
  ).bind(key, win, win, win).run();
  const row = (await env.DB.prepare('SELECT count FROM rate_limits WHERE key=?').bind(key).all()).results[0];
  if (Math.random() < 0.02) { try { await env.DB.prepare('DELETE FROM rate_limits WHERE window_start < ?').bind(now - 86400 * 2).run(); } catch {} }
  return (row?.count || 1) <= limit;
}

// ---- account lockout helpers ----
export function checkLock(row) {
  if (row.locked_until && row.locked_until > nowSec()) {
    const mins = Math.ceil((row.locked_until - nowSec()) / 60);
    err(429, `Too many failed attempts. Please try again in ${mins} minute${mins === 1 ? '' : 's'}.`, 'LOCKED');
  }
}
export async function recordFailure(env, table, id, current, max = 8, lockSec = 900) {
  const n = (current || 0) + 1;
  const lock = n >= max ? nowSec() + lockSec : 0;
  await env.DB.prepare(`UPDATE ${table} SET failed_attempts=?, locked_until=? WHERE id=?`).bind(n >= max ? 0 : n, lock, id).run();
}
export async function clearFailures(env, table, id) {
  await env.DB.prepare(`UPDATE ${table} SET failed_attempts=0, locked_until=0 WHERE id=?`).bind(id).run();
}

// ---- Turnstile (optional; enforced only when the owner configures keys) ----
export async function turnstileRequired(env) {
  const s = await getSettings(env, ['turnstile_secret', 'turnstile_site_key']);
  return Boolean(s.turnstile_secret && s.turnstile_site_key);
}
export async function verifyTurnstile(env, token, ip) {
  const s = await getSettings(env, ['turnstile_secret']);
  if (!s.turnstile_secret) return true; // not configured → rate limits still apply
  if (!token || typeof token !== 'string' || token.length > 2048) return false;
  try {
    const res = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ secret: s.turnstile_secret, response: token, remoteip: ip }),
      signal: AbortSignal.timeout(8000),
    });
    const data = await res.json();
    return Boolean(data.success);
  } catch { return false; }
}
