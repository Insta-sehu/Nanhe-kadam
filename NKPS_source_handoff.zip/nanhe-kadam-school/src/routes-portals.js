// Teacher portal + Parent portal APIs. Strictly scoped to the signed-in account.
import { json, err, readBody, str, int, dateStr, clientIp, nowSec, audit } from './util.js';
import { requireAuth } from './auth.js';

async function teacherClassIds(env, teacherId) {
  if (!teacherId) return [];
  return (await env.DB.prepare('SELECT class_id FROM teacher_classes WHERE teacher_id=?').bind(teacherId).all()).results.map((r) => r.class_id);
}

export async function handleTeacher(request, env, path) {
  const s = await requireAuth(env, request, ['teacher']);
  const ip = clientIp(request);
  const m = request.method;
  const seg = path.replace('/api/teacher/', '').split('/');
  const [root, idPart] = seg;
  const id = idPart && /^\d+$/.test(idPart) ? Number(idPart) : null;
  const url = new URL(request.url);
  const q = url.searchParams;
  const myClasses = await teacherClassIds(env, s.teacherId);
  const assertMyClass = (cid) => { if (!myClasses.includes(cid)) err(403, 'That class is not assigned to you.'); };

  if (root === 'me' && m === 'GET') {
    const t = (await env.DB.prepare('SELECT id, name, phone, email, qualification FROM teachers WHERE id=? AND deleted_at IS NULL').bind(s.teacherId).all()).results[0];
    const classes = myClasses.length
      ? (await env.DB.prepare(`SELECT id, name, sort_order FROM classes WHERE id IN (${myClasses.map(() => '?').join(',')}) ORDER BY sort_order`).bind(...myClasses).all()).results
      : [];
    return json({ teacher: t, classes, username: s.username });
  }

  if (root === 'students' && m === 'GET') {
    const cid = int(q.get('class_id'), { min: 1, label: 'Class' });
    assertMyClass(cid);
    const rows = (await env.DB.prepare(
      "SELECT id, name, admission_no, guardian_name, guardian_phone, photo_id FROM students WHERE class_id=? AND deleted_at IS NULL AND status='active' ORDER BY name"
    ).bind(cid).all()).results;
    return json({ students: rows });
  }

  if (root === 'attendance') {
    if (m === 'GET') {
      const cid = int(q.get('class_id'), { min: 1, label: 'Class' });
      assertMyClass(cid);
      const date = dateStr(q.get('date'), 'Date');
      const r = await env.DB.batch([
        env.DB.prepare("SELECT id, name, admission_no FROM students WHERE class_id=? AND deleted_at IS NULL AND status='active' ORDER BY name").bind(cid),
        env.DB.prepare('SELECT student_id, status FROM attendance WHERE class_id=? AND date=?').bind(cid, date),
      ]);
      return json({ students: r[0].results, attendance: r[1].results });
    }
    if (m === 'POST') {
      const b = await readBody(request);
      const cid = int(b.class_id, { min: 1, label: 'Class' });
      assertMyClass(cid);
      const date = dateStr(b.date, 'Date');
      if (!Array.isArray(b.records) || b.records.length === 0 || b.records.length > 100) err(400, 'Attendance records are invalid.');
      const valid = new Set((await env.DB.prepare("SELECT id FROM students WHERE class_id=? AND deleted_at IS NULL AND status='active'").bind(cid).all()).results.map((r) => r.id));
      const stmts = b.records.map((r) => {
        const sid = int(r.student_id, { min: 1, label: 'Student' });
        if (!valid.has(sid)) err(403, 'A student in this list is not in your class.');
        if (!['P', 'A', 'L'].includes(r.status)) err(400, 'Invalid attendance status.');
        return env.DB.prepare('INSERT INTO attendance (student_id, class_id, date, status, marked_by) VALUES (?,?,?,?,?) ON CONFLICT(student_id, date) DO UPDATE SET status=excluded.status, marked_by=excluded.marked_by')
          .bind(sid, cid, date, r.status, s.id);
      });
      await env.DB.batch(stmts);
      await audit(env, s.username, s.role, 'attendance_saved', `Class #${cid} on ${date}`, ip);
      return json({ ok: true });
    }
  }

  if (root === 'homework') {
    if (m === 'GET') {
      if (!myClasses.length) return json({ homework: [] });
      const rows = (await env.DB.prepare(
        `SELECT h.*, c.name class_name FROM homework h JOIN classes c ON c.id=h.class_id
         WHERE h.deleted_at IS NULL AND h.class_id IN (${myClasses.map(() => '?').join(',')}) ORDER BY h.created_at DESC LIMIT 100`
      ).bind(...myClasses).all()).results;
      return json({ homework: rows });
    }
    if (m === 'POST') {
      const b = await readBody(request);
      const cid = int(b.class_id, { min: 1, label: 'Class' });
      assertMyClass(cid);
      const title = str(b.title, { min: 2, max: 140, label: 'Title' });
      const r = await env.DB.prepare('INSERT INTO homework (class_id, title, details, due_date, created_by) VALUES (?,?,?,?,?)')
        .bind(cid, title, str(b.details, { max: 2000, label: 'Details', optional: true }), dateStr(b.due_date, 'Due date', true), s.id).run();
      await audit(env, s.username, s.role, 'homework_created', title, ip);
      return json({ ok: true, id: r.meta.last_row_id });
    }
    if ((m === 'PUT' || m === 'DELETE') && id) {
      const h = (await env.DB.prepare('SELECT * FROM homework WHERE id=? AND deleted_at IS NULL').bind(id).all()).results[0];
      if (!h) err(404, 'Homework not found.');
      assertMyClass(h.class_id);
      if (m === 'DELETE') {
        await env.DB.prepare("UPDATE homework SET deleted_at=datetime('now') WHERE id=?").bind(id).run();
        await audit(env, s.username, s.role, 'homework_deleted', `#${id}`, ip);
      } else {
        const b = await readBody(request);
        const cid = int(b.class_id, { min: 1, label: 'Class' });
        assertMyClass(cid);
        await env.DB.prepare('UPDATE homework SET class_id=?, title=?, details=?, due_date=? WHERE id=?')
          .bind(cid, str(b.title, { min: 2, max: 140, label: 'Title' }), str(b.details, { max: 2000, label: 'Details', optional: true }), dateStr(b.due_date, 'Due date', true), id).run();
        await audit(env, s.username, s.role, 'homework_updated', `#${id}`, ip);
      }
      return json({ ok: true });
    }
  }

  if (root === 'notices' && m === 'GET') {
    const now = nowSec();
    const rows = (await env.DB.prepare(
      `SELECT id, title, body, pinned, publish_at FROM notices WHERE status='published' AND deleted_at IS NULL
       AND (publish_at IS NULL OR publish_at<=?) AND (expires_at IS NULL OR expires_at>?) ORDER BY pinned DESC, publish_at DESC LIMIT 20`
    ).bind(now, now).all()).results;
    return json({ notices: rows });
  }

  err(404, 'Not found.');
}

export async function handleParent(request, env, path) {
  const s = await requireAuth(env, request, ['parent']);
  const m = request.method;
  if (m !== 'GET') err(405, 'Method not allowed.');
  const root = path.replace('/api/parent/', '');
  const url = new URL(request.url);
  const q = url.searchParams;
  const sid = s.studentId;

  if (root === 'overview') {
    const st = (await env.DB.prepare(
      `SELECT s.id, s.name, s.admission_no, s.dob, s.admission_date, s.guardian_name, s.guardian_phone, s.photo_id, c.name class_name
       FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.id=? AND s.deleted_at IS NULL AND s.status='active'`
    ).bind(sid).all()).results[0];
    if (!st) err(401, 'Account is no longer active.');
    const r = await env.DB.batch([
      env.DB.prepare("SELECT COUNT(*) total, SUM(CASE WHEN status='P' THEN 1 ELSE 0 END) present, SUM(CASE WHEN status='L' THEN 1 ELSE 0 END) late FROM attendance WHERE student_id=?").bind(sid),
      env.DB.prepare("SELECT COALESCE(SUM(amount),0) due FROM fees WHERE student_id=? AND status='due' AND deleted_at IS NULL").bind(sid),
      env.DB.prepare("SELECT COUNT(*) c FROM homework h JOIN students st ON st.class_id=h.class_id WHERE st.id=? AND h.deleted_at IS NULL AND (h.due_date IS NULL OR h.due_date >= date('now'))").bind(sid),
    ]);
    return json({ student: st, attendance_summary: r[0].results[0], fees_due: r[1].results[0].due, active_homework: r[2].results[0].c });
  }

  if (root === 'attendance') {
    const month = q.get('month');
    let rows;
    if (month && /^\d{4}-\d{2}$/.test(month)) {
      rows = (await env.DB.prepare('SELECT date, status FROM attendance WHERE student_id=? AND date LIKE ? ORDER BY date').bind(sid, `${month}-%`).all()).results;
    } else {
      rows = (await env.DB.prepare('SELECT date, status FROM attendance WHERE student_id=? ORDER BY date DESC LIMIT 90').all()).results;
    }
    return json({ attendance: rows });
  }

  if (root === 'homework') {
    const rows = (await env.DB.prepare(
      `SELECT h.id, h.title, h.details, h.due_date, h.created_at, c.name class_name FROM homework h
       JOIN students st ON st.class_id=h.class_id JOIN classes c ON c.id=h.class_id
       WHERE st.id=? AND h.deleted_at IS NULL ORDER BY h.created_at DESC LIMIT 30`
    ).bind(sid).all()).results;
    return json({ homework: rows });
  }

  if (root === 'fees') {
    const rows = (await env.DB.prepare('SELECT id, title, amount, due_date, status, paid_on, note FROM fees WHERE student_id=? AND deleted_at IS NULL ORDER BY created_at DESC').bind(sid).all()).results;
    return json({ fees: rows });
  }

  if (root === 'results') {
    const rows = (await env.DB.prepare('SELECT id, exam, subject, marks, max_marks, term, created_at FROM results WHERE student_id=? AND deleted_at IS NULL ORDER BY created_at DESC, subject').bind(sid).all()).results;
    return json({ results: rows });
  }

  if (root === 'notices') {
    const now = nowSec();
    const rows = (await env.DB.prepare(
      `SELECT id, title, body, pinned, publish_at FROM notices WHERE status='published' AND deleted_at IS NULL
       AND (publish_at IS NULL OR publish_at<=?) AND (expires_at IS NULL OR expires_at>?) ORDER BY pinned DESC, publish_at DESC LIMIT 20`
    ).bind(now, now).all()).results;
    return json({ notices: rows });
  }

  err(404, 'Not found.');
}
