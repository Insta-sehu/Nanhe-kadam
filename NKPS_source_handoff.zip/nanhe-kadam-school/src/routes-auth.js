// Auth routes: first-run setup, staff login, parent login, session info, password change.
import { json, err, readBody, str, clientIp, audit, dateStr, getSettings } from './util.js';
import {
  hashPassword, verifyPassword, validatePassword, validateUsername,
  createSession, cookieFor, clearCookie, getSession, requireAuth, destroySession, revokeSessions,
  rateLimit, checkLock, recordFailure, clearFailures, verifyTurnstile,
} from './auth.js';

export async function handleAuth(request, env, path) {
  const ip = clientIp(request);
  const method = request.method;

  if (path === '/api/setup-status' && method === 'GET') {
    const row = (await env.DB.prepare("SELECT COUNT(*) c FROM users WHERE role IN ('admin','coadmin')").all()).results[0];
    return json({ needed: row.c === 0 });
  }

  // One-time owner account creation. Permanently disabled once any admin exists.
  if (path === '/api/setup' && method === 'POST') {
    if (!(await rateLimit(env, `setup:${ip}`, 5, 3600))) err(429, 'Too many attempts. Try again later.');
    const row = (await env.DB.prepare("SELECT COUNT(*) c FROM users WHERE role IN ('admin','coadmin')").all()).results[0];
    if (row.c > 0) err(403, 'Setup is already complete. Please sign in.');
    const b = await readBody(request);
    const username = str(b.username, { min: 3, max: 32, label: 'Username' });
    validateUsername(username);
    validatePassword(b.password);
    const name = str(b.name, { min: 2, max: 80, label: 'Your name' });
    if (!(await verifyTurnstile(env, b.turnstile, ip))) err(400, 'Bot verification failed. Please try again.');
    const hash = await hashPassword(b.password);
    const res = await env.DB.prepare("INSERT INTO users (role, username, password_hash, name) VALUES ('admin',?,?,?)").bind(username, hash, name).run();
    const id = res.meta.last_row_id;
    await audit(env, username, 'admin', 'setup', 'Owner account created', ip);
    const s = await createSession(env, request, 'staff', id);
    return json({ ok: true, role: 'admin', name }, 200, { 'Set-Cookie': cookieFor(request, s.token, s.ttl) });
  }

  if (path === '/api/auth/login' && method === 'POST') {
    const b = await readBody(request);
    const username = str(b.username, { min: 1, max: 64, label: 'Username' });
    const password = str(b.password, { min: 1, max: 128, label: 'Password' });
    if (!(await rateLimit(env, `login:${ip}`, 12, 600))) err(429, 'Too many attempts from this connection. Please wait 10 minutes.');
    if (!(await verifyTurnstile(env, b.turnstile, ip))) err(400, 'Bot verification failed. Please try again.');
    const u = (await env.DB.prepare('SELECT * FROM users WHERE username=?').bind(username).all()).results[0];
    if (!u) { await audit(env, username, '', 'login_failed', 'Unknown username', ip); err(401, 'Username or password is incorrect.'); }
    checkLock(u);
    if (!u.active) err(403, 'This account has been deactivated. Please contact the school office.');
    if (!(await verifyPassword(password, u.password_hash))) {
      await recordFailure(env, 'users', u.id, u.failed_attempts);
      await audit(env, username, u.role, 'login_failed', 'Wrong password', ip);
      err(401, 'Username or password is incorrect.');
    }
    await clearFailures(env, 'users', u.id);
    await env.DB.prepare("UPDATE users SET last_login=datetime('now') WHERE id=?").bind(u.id).run();
    const s = await createSession(env, request, 'staff', u.id);
    await audit(env, u.username, u.role, 'login', 'Signed in', ip);
    return json({ ok: true, role: u.role, name: u.name }, 200, { 'Set-Cookie': cookieFor(request, s.token, s.ttl) });
  }

  // Parent login: admission number + child's date of birth (+ optional PIN set by school).
  if (path === '/api/auth/parent-login' && method === 'POST') {
    const b = await readBody(request);
    const adm = str(b.admission_no, { min: 1, max: 30, label: 'Admission number' });
    const dob = dateStr(b.dob, 'Date of birth');
    if (!(await rateLimit(env, `plogin:${ip}`, 15, 600))) err(429, 'Too many attempts. Please wait 10 minutes.');
    if (!(await rateLimit(env, `plogin-a:${adm.toLowerCase()}`, 8, 600))) err(429, 'Too many attempts for this admission number. Please wait 10 minutes or contact the school office.');
    if (!(await verifyTurnstile(env, b.turnstile, ip))) err(400, 'Bot verification failed. Please try again.');
    const st = (await env.DB.prepare('SELECT * FROM students WHERE admission_no=? AND deleted_at IS NULL').bind(adm).all()).results[0];
    if (!st) { await audit(env, adm, 'parent', 'parent_login_failed', 'Unknown admission number', ip); err(401, 'Admission number or date of birth does not match our records.'); }
    checkLock(st);
    if (st.status !== 'active') err(403, 'This account is not active. Please contact the school office.');
    if (st.dob !== dob) {
      await recordFailure(env, 'students', st.id, st.failed_attempts, 8, 900);
      await audit(env, adm, 'parent', 'parent_login_failed', 'Wrong date of birth', ip);
      err(401, 'Admission number or date of birth does not match our records.');
    }
    if (st.parent_pin_hash) {
      const pin = typeof b.pin === 'string' ? b.pin : '';
      if (!pin) err(401, 'A parent PIN is also required. It was shared by the school office.', 'PIN_REQUIRED');
      if (!(await verifyPassword(pin, st.parent_pin_hash))) {
        await recordFailure(env, 'students', st.id, st.failed_attempts, 8, 900);
        err(401, 'Parent PIN is incorrect.');
      }
    }
    await clearFailures(env, 'students', st.id);
    const s = await createSession(env, request, 'parent', st.id);
    await audit(env, adm, 'parent', 'parent_login', 'Parent signed in', ip);
    return json({ ok: true, role: 'parent', name: st.name }, 200, { 'Set-Cookie': cookieFor(request, s.token, s.ttl) });
  }

  if (path === '/api/auth/logout' && method === 'POST') {
    await destroySession(env, request);
    return json({ ok: true }, 200, { 'Set-Cookie': clearCookie(request) });
  }

  if (path === '/api/auth/me' && method === 'GET') {
    const s = await getSession(env, request);
    if (!s) return json({ authenticated: false });
    if (s.kind === 'parent') {
      const st = (await env.DB.prepare('SELECT s.name, s.admission_no, s.photo_id, c.name class_name FROM students s LEFT JOIN classes c ON c.id=s.class_id WHERE s.id=?').bind(s.studentId).all()).results[0];
      return json({ authenticated: true, role: 'parent', name: st.name, student: st });
    }
    return json({ authenticated: true, role: s.role, name: s.name, username: s.username });
  }

  if (path === '/api/auth/change-password' && method === 'POST') {
    const s = await requireAuth(env, request, ['admin', 'coadmin', 'teacher']);
    const b = await readBody(request);
    const current = str(b.current, { min: 1, max: 128, label: 'Current password' });
    validatePassword(b.password);
    if (!(await rateLimit(env, `pwchange:${s.id}`, 6, 600))) err(429, 'Too many attempts. Please wait a while.');
    const u = (await env.DB.prepare('SELECT password_hash FROM users WHERE id=?').bind(s.id).all()).results[0];
    if (!(await verifyPassword(current, u.password_hash))) err(401, 'Current password is incorrect.');
    await env.DB.prepare('UPDATE users SET password_hash=? WHERE id=?').bind(await hashPassword(b.password), s.id).run();
    await revokeSessions(env, 'staff', s.id);
    await audit(env, s.username, s.role, 'password_changed', 'Own password changed; all sessions revoked', ip);
    return json({ ok: true }, 200, { 'Set-Cookie': clearCookie(request) });
  }

  err(404, 'Not found.');
}
