// Nanhe Kadam Public School — Cloudflare Worker entry point.
// Serves static assets from /public and a JSON REST API under /api/*.
import { ApiError, json, clientIp } from './util.js';
import { csrfCheck } from './auth.js';
import { handleAuth } from './routes-auth.js';
import { handlePublic, serveImage } from './routes-public.js';
import { handleAdmin } from './routes-admin.js';
import { handleTeacher, handleParent } from './routes-portals.js';

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy':
    "default-src 'self'; script-src 'self' https://challenges.cloudflare.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; frame-src https://www.google.com https://challenges.cloudflare.com; object-src 'none'; base-uri 'self'; form-action 'self'",
};

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    try {
      if (path.startsWith('/api/')) {
        csrfCheck(request);
        let res;
        if (path.startsWith('/api/auth/') || path === '/api/setup' || path === '/api/setup-status') res = await handleAuth(request, env, path);
        else if (path.startsWith('/api/public/')) res = await handlePublic(request, env, path, ctx);
        else if (path.startsWith('/api/admin/')) res = await handleAdmin(request, env, path);
        else if (path.startsWith('/api/teacher/')) res = await handleTeacher(request, env, path);
        else if (path.startsWith('/api/parent/')) res = await handleParent(request, env, path);
        else throw new ApiError(404, 'Not found.');
        return withHeaders(res, SECURITY_HEADERS);
      }
      if (path.startsWith('/img/')) {
        return withHeaders(await serveImage(request, env, path), { 'X-Content-Type-Options': 'nosniff' });
      }
      // Static assets (HTML pages, CSS, JS, fonts, images)
      const res = await env.ASSETS.fetch(request);
      const headers = new Headers(res.headers);
      for (const [k, v] of Object.entries(SECURITY_HEADERS)) headers.set(k, v);
      if (res.status === 200) {
        if (path.startsWith('/assets/fonts/') || path.startsWith('/assets/img/')) headers.set('Cache-Control', 'public, max-age=604800');
        else if (path.startsWith('/assets/')) headers.set('Cache-Control', 'public, max-age=3600');
        else headers.set('Cache-Control', 'no-cache');
      }
      return new Response(res.body, { status: res.status, statusText: res.statusText, headers });
    } catch (e) {
      if (e instanceof ApiError) {
        return withHeaders(json({ error: e.message, code: e.code }, e.status), SECURITY_HEADERS);
      }
      console.log('Unhandled error:', e && e.stack || e, 'path:', path, 'ip:', clientIp(request));
      return withHeaders(json({ error: 'Something went wrong on our side. Please try again.' }, 500), SECURITY_HEADERS);
    }
  },
};

function withHeaders(res, extra) {
  const headers = new Headers(res.headers);
  for (const [k, v] of Object.entries(extra)) headers.set(k, v);
  return new Response(res.body, { status: res.status, statusText: res.statusText, headers });
}
