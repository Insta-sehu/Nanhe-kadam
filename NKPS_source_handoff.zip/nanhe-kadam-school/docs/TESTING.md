# Test Report — Delivery Build

**Date:** 11 November 2026 · **Environment:** Wrangler 4.86 local dev (workerd, same runtime as Cloudflare), Node 20, Chromium 158 headless (Playwright).

## 1. API & security suite — latest isolated authenticated run → **76 / 76 passed**

Covers (each line is an executed assertion):

- Public: homepage 200, content API shape, **no secrets in public responses**, ETag → 304 revalidation, security headers (CSP/nosniff), all portal pages + assets serve.
- CSRF: missing custom header → 403; cross-origin → 403.
- AuthZ without login: admin/teacher/parent APIs → 401; unknown route → 404.
- First-run setup: creates owner; **permanently disabled afterwards** (second attempt → 403).
- Login: wrong password → 401; unknown user → 401; correct → session; logout invalidates; password change revokes old sessions and new password works.
- Students: create with unique admission no; duplicate → 409; list/search; soft-delete revokes parent session.
- Parent login: admission no + DOB works immediately after creation; wrong DOB → 401; **PIN flow** (required → blocked without PIN → works with PIN → old sessions revoked → remove PIN restores DOB-only).
- Scoping: parent → admin API 403; parent → teacher API 403; teacher → admin API 403; teacher → unassigned class 403; co-admin → admin accounts 403; co-admin → AI settings 403.
- Live updates without redeploy: fee add/mark-paid → parent sees instantly; result add/delete and **bulk results path** → parent view updates; attendance → parent view; homework → parent view; **gallery upload → public site live**, unpublish → removed, delete works; **notice publish → live**, scheduled-future → hidden, draft → hidden, delete → removed; **slogan edit → public API reflects immediately**.
- Removing a student atomically soft-deletes their unpaid due-fee rows and revokes parent sessions. Paid fee history remains. The dashboard also joins only non-deleted students as defense-in-depth, so legacy/orphan due rows do not inflate the active total.
- Uploads: fake image bytes rejected (magic-byte check); served image has correct type + immutable cache.
- Validation: invalid phone, invalid map embed rejected.
- Enquiries: saved to D1, visible to admin only, never in public responses; rate limit → 429.
- AI: safe fallback does not invent/share a phone number; `/api/admin/ai/test` route reaches its missing-key response (regression test for named-route parsing).
- Audit log records actions; health endpoint returns counts.
- Rate limiting: repeated failed logins → 429; repeated enquiries → 429.

## 1b. Previous production verification (live Cloudflare deployment, 9 Nov) → **40 / 40 passed**

Run against `https://nanhe-kadam-school.nanhe-kadam.workers.dev` after the original deploy:

- Public content API live; school name and slogan correct; **exactly 4** featured gallery photos.
- **No secrets leaked**: `gemini_api_key` and `turnstile_secret` absent from the public API.
- D1 images serve **real bytes** on production (75 KB WebP) with immutable caching.
- One-time setup **permanently closed** after the owner account was created; a second
  `POST /api/setup` is refused (HTTP 403).
- Owner admin login works; session is an HttpOnly cookie with **no token in the response body**.
- Admin overview, audit log (25 entries) and DB-health endpoints all live.
- **CSRF**: mutation without the client header → 403. Anonymous admin API → 401.
- **Live edit round-trip**: slogan changed in Admin → immediately visible on the public API →
  restored. Notice published → immediately live → deleted → immediately gone. **No redeploy.**
- Parent login (admission no + DOB) works; overview, results (4), fees (2), homework (1),
  attendance (5 days) all correct; **wrong DOB rejected**; parent sees only their own child.
- **RBAC on production**: parent cookie → admin API 403; teacher cookie → admin API 403;
  teacher sees only assigned classes (Play Group, Nursery).
- Logout revokes the session server-side (subsequent request → 401).

## 1c. Live Gemini assistant check (11 Nov) → **passed**

- Owner-provided key was accepted by the Gemini API; `testGemini()` returned **OK** with `gemini-3.5-flash`, and the source `askGemini()` integration returned a school greeting through the Interactions API.
- Key and model were saved server-side in the existing live D1 settings, then the production `/api/public/assistant` endpoint was exercised with a greeting and returned a real reply (`fallback: false`). The key is not in the repository/ZIP or API responses.
- The production Worker still runs the previous code version until the follow-up deploy. The source fix pack uses the current Interactions API with `store:false`; its Gemini calls were exercised locally, but the updated code is not yet deployed.

## 1d. Live browser suite (real production URL, previous deploy) → **19 / 19 passed**

- No horizontal overflow at **320 / 360 / 375 / 390 / 412 / 430 / 768 / 1024 / 1440 px**.
- Gallery: exactly 4 photos, **all load from D1**, **all circular**.
- Hero illustration is a **perfect circle** (492 × 492, `border-radius: 50%`).
- Admin login → dashboard, gallery, students and content tabs all render on production.
- Parent login → dashboard on a 390 px mobile viewport.
- **Zero JavaScript errors** anywhere on production.

## 2. Browser UI suite — latest `npm run test:ui` → **45 passed, 0 failed**

- **No horizontal overflow** on the homepage at **320, 360, 375, 390, 412, 430, 768, 1024, 1440 px** (scrollWidth ≤ viewport at every size).
- Mobile scrolling/reveal checks passed at 320, 360, 375, 390, 412, and 430 px across 10 section/footer stops; contact cards remained inside the 20 px gutters during the reveal.
- No horizontal overflow on Admin/Teacher/Parent login pages at 320 & 390 px.
- **Zero JavaScript console errors** on every page tested.
- Gallery shows **exactly 4** featured photos; every image stays **inside its card** (bounding-box check); **every gallery image actually loads** (`naturalWidth > 0`).
- Mobile AI chat panel opens compactly, remains inside the viewport and is capped at 420 CSS px tall.
- AI chat button correctly hidden while the assistant is disabled.
- Authenticated browser portal flows were skipped in this latest run because UI test credentials were not supplied. The authenticated API suite was run separately against an isolated temporary D1 database and passed **76 / 76**.
- Screenshots captured in `test-artifacts/` (not shipped in the ZIP).

## 3. Bugs found & fixed during testing

1. Missing import (`rateLimit`) — build error → fixed.
2. Static assets bypassed Worker security headers → added edge `_headers` file → verified.
3. Portal boot ran before `const` declarations (TDZ crash) → boot moved after declarations → verified.
4. CSS `display` overrode the `hidden` attribute (chat FAB + login/app views visible when they shouldn't be) → global `[hidden]{display:none!important}` → verified visually + by tests.
5. ETag included `server_time` (defeated 304 caching) → ETag now content-only → verified.
6. Test harness: mobile sidebar must be opened before tab clicks → fixed harness.
7. **Circular image redesign** — hero/about/gallery changed from square/arch to circles. First attempt caused 2–3 px horizontal overflow at 412/430 px (decorative `::before`/`::after` offsets). Offsets reduced → re-verified all 9 widths pass, locally and on production.
8. **D1 BLOB serialization**: D1 returns BLOB columns as number arrays; passing that straight to `Response` corrupted image bodies (200 OK but broken images). Normalized to `Uint8Array` and added a **byte-level PNG-magic assertion** + browser `naturalWidth` check → verified visually and by tests.
9. Deleted students left unpaid fees active → student removal now atomically soft-deletes only that student's due-fee rows, revokes parent sessions, and preserves paid history; dashboard totals also join against non-deleted students to exclude legacy ghost dues.
10. Named admin paths (`/api/admin/ai/test` and `/api/admin/results/bulk`) were parsed as numeric record IDs → parse only numeric path segments as IDs; added regression checks for both routes.
11. New Gemini API keys could not use the previous `gemini-2.5-flash` default → use supported `gemini-3.5-flash` and the Interactions API, with server-side `store:false`.
12. The mobile chat panel occupied too much of the phone view → cap height at 420 px / viewport-relative height, reduce chat body minimum height and test its final on-screen bounds.

## 4. NOT verified (honest limitations)

- **Real mobile hardware / 60 FPS**: animations use only transform/opacity, respect `prefers-reduced-motion` and downgrade on low-core devices, but actual frame rates were not measured on physical phones. Test on the owner's phone after deploy.
- **Live Gemini connection**: the owner-provided key was saved server-side on 11 Nov, and a real reply was verified through the live public assistant endpoint using `gemini-3.5-flash`. The source fix pack switches to the current Interactions API with `store:false`; that changed code still needs deployment. The **Test Connection** endpoint fix is covered locally but is not active on production yet.
- **Live Turnstile verification**: no widget keys at build time. Server verification + conditional widget rendering are implemented; enable with real keys and try a login.
- **Remote deployment of this fix pack**: not yet performed. The existing Worker and URL stay live; uploading the patch requires fresh Cloudflare authorization because the earlier token was exposed. No Cloudflare credential is included in the ZIP. The production model setting was updated directly via the admin API; migration `0002` is pending remote application.
- **Google Maps exact location**: not invented. The site shows the owner-provided address with a Maps *search* link until the owner pastes a verified link/embed.
- **Load testing at 400-student scale**: schema, indexes and batch writes are designed for it and free-tier math is documented, but no synthetic load test was run.
- **Email delivery**: not in scope — enquiries are stored in D1 and shown in the admin portal (owner's requirement). Official email can be added to contact content later.
