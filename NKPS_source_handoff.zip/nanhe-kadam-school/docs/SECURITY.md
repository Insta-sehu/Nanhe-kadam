# Security Design & Audit

Security is enforced **server-side on every request**. The frontend is public by design — hiding it is never used as a protection.

## Authentication

| Item | Implementation |
|---|---|
| Password hashing | PBKDF2-HMAC-SHA256, **100,000 iterations**, 16-byte random salt per user (WebCrypto). Format `pbkdf2:100000:salt:hash`. Constant-time comparison. |
| Sessions | **Opaque 256-bit random tokens**; only the SHA-256 hash is stored in D1 (`sessions` table). No JWT, no tokens in localStorage. |
| Cookies | `HttpOnly`, `SameSite=Lax`, `Path=/`, `Secure` on HTTPS. Staff sessions expire after **12 h**, parent sessions after **7 days**. |
| Revocation | Logout deletes the session. Password change/reset, PIN change, deactivation and student deletion revoke all related sessions immediately. Expired sessions are purged on login. |
| First-run setup | `/api/setup` works **only while zero admins exist**, then is permanently disabled (verified by test). No default or hardcoded credentials anywhere. |
| Parent login | Admission number + child's DOB (owner's requirement), optionally hardened with a 4–8 digit **parent PIN** set by admin. Both are rate-limited and lockable. |

## Authorization (server-checked on every endpoint)

| Capability | Admin (owner) | Co-admin | Teacher | Parent |
|---|---|---|---|---|
| Website content, gallery, notices | ✅ | ✅ | ❌ | ❌ |
| Students / teachers / classes / fees / results | ✅ | ✅ | ❌ | ❌ |
| Attendance / homework | ✅ | ✅ | ✅ **own classes only** | ❌ |
| View own child's records | — | — | — | ✅ **own child only** |
| Admin accounts, AI keys, Turnstile secrets, audit log | ✅ | ❌ | ❌ | ❌ |

Role information is read from the **server-side session**, never from the client. Changing anything in DevTools cannot elevate privileges (verified by tests: parent→admin 403, teacher→admin 403, teacher→unassigned class 403, co-admin→admin settings 403).

## Request protections

- **CSRF**: every mutating request must carry the custom `X-NKPS-Client: fetch` header (cross-site forms cannot set it; cross-origin `fetch` with it triggers a CORS preflight that is never granted). `Origin` is additionally verified when present. Cookies are SameSite=Lax.
- **SQL injection**: every query uses bound parameters; no string concatenation of user input. Table names in helpers are fixed constants.
- **XSS**: all dynamic content is HTML-escaped at render time (`esc()`); no `innerHTML` of unescaped user data; notices render as plain text. A strict **Content-Security-Policy** (`default-src 'self'`, no inline scripts) is applied to pages and APIs.
- **Input validation**: type/length/format checks on every field (names, dates, phones, emails, URLs, marks, amounts). Map embeds restricted to `https://www.google.com/maps/embed…`.
- **Uploads**: JPEG/PNG/WebP only, verified by **magic bytes** (not just the declared type), ≤900 KB after automatic client-side compression, stored as D1 BLOBs, served with `X-Content-Type-Options: nosniff` and immutable caching. No SVG (script risk), no executable content, random unguessable IDs.
- **Rate limiting** (D1-backed): staff login 12/10 min per IP + 8-failure account lockout (15 min); parent login 15/10 min per IP + 8/10 min per admission number + lockout; enquiries 4/h per IP; assistant 8/min per IP + configurable **daily global cap**; setup 5/h; password change 6/10 min; AI test 8/10 min.
- **Turnstile**: optional but fully wired — when the owner saves site key + secret, login, parent login, setup and enquiry forms render the widget and the server verifies tokens with Cloudflare. Without keys, rate limits still protect the forms.
- **Security headers**: CSP, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy` on all responses (via `_headers` for assets and the Worker for APIs). `X-Frame-Options` is intentionally not set so the site can be embedded in previews; add `Content-Security-Policy: frame-ancestors 'self'` in `public/_headers` if you want to block framing in production.
- **Audit log**: logins (success/failure), all create/update/delete actions, content changes, AI setting changes (key value never logged), password resets — with actor, role, IP and timestamp. Visible to the owner in Admin → Audit Log.

## Secrets handling

- **No secrets are needed at deploy time.** The Gemini API key and Turnstile secret are entered in the Admin Portal and stored in D1 (server-side only).
- The Gemini key is **never** included in any API response — reads return only `key_set` + a masked tail (`••••1234`). Verified by the "no secrets leaked" test.
- `.env`, `.dev.vars`, backups and one-off SQL files are gitignored. The repo contains **zero credentials**.
- AI answers are constrained by a system prompt built only from verified school settings + published notices, with explicit "never invent fees/facilities/dates" instructions, 500-character input limit, 512-token output cap and a neutral temporary-unavailable fallback on any error. Gemini uses the Interactions API with `store:false` so parent chat history is not retained by Google.

## Children's privacy

- No child's personal information is ever exposed publicly (verified by test).
- Parent sessions are scoped to exactly one student; all parent endpoints filter by the session's student ID.
- Teachers see only name/admission no/guardian contact for their own classes — no fees, results or other classes.
- Deleting a student is a soft-delete that immediately kills parent access.

## Known trade-offs (honest list)

1. **Parent login strength**: admission no + DOB is convenient but weaker than a password. Mitigations: strict rate limits + lockout, optional PIN (recommended for every family), no public data. Enable Turnstile for extra safety.
2. **PBKDF2 on Workers Free**: 100k iterations follows Cloudflare's own guidance; login is infrequent. If you ever see CPU-limit errors on the free plan, lower `ITERATIONS` in `src/auth.js` (e.g. 50k) and reset passwords — or upgrade to Workers Paid ($5).
3. **Images in D1**: chosen so no R2/card setup is needed. The free plan caps a database at 500 MB — roughly 1,500+ compressed photos. The Health page shows usage. If you outgrow it, move images to R2 (code change) or upgrade.
4. **No WAF rules configured**: consider adding Cloudflare WAF/rate-limiting rules (free tier includes basic ones) for the live domain.
5. **Backups are manual by default** — see BACKUP.md. D1 Time Travel (7 days on free) is a safety net, not a backup strategy.

## Owner security checklist

- [ ] Keep the GitHub repo **private**
- [ ] Use a strong owner password; change it if it was ever shared in chat
- [ ] Delete demo accounts (demo teacher + demo students) before real use
- [ ] Set a parent PIN for each family (optional but recommended)
- [ ] Enable Turnstile (free) when convenient
- [ ] Take weekly backups (`npm run db:backup`)
- [ ] Review Admin → Audit Log occasionally
