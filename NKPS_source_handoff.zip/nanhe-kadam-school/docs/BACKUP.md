# Backup & Restore

## What needs backing up?

**Only the D1 database.** It contains everything: students, accounts (hashed passwords), fees, results, attendance, homework, notices, gallery metadata **and the photo binaries**, website content and settings (incl. the Gemini key). The code lives in GitHub; static brand assets live in `public/`.

## Manual backup (recommended weekly)

```bash
npx wrangler login          # if not already signed in
npm run db:backup           # → backups/nkps-backup-YYYY-MM-DD-HH-MM-SS.sql
```

- The export is a complete SQL dump (schema + data).
- `backups/` is **gitignored** — it contains personal data. Store copies somewhere private (e.g. encrypted drive / private cloud).
- Local dev database: `npm run db:backup -- --local`.

## Restore procedure

**Scenario 1 — accidental deletion (within 7 days):**
D1 Time Travel on the free plan keeps 7 days of history:
```bash
npx wrangler d1 time-travel restore nanhe-kadam-db --timestamp="2026-11-09T10:00:00Z"
```
(Restores the whole database to that moment. Check the exact syntax with `npx wrangler d1 time-travel --help`.)

**Scenario 2 — restore from a backup file into the existing database:**
```bash
# WARNING: this re-runs the dump. For a clean restore, recreate the database first:
npx wrangler d1 delete nanhe-kadam-db
npm run db:create                     # creates fresh DB + updates wrangler.toml (skip migrations prompt if restoring full dump)
npx wrangler d1 execute nanhe-kadam-db --remote --file=backups/nkps-backup-XXXX.sql
npm run deploy                        # rebind the worker to the new database id
```

**Scenario 3 — test a restore safely (recommended drill):**
```bash
npx wrangler d1 create nanhe-kadam-restore-test
npx wrangler d1 execute nanhe-kadam-restore-test --remote --file=backups/nkps-backup-XXXX.sql
npx wrangler d1 execute nanhe-kadam-restore-test --remote --command "SELECT COUNT(*) FROM students;"
npx wrangler d1 delete nanhe-kadam-restore-test
```

## Optional automation (GitHub Actions)

A workflow is included at `.github/workflows/backup.yml` but is **NOT active** until you:
1. Add repo secrets `CLOUDFLARE_API_TOKEN` (D1 edit permission) and `CLOUDFLARE_ACCOUNT_ID`.
2. Uncomment the `schedule:` block.
3. Keep the repo private (artifacts contain personal data, 90-day retention).

You can always run it manually: repo → **Actions → Database Backup → Run workflow**.

> Until you do this, no automated backup exists — the README and admin Health page say so explicitly.

## What about photos?

Photos are inside the D1 dump (BLOBs), so the single `.sql` file is a complete backup. Static brand images (logo, illustrations) are in git under `public/assets/img/`.
