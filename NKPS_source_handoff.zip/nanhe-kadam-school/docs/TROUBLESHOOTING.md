# Troubleshooting

## Deployment

**`npm run db:create` says I'm not logged in**
Run `npx wrangler login` and complete the browser flow. In Codespaces, open the printed URL in your local browser. In CI, set `CLOUDFLARE_API_TOKEN` + `CLOUDFLARE_ACCOUNT_ID` instead.

**Deploy fails: "database_id" invalid / LOCAL_DEV_PLACEHOLDER**
You skipped `npm run db:create`. Run it — it writes the real ID into `wrangler.toml`. Or paste the UUID from `npx wrangler d1 list` manually.

**Migrations fail remotely**
`npx wrangler d1 migrations apply nanhe-kadam-db --remote`. If a migration was partially applied, check `npx wrangler d1 migrations list nanhe-kadam-db --remote` and see BACKUP.md before touching data.

**The site loads but looks unstyled**
Hard-refresh (Ctrl+Shift+R). Assets are cached for an hour; a fresh deploy may take a few seconds to propagate.

## Login & accounts

**"Too many attempts… try again in X minutes"**
Rate limiting / lockout is doing its job. Wait 10–15 minutes. Owner can reset a staff password via `npm run admin:create` (also clears the lock). Locally, `npm test` clears windows automatically.

**Admin setup screen doesn't appear**
It only shows while **zero** admins exist. If you already created one, sign in. Lost the password → `npm run admin:create -- --username "..." --password "..."`.

**Parent can't log in**
Check Admin → Students: admission number spelling (case-insensitive) and **exact date of birth**. If a PIN is set, the parent needs it too (profile → Parent PIN to reset/remove). Status must be **active**.

**A teacher sees "No classes assigned"**
Admin → Teachers → edit → tick their classes → save.

## Content & images

**Photo upload says "too large"**
The browser compresses automatically (≤ ~850 KB). Very large/complex photos can still exceed it — crop or pick a smaller version. Only JPG/PNG/WebP are accepted.

**Gallery change not visible on the website**
The photo must be **published**, and the homepage shows the **first 4** by sort order. Public content revalidates on page load / tab focus — refresh once. If you use a CDN in front (custom domain), purge cache.

**Notice not showing**
Status must be *Published*, publish time in the past, expiry in the future. The admin Notices list shows a badge (Draft / Scheduled / Live / Expired) explaining the state.

**Logo replaced but old one still shows somewhere**
Hard-refresh. The default logo files remain as fallback; the uploaded logo is served from `/img/<id>` with long caching, and a new upload gets a new ID (old caches expire naturally).

## AI assistant

**Chat button doesn't appear**
Admin → AI Assistant → paste key → **Test Connection** → tick *Enable* → Save. The button only renders when enabled.

**Test Connection fails**
- 400/403 from Google → key invalid or restricted; create a fresh key at aistudio.google.com.
- Model unavailable for a new API key → use `gemini-3.5-flash` (the recommended default). The assistant uses Google's Interactions API and stores no chat history with Google.
- 429 → your Gemini quota may be exhausted; the website shows a neutral temporary-unavailable message (it does not invent or expose contact details).

**Assistant answers are wrong**
It only knows what's in Website Content + published notices. Fix the content; the assistant uses it immediately.

## Turnstile

**Widget shows but verification fails**
Site key and secret must be from the **same** widget, and the widget's allowed hostnames must include your domain (and `workers.dev` subdomain if you use it). Clear both keys to disable.

## Limits & performance

**D1 errors after heavy usage**
Free tier: 5M row-reads/day, 100k row-writes/day. Check Admin → Database Health. Limits reset 00:00 UTC. If you genuinely exceed them, Workers Paid ($5/mo) removes the daily cliff.

**Database approaching 500 MB**
Almost always photos. Delete unused gallery items (deleting frees the image blob when unreferenced). Keep only what's needed.

**Login occasionally slow / CPU error on free plan**
PBKDF2 is intentionally heavy. See SECURITY.md trade-off #2 for the tuning knob.

## Local development

**`npm run dev` port already in use** → another wrangler is running; stop it or change `--port`.
**Local DB missing tables** → `npm run db:migrate:local`.
**UI tests fail to launch browser** → `npx playwright install --with-deps chromium`.
**Tests fail with 429** → they clear local rate limits automatically; make sure `BASE_URL` points at the local server.
