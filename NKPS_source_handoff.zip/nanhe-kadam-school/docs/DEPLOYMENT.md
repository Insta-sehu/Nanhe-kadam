# Deployment Guide

Everything runs on **one Cloudflare Worker + one D1 database**. No other services, no card, no build step.

## A. First-time deployment (≈10 minutes)

### 1. Get the code into GitHub
1. Create a **private** repository on GitHub.
2. Upload the contents of this project (the ZIP contents, not the ZIP itself).

### 2. Open in Codespaces (or use your own computer with Node 20+)
Code → **Codespaces** → Create codespace. The devcontainer installs dependencies automatically; otherwise run `npm install`.

### 3. Sign in to Cloudflare
```bash
npx wrangler login
```
A browser URL appears — open it, log in to your Cloudflare account, press **Allow**.
(In Codespaces, copy the URL into your local browser; the callback completes automatically.)

### 4. Create the database
```bash
npm run db:create
```
This creates the `nanhe-kadam-db` D1 database, writes its ID into `wrangler.toml`, and applies all migrations (tables + default website content + the 5 classes: Play Group, Nursery, LKG, UKG, Class 1).

### 5. Deploy
```bash
npm run deploy
```
Wrangler prints your live URL, e.g. `https://nanhe-kadam-school.<subdomain>.workers.dev`.

### 6. Create the owner account (one-time)
1. Open `https://<your-url>/admin/`
2. The **"Create the owner account"** screen appears (only because no admin exists yet).
3. Enter your name, chosen username (e.g. `Rakesh@1`) and a strong password.
4. Done — this screen never appears again. Sign in any time at `/admin/`.

> Prefer the command line? `npm run admin:create -- --username "Rakesh@1" --password "..." --name "Rakesh"` does the same securely (password is hashed locally; nothing secret is stored in the repo).

### 7. First settings to fill in (Admin Portal)
- **Website Content → Contact & Location**: phone is pre-filled; add the official **email** and the **verified Google Maps link/embed** when ready.
- **Website Content**: review slogan, about, messages — everything is editable.
- **Gallery**: upload real school photos (demo illustrations can be deleted).
- **Students**: add children — parent logins start working immediately (admission no + DOB).
- **Teachers**: create accounts and assign classes.
- **AI Assistant** (optional): paste a Gemini API key from [aistudio.google.com](https://aistudio.google.com), press **Test Connection**, then enable.
- **Bot protection** (optional): create a free Turnstile widget in Cloudflare dashboard → Turnstile, paste site key + secret in Website Content → Bot Protection.

## B. Custom domain (optional, free)

Cloudflare dashboard → **Workers & Pages → nanhe-kadam-school → Settings → Domains & Routes → Add → Custom domain** → enter e.g. `nanhekadam.in` (domain must be on your Cloudflare account). SSL is automatic. This is a one-time dashboard step; content updates never need it.

## C. The three kinds of updates

| Type | How | Redeploy? |
|---|---|---|
| **Content** (gallery, notices, slogan, text, logo, contact, map, announcements, AI/Turnstile keys) | Admin Portal | ❌ Never |
| **Records** (students, teachers, fees, results, attendance, homework, co-admins) | Admin Portal | ❌ Never |
| **Code** (design changes, new features) | edit files → `npm run deploy` | ✅ Yes |

Database schema changes (rare): add a new file `migrations/0002_….sql`, then `npm run db:migrate` and `npm run deploy`.

## D. Account recovery

**Admin password forgotten** (owner has Cloudflare access):
```bash
npx wrangler login   # if needed
npm run admin:create -- --username "Rakesh@1" --password "new-strong-password"
```
Resets the password, re-activates the account and signs out all its sessions.

**Co-admin / teacher password forgotten:** Admin Portal → Admin Accounts / Teachers → key icon → set a new password.

**Parent login problems:** verify admission number + DOB in Admin → Students → edit. If a PIN was set and forgotten, use the profile → **Parent PIN** → remove or replace it.

## E. Local development

```bash
npm run db:migrate:local                 # local SQLite copy in .data/
npm run dev                              # http://localhost:8787
ADMIN_USER='x' ADMIN_PASS='y' npm run demo:seed   # optional demo data (local only)
ADMIN_USER='x' ADMIN_PASS='y' npm test            # API tests
```

Local data lives in `.data/` (gitignored). It never touches the live database.

## F. Rolling back a bad code deploy

Cloudflare dashboard → Workers → nanhe-kadam-school → **Deployments** → previous version → **Rollback**. Content/database is unaffected by code rollbacks.
