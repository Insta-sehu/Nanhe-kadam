# 🏫 Nanhe Kadam Public School — Website + Management System

## ✅ Already deployed and live

| What | Where |
|---|---|
| **Public website** | https://nanhe-kadam-school.nanhe-kadam.workers.dev |
| **Admin Portal** | https://nanhe-kadam-school.nanhe-kadam.workers.dev/admin/ |
| **Teacher Portal** | https://nanhe-kadam-school.nanhe-kadam.workers.dev/teacher/ |
| **Parent Portal** | https://nanhe-kadam-school.nanhe-kadam.workers.dev/parent/ |
| Worker name | `nanhe-kadam-school` |
| workers.dev subdomain | `nanhe-kadam` |
| D1 database | `nanhe-kadam-db` — id `542d8371-b578-450e-bdb9-dabbf3574631` (already in `wrangler.toml`) |

The same Worker and D1 remain the production site. On 11 Nov 2026, the owner-provided Gemini key and supported `gemini-3.5-flash` model were saved server-side and the live chat endpoint was verified. This project also contains a follow-up code fix pack (compact mobile chat, accurate fee totals after child deletion, working Gemini connection test, current Gemini API); **those code changes still need a Cloudflare deploy** to become active. No student/demo records were re-added.

To publish the code fixes from this folder (or a Codespace):

```bash
npm install
export CLOUDFLARE_API_TOKEN=...   # use a fresh, limited-scope token; never commit it
npm run db:migrate               # apply pending D1 migrations (if any)
npm run deploy                   # same Worker URL and D1 database
```

> ⚠️ The API token used for the first deployment was shared in a chat message.
> Revoke it and create a **fresh, limited-scope token** for another deploy. Keep it
> only in a terminal/Codespaces secret; it is not present anywhere in this repository.
> A new deploy replaces the active Worker version; Cloudflare may retain old versions
> for rollback, while the existing URL and database stay unchanged.

---

A complete, production-ready school platform built **entirely on Cloudflare's free tier**:

- **Premium animated public website** (mobile-first, brand colors from the school logo)
- **Admin Portal** — students, teachers, classes, attendance, homework, fees, results, gallery, notices, full website content, enquiries, AI settings, co-admins, audit log
- **Teacher Portal** — assigned classes, attendance, homework, notices
- **Parent Portal** — login with **admission number + child's date of birth**; sees attendance, homework, fees, results, notices
- **Live Gallery & Notices** — admin publishes → visible on the website **instantly, no redeployment**
- **Optional Gemini AI assistant** — configured by the owner in the Admin Portal; API key never leaves the server

| Layer | Technology | Cost |
|---|---|---|
| Frontend | Cloudflare Workers Static Assets (vanilla HTML/CSS/JS, no build step) | Free |
| Backend | Cloudflare Workers (REST API) | Free |
| Database | Cloudflare D1 (SQLite) — all records incl. photos | Free |
| Bot protection | Cloudflare Turnstile (optional, owner-configured) | Free |
| AI (optional) | Google Gemini API (owner's own key, daily cap) | Owner's Gemini quota |

> **No R2, no paid services, no card required.** Photos are auto-compressed in the browser and stored in D1 (keeps setup to a single database). See `docs/SECURITY.md` for the reasoning and limits.

---

## 🚀 Deploy in 5 steps (GitHub Codespaces friendly)

```bash
# 1. Install dependencies
npm install

# 2. Sign in to Cloudflare (opens browser; in Codespaces follow the URL shown)
npx wrangler login

# 3. Create the D1 database + apply migrations (auto-updates wrangler.toml)
npm run db:create

# 4. Deploy
npm run deploy

# 5. Open https://nanhe-kadam-school.<your-subdomain>.workers.dev/admin/
#    → "Create the owner account" appears ONCE. Enter your chosen username/password.
```

That's it. **Everything else is managed from the Admin Portal** — you never need to open the Cloudflare dashboard again for day-to-day work.

📖 Detailed guide (custom domain, updates, recovery): **[docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)**

### What needs a redeploy vs. what doesn't?

| Change | Redeploy needed? |
|---|---|
| Gallery photos, notices, slogan, all website text, logo, contact info, map link | ❌ No — live instantly from Admin Portal |
| Students, teachers, fees, results, attendance, homework | ❌ No — database updates |
| Gemini key / Turnstile keys / announcements | ❌ No — Admin Portal settings |
| Actual code changes (design, features) | ✅ Yes — `npm run deploy` |

---

## 🔑 Portals & first login

| Portal | URL | Login |
|---|---|---|
| Admin | `/admin/` | Owner account created on first visit (one-time setup) |
| Teacher | `/teacher/` | Username + password created by admin |
| Parent | `/parent/` | Child's **admission number + date of birth** (+ optional PIN set by admin) |

- The first-run setup screen is **permanently disabled** after the owner account exists. No default credentials exist anywhere in this code.
- Admin can add **co-admins** (same school-management powers, but cannot touch admin accounts, AI keys or security keys).
- Forgot the admin password? Recovery: `npm run admin:create -- --username "..." --password "..."` (see `docs/DEPLOYMENT.md`).

## 🧪 Local development & demo data

```bash
npm run db:migrate:local   # create local database
npm run dev                # http://localhost:8787

# Optional demo data (5 children, teacher, fees, results, gallery):
ADMIN_USER='Rakesh@1' ADMIN_PASS='your-password' npm run demo:seed
```

Demo logins created by the seed (delete them before real use):
- Teacher: `sunita.teacher` / `Teacher@1234`
- Parent: admission `NKPS001`, DOB `2021-03-15`

## ✅ Tests

```bash
ADMIN_USER='...' ADMIN_PASS='...' npm test        # 74 API/security checks
ADMIN_USER='...' ADMIN_PASS='...' npm run test:ui # 47 browser UI checks (needs: npx playwright install chromium)
```

Actual results for this fix pack: **74/74 API + 47/47 browser checks passed locally** — see **[docs/TESTING.md](docs/TESTING.md)**. The previous production build separately passed **40 API + 19 browser checks** before this follow-up code patch.

## 💾 Backups

```bash
npm run db:backup   # exports the live D1 database to backups/*.sql
```

Do this weekly. Restore steps + optional GitHub Actions automation: **[docs/BACKUP.md](docs/BACKUP.md)**. Automation is **not** active until you configure it.

## 💸 Free-tier reality check (verified Nov 2026)

| Resource | Free allowance | This school's expected usage |
|---|---|---|
| D1 reads | 5,000,000 rows/day | A few thousand/day — tiny |
| D1 writes | 100,000 rows/day | ~500/day (400 students attendance) |
| D1 storage | 5 GB account / **500 MB per database** | Text records: a few MB. ~1,000 compressed photos ≈ 250 MB |
| Workers requests | 100,000/day | A school site uses hundreds–thousands/day |

**For 400 students this runs comfortably free for years** — but Cloudflare can change plans/limits at any time, so nothing is guaranteed forever. Watch the **Database Health** page in the admin portal, keep gallery photos compressed (automatic), and take weekly backups. If you ever outgrow the free tier, the Workers Paid plan ($5/mo) raises every limit — the code needs no changes.

## 📁 Project structure

```
├── public/               # Frontend (served as static assets)
│   ├── index.html        # Public website
│   ├── admin/            # Admin portal (SPA)
│   ├── teacher/          # Teacher portal
│   ├── parent/           # Parent portal
│   ├── _headers          # Edge security headers
│   └── assets/           # CSS, JS, fonts, logo, illustrations
├── src/                  # Cloudflare Worker (REST API)
│   ├── index.js          # Router + security headers
│   ├── auth.js           # PBKDF2 hashing, sessions, CSRF, rate limits, Turnstile
│   ├── routes-auth.js    # Setup, logins, password change
│   ├── routes-public.js  # Content, gallery, notices, enquiries, assistant
│   ├── routes-admin.js   # Full admin API
│   ├── routes-portals.js # Teacher + parent APIs (scoped)
│   ├── gemini.js         # Optional AI assistant (server-side key)
│   └── util.js           # Validation, images, settings, audit
├── migrations/           # D1 schema + default content
├── scripts/              # setup, admin recovery, backup, demo seed, tests
├── docs/                 # Deployment, security, backup, troubleshooting, test report
└── wrangler.toml         # Cloudflare config
```

## 📚 Documentation

- **[Deployment guide](docs/DEPLOYMENT.md)** — first deploy, updates, custom domain, recovery
- **[Security](docs/SECURITY.md)** — auth design, RBAC matrix, protections, owner checklist
- **[Backup & restore](docs/BACKUP.md)**
- **[Troubleshooting](docs/TROUBLESHOOTING.md)**
- **[Test report](docs/TESTING.md)** — what was tested, results, known limitations

## ⚠️ Important notes for the owner

1. **Keep the GitHub repository private** (student data lives in D1, not in git — but keep configs private anyway).
2. School email and the exact Google Maps location are **not invented** — add them in Admin → Website Content when verified.
3. No launch/opening-date announcement exists anywhere; the announcement banner is **off** until you enable it.
4. Facilities listed are only the ones you confirmed (classrooms, play room, CCTV cameras, caring aayas, food & water). Edit anytime in Admin → Website Content.
5. Delete the demo students/teacher before real use (Admin → Students/Teachers → remove).
