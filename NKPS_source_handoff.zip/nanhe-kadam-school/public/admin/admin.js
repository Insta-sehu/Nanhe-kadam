// Admin Portal — full school management. Vanilla JS, no build step.
(async function () {
  'use strict';
  const { api, esc: h, toast, modal, confirmDlg, fmtDate, fmtDateTime, money, initials, today, epochToLocal, compressImage, icon, shell, maybeTurnstile, setLogo } = P;
  const $ = (s, el) => (el || document).querySelector(s);
  const $$ = (s, el) => [...(el || document).querySelectorAll(s)];
  const C = () => document.getElementById('content');
  let ME = null, CLASSES = [], SHELL = null;

  // ---------------- boot ----------------
  async function boot() {
  const me = await api('/api/auth/me').catch(() => ({ authenticated: false }));
  if (me.authenticated && ['admin', 'coadmin'].includes(me.role)) { ME = me; await startApp(); }
  else {
    const setup = await api('/api/setup-status').catch(() => ({ needed: false }));
    $('#login-view').hidden = false;
    $(setup.needed ? '#setup-block' : '#login-block').hidden = false;
    maybeTurnstile();
    if (setup.needed) {
      $('#setup-form').addEventListener('submit', async (ev) => {
        ev.preventDefault();
        const errBox = $('#setup-error'); errBox.classList.remove('show');
        if ($('#s-pass').value !== $('#s-pass2').value) { errBox.textContent = 'Passwords do not match.'; return errBox.classList.add('show'); }
        const btn = ev.target.querySelector('button'); btn.disabled = true;
        try {
          const body = { name: $('#s-name').value.trim(), username: $('#s-user').value.trim(), password: $('#s-pass').value };
          if (window.turnstile && window.__tsWidget != null) body.turnstile = window.turnstile.getResponse(window.__tsWidget);
          await api('/api/setup', { method: 'POST', body });
          location.reload();
        } catch (e) { errBox.textContent = e.message; errBox.classList.add('show'); btn.disabled = false; }
      });
    } else {
      $('#login-form').addEventListener('submit', async (ev) => {
        ev.preventDefault();
        const errBox = $('#login-error'); errBox.classList.remove('show');
        const btn = ev.target.querySelector('button'); btn.disabled = true;
        try {
          const body = { username: $('#l-user').value.trim(), password: $('#l-pass').value };
          if (window.turnstile && window.__tsWidget != null) body.turnstile = window.turnstile.getResponse(window.__tsWidget);
          const r = await api('/api/auth/login', { method: 'POST', body });
          if (r.role === 'teacher') { await api('/api/auth/logout', { method: 'POST' }); throw new Error('This is the Admin Portal. Teachers please sign in at /teacher/'); }
          location.reload();
        } catch (e) { errBox.textContent = e.message; errBox.classList.add('show'); btn.disabled = false; if (window.turnstile && window.__tsWidget != null) window.turnstile.reset(window.__tsWidget); }
      });
    }
  }
  }

  async function startApp() {
    $('#login-view').hidden = true; $('#app-view').hidden = false;
    CLASSES = (await api('/api/admin/classes')).classes;
    api('/api/public/content').then((d) => setLogo(d.settings?.logo_image_id)).catch(() => {});
    const groups = [
      { items: [{ id: 'dashboard', label: 'Dashboard', icon: 'dashboard' }] },
      { label: 'School', items: [
        { id: 'students', label: 'Students', icon: 'students' },
        { id: 'teachers', label: 'Teachers', icon: 'teacher' },
        { id: 'classes', label: 'Classes', icon: 'classes' }] },
      { label: 'Academics', items: [
        { id: 'attendance', label: 'Attendance', icon: 'calendar' },
        { id: 'homework', label: 'Homework', icon: 'book' },
        { id: 'fees', label: 'Fees', icon: 'money' },
        { id: 'results', label: 'Results', icon: 'chart' }] },
      { label: 'Website', items: [
        { id: 'gallery', label: 'Gallery', icon: 'camera' },
        { id: 'notices', label: 'Notices', icon: 'bell' },
        { id: 'content', label: 'Website Content', icon: 'globe' },
        { id: 'inquiries', label: 'Enquiries', icon: 'mail', badge: true }] },
    ];
    if (ME.role === 'admin') groups.push({ label: 'System', items: [
      { id: 'ai', label: 'AI Assistant', icon: 'robot' },
      { id: 'admins', label: 'Admin Accounts', icon: 'shield' },
      { id: 'audit', label: 'Audit Log', icon: 'list' },
      { id: 'health', label: 'Database Health', icon: 'info' }] });
    groups.push({ items: [{ id: 'password', label: 'Change Password', icon: 'key' }] });
    SHELL = shell({ groups, onNav: nav, user: ME, roleLabel: ME.role === 'admin' ? 'Owner · Admin' : 'Co-Admin', portalName: 'Admin Portal' });
    refreshBadge();
    nav('dashboard');
  }

  const TITLES = { dashboard: ['Dashboard', 'School at a glance'], students: ['Students', 'Admissions, profiles & parent accounts'], teachers: ['Teachers', 'Accounts & class assignments'], classes: ['Classes', 'Play Group to Class 1'], attendance: ['Attendance', 'Daily attendance register'], homework: ['Homework', 'Class-wise homework'], fees: ['Fees', 'Fee records & payments'], results: ['Results', 'Exam marks & progress'], gallery: ['Gallery', 'Photos shown on the website'], notices: ['Notices', 'Live notice board'], content: ['Website Content', 'Everything on the public website'], inquiries: ['Enquiries', 'Admission enquiries from parents'], ai: ['AI Assistant', 'Gemini settings (optional)'], admins: ['Admin Accounts', 'Owner & co-admins'], audit: ['Audit Log', 'Who did what, when'], health: ['Database Health', 'Storage & usage'] };
  function nav(id) {
    if (id === 'password') return passwordModal();
    const [title, sub] = TITLES[id] || ['', ''];
    SHELL.setActive(id, title, sub);
    C().innerHTML = '<div class="empty">Loading…</div>';
    (VIEWS[id] || (() => {}))().catch((e) => { C().innerHTML = `<div class="alert bad">${h(e.message)}</div>`; });
  }
  async function refreshBadge() {
    try { const d = await api('/api/admin/overview'); SHELL.setBadge('inquiries', d.new_inquiries); } catch {}
  }

  // ---------------- shared helpers ----------------
  const classOpts = (sel, all = false) => (all ? '<option value="">All classes</option>' : '<option value="">Choose class…</option>') + CLASSES.map((c) => `<option value="${c.id}" ${String(sel) === String(c.id) ? 'selected' : ''}>${h(c.name)}</option>`).join('');
  const stat = (label, n, ic, color, bg) => `<div class="stat" style="--sc:${color};--scbg:${bg}"><span class="ic">${icon(ic, 20, color)}</span><div class="n">${n}</div><div class="l">${h(label)}</div></div>`;
  const badge = (txt, kind) => `<span class="badge ${kind}">${h(txt)}</span>`;
  const avatar = (st) => st.photo_id ? `<img class="avatar" src="/img/${h(st.photo_id)}" alt="">` : `<span class="avatar">${h(initials(st.name))}</span>`;
  const table = (head, rows, minW) => `<div class="table-wrap"><table ${minW ? `style="min-width:${minW}px"` : ''}><thead><tr>${head.map((x) => `<th>${x}</th>`).join('')}</tr></thead><tbody>${rows || `<tr><td colspan="${head.length}"><div class="empty">Nothing here yet.</div></td></tr>`}</tbody></table></div>`;

  async function allStudents() { return (await api('/api/admin/students')).students; }
  const studentOpts = (list, sel) => '<option value="">Choose student…</option>' + list.map((s) => `<option value="${s.id}" ${String(sel) === String(s.id) ? 'selected' : ''}>${h(s.name)} (${h(s.admission_no)})${s.class_name ? ' · ' + h(s.class_name) : ''}</option>`).join('');

  function suggestAdmission(list) {
    let max = 0;
    for (const s of list) { const m = /^NKPS0*(\d+)$/i.exec(s.admission_no); if (m) max = Math.max(max, Number(m[1])); }
    return 'NKPS' + String(max + 1).padStart(3, '0');
  }

  // ================= DASHBOARD =================
  async function vDashboard() {
    const d = await api('/api/admin/overview');
    SHELL.setBadge('inquiries', d.new_inquiries);
    const maxN = Math.max(1, ...d.class_counts.map((c) => c.n));
    C().innerHTML = `
      <div class="stats">
        ${stat('Total Students', d.total_students, 'students', '#1e3a6e', 'var(--sky)')}
        ${stat('Active Students', d.active_students, 'check', '#2e7a3d', 'var(--leaf-soft)')}
        ${stat('Fees Pending', money(d.fees_due_total), 'money', '#cf6f10', 'var(--tang-soft)')}
        ${stat('New Enquiries', d.new_inquiries, 'mail', '#c98f00', 'var(--sun-soft)')}
      </div>
      <div class="grid-2">
        <div class="card"><h3>Class-wise Students</h3>
          ${d.class_counts.map((c) => `<div style="margin-bottom:13px"><div style="display:flex;justify-content:space-between;font-weight:800;font-size:.9rem;margin-bottom:4px"><span>${h(c.name)}</span><span>${c.n}</span></div><div class="progress"><i style="width:${(c.n / maxN) * 100}%"></i></div></div>`).join('') || '<div class="empty">No classes yet.</div>'}
        </div>
        <div class="card"><h3>Recent Admissions</h3>
          ${d.recent_admissions.length ? d.recent_admissions.map((s) => `<div class="who" style="padding:9px 0;border-bottom:1px solid #f4ecdd"><span class="avatar">${h(initials(s.name))}</span><span style="flex:1;min-width:0"><b>${h(s.name)}</b><small>${h(s.admission_no)} · ${fmtDate(s.admission_date)}</small></span></div>`).join('') : '<div class="empty"><span class="big">🎒</span>No students yet. Add your first child from the Students tab.</div>'}
        </div>
      </div>
      <div class="card"><h3>Quick Actions</h3>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn btn-primary btn-sm" data-q="student">${icon('plus', 15)} Add Child</button>
          <button class="btn btn-sun btn-sm" data-q="photo">${icon('camera', 15)} Upload Photo</button>
          <button class="btn btn-leaf btn-sm" data-q="notice">${icon('bell', 15)} New Notice</button>
          <button class="btn btn-ghost btn-sm" data-q="inquiries">${icon('mail', 15)} Enquiries (${d.new_inquiries} new)</button>
        </div>
        <div class="alert info" style="margin-top:16px">${icon('info', 18)} Gallery, notices and website text go live on the website <b>immediately</b> after saving — no redeployment needed.</div>
      </div>`;
    $('[data-q=student]').addEventListener('click', () => studentForm());
    $('[data-q=photo]').addEventListener('click', () => galleryForm());
    $('[data-q=notice]').addEventListener('click', () => noticeForm());
    $('[data-q=inquiries]').addEventListener('click', () => nav('inquiries'));
  }

  // ================= STUDENTS =================
  async function vStudents() {
    C().innerHTML = `
      <div class="toolbar">
        <input class="grow" id="st-q" type="search" placeholder="Search name or admission no…">
        <select id="st-class">${classOpts('', true)}</select>
        <select id="st-status"><option value="">All statuses</option><option value="active">Active</option><option value="inactive">Inactive</option><option value="left">Left</option></select>
        <button class="btn btn-primary" id="st-add">${icon('plus', 16)} Add Child</button>
      </div>
      <div id="st-table"></div>
      <div class="alert info" style="margin-top:16px">${icon('info', 18)} Parents sign in at <b>/parent/</b> using the child's <b>admission number + date of birth</b>. Keep both correct here.</div>`;
    const load = async () => {
      const qs = new URLSearchParams();
      if ($('#st-q').value.trim()) qs.set('q', $('#st-q').value.trim());
      if ($('#st-class').value) qs.set('class_id', $('#st-class').value);
      if ($('#st-status').value) qs.set('status', $('#st-status').value);
      const { students } = await api('/api/admin/students?' + qs);
      $('#st-table').innerHTML = table(['Child', 'Admission No', 'Class', 'Guardian', 'Status', 'Parent PIN', ''],
        students.map((s) => `<tr>
          <td><div class="who">${avatar(s)}<span><b>${h(s.name)}</b><small>DOB ${fmtDate(s.dob)}</small></span></div></td>
          <td><b>${h(s.admission_no)}</b></td><td>${h(s.class_name || '—')}</td>
          <td>${h(s.guardian_name || '—')}<br><small style="color:var(--muted)">${h(s.guardian_phone || '')}</small></td>
          <td>${badge(s.status, s.status === 'active' ? 'green' : s.status === 'left' ? 'gray' : 'yellow')}</td>
          <td>${s.has_pin ? badge('PIN set', 'blue') : badge('DOB only', 'gray')}</td>
          <td><div class="row-actions">
            <button class="icon-btn" data-act="open" data-id="${s.id}" title="Open profile">${icon('eye', 16)}</button>
            <button class="icon-btn" data-act="edit" data-id="${s.id}" title="Edit">${icon('edit', 16)}</button>
            <button class="icon-btn danger" data-act="del" data-id="${s.id}" title="Remove">${icon('trash', 16)}</button>
          </div></td></tr>`).join(''), 760);
      $$('#st-table [data-act]').forEach((b) => b.addEventListener('click', async () => {
        const id = Number(b.dataset.id);
        const st = students.find((x) => x.id === id);
        if (b.dataset.act === 'open') return studentDetail(id);
        if (b.dataset.act === 'edit') return studentForm(st);
        if (await confirmDlg(`Remove ${st.name} (${st.admission_no})? The student is archived and parent login stops. Unpaid fees are removed from active fees and the dashboard total; paid fees and results history are kept.`)) {
          try {
            const result = await api('/api/admin/students/' + id, { method: 'DELETE' });
            const count = Number(result.pending_fees_archived || 0);
            toast(`Student removed. ${count} unpaid fee record(s) cleared from active fees.`);
            load();
          } catch (e) { toast(e.message, 'bad'); }
        }
      }));
    };
    let t; $('#st-q').addEventListener('input', () => { clearTimeout(t); t = setTimeout(load, 300); });
    $('#st-class').addEventListener('change', load); $('#st-status').addEventListener('change', load);
    $('#st-add').addEventListener('click', async () => studentForm(null, await allStudents()));
    await load();
  }

  async function studentForm(st, allList) {
    const isEdit = Boolean(st);
    if (isEdit) st = (await api('/api/admin/students/' + st.id)).student;
    const suggested = isEdit ? st.admission_no : suggestAdmission(allList || await allStudents());
    const m = modal(isEdit ? 'Edit Child' : 'Add New Child', `
      <div class="form-grid">
        <div class="field full"><label>Child's full name *</label><input id="f-name" maxlength="80" value="${h(st?.name || '')}"></div>
        <div class="field"><label>Admission number * (parent login ID)</label><input id="f-adm" maxlength="30" value="${h(suggested)}"><div class="hint">You decide this. Must be unique.</div></div>
        <div class="field"><label>Class *</label><select id="f-class">${classOpts(st?.class_id)}</select></div>
        <div class="field"><label>Date of birth * (parent login)</label><input id="f-dob" type="date" value="${h(st?.dob || '')}"></div>
        <div class="field"><label>Admission date</label><input id="f-adate" type="date" value="${h(st?.admission_date || today())}"></div>
        <div class="field"><label>Guardian name</label><input id="f-gname" maxlength="80" value="${h(st?.guardian_name || '')}"></div>
        <div class="field"><label>Guardian phone</label><input id="f-gphone" maxlength="18" value="${h(st?.guardian_phone || '')}"></div>
        <div class="field full"><label>Address</label><input id="f-addr" maxlength="250" value="${h(st?.address || '')}"></div>
        <div class="field full"><label>Notes (private)</label><textarea id="f-notes" maxlength="1000">${h(st?.notes || '')}</textarea></div>
        ${isEdit ? `<div class="field"><label>Status</label><select id="f-status"><option value="active" ${st.status === 'active' ? 'selected' : ''}>Active</option><option value="inactive" ${st.status === 'inactive' ? 'selected' : ''}>Inactive</option><option value="left" ${st.status === 'left' ? 'selected' : ''}>Left school</option></select></div>` : `<div class="field"><label>Parent PIN (optional, 4–8 digits)</label><input id="f-pin" inputmode="numeric" maxlength="8" placeholder="Leave empty for DOB-only login"><div class="hint">Extra safety beyond admission no + DOB.</div></div>`}
        <div class="field full"><label>Photo (optional)</label>
          <div style="display:flex;gap:14px;align-items:center">
            ${st?.photo_id ? `<img class="photo-preview" id="f-prev" src="/img/${h(st.photo_id)}">` : '<img class="photo-preview" id="f-prev" hidden>'}
            <input id="f-photo" type="file" accept="image/jpeg,image/png,image/webp">
            ${st?.photo_id ? '<button class="btn btn-ghost btn-sm" id="f-photo-clear" type="button">Remove</button>' : ''}
          </div></div>
      </div>`, { wide: true });
    let photoData; let photoCleared = false;
    $('#f-photo', m.el).addEventListener('change', async (ev) => {
      const file = ev.target.files[0]; if (!file) return;
      try { photoData = await compressImage(file, { maxDim: 600 }); const p = $('#f-prev', m.el); p.src = photoData; p.hidden = false; } catch (e) { toast(e.message, 'bad'); ev.target.value = ''; }
    });
    $('#f-photo-clear', m.el)?.addEventListener('click', () => { photoCleared = true; photoData = null; $('#f-prev', m.el).hidden = true; });
    m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">${isEdit ? 'Save Changes' : 'Add Child & Activate Login'}</button>`;
    $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
    $('[data-a=save]', m.foot).addEventListener('click', async (ev) => {
      const btn = ev.target; btn.disabled = true;
      const body = {
        name: $('#f-name', m.el).value.trim(), admission_no: $('#f-adm', m.el).value.trim(),
        class_id: $('#f-class', m.el).value, dob: $('#f-dob', m.el).value, admission_date: $('#f-adate', m.el).value,
        guardian_name: $('#f-gname', m.el).value.trim(), guardian_phone: $('#f-gphone', m.el).value.trim(),
        address: $('#f-addr', m.el).value.trim(), notes: $('#f-notes', m.el).value.trim(),
      };
      if (isEdit) body.status = $('#f-status', m.el).value; else if ($('#f-pin', m.el).value.trim()) body.parent_pin = $('#f-pin', m.el).value.trim();
      if (photoData) body.photo = photoData; else if (photoCleared) body.photo = null;
      try {
        if (isEdit) await api('/api/admin/students/' + st.id, { method: 'PUT', body });
        else await api('/api/admin/students', { method: 'POST', body });
        toast(isEdit ? 'Student updated.' : `Added! Parent can now login with ${body.admission_no} + date of birth.`);
        m.close(); nav('students');
      } catch (e) { toast(e.message, 'bad'); btn.disabled = false; }
    });
  }

  async function studentDetail(id) {
    const { student: st } = await api('/api/admin/students/' + id);
    const m = modal(st.name, `
      <div style="display:flex;gap:16px;align-items:center;margin-bottom:16px;flex-wrap:wrap">
        ${st.photo_id ? `<img class="photo-preview" src="/img/${h(st.photo_id)}">` : `<span class="avatar" style="width:64px;height:64px;font-size:1.2rem">${h(initials(st.name))}</span>`}
        <div style="flex:1;min-width:200px"><b class="serif" style="font-size:1.2rem">${h(st.name)}</b><div style="color:var(--muted);font-weight:700;font-size:.88rem">${h(st.admission_no)} · ${h(st.class_name || '')}</div></div>
        <button class="btn btn-ghost btn-sm" id="d-pin">${icon('key', 15)} Parent PIN</button>
        <button class="btn btn-ghost btn-sm" id="d-edit">${icon('edit', 15)} Edit</button>
      </div>
      <dl class="kv" style="margin-bottom:18px">
        <dt>Date of birth</dt><dd>${fmtDate(st.dob)}</dd>
        <dt>Admission date</dt><dd>${fmtDate(st.admission_date)}</dd>
        <dt>Guardian</dt><dd>${h(st.guardian_name || '—')} · ${h(st.guardian_phone || '—')}</dd>
        <dt>Address</dt><dd>${h(st.address || '—')}</dd>
        <dt>Status</dt><dd>${badge(st.status, st.status === 'active' ? 'green' : 'yellow')}</dd>
        ${st.notes ? `<dt>Notes</dt><dd>${h(st.notes)}</dd>` : ''}
      </dl>
      <div class="tabs"><button data-tab="fees" class="active">Fees</button><button data-tab="results">Results</button><button data-tab="att">Attendance</button></div>
      <div id="d-tab"></div>`, { wide: true });
    $('#d-edit', m.el).addEventListener('click', () => { m.close(); studentForm(st); });
    $('#d-pin', m.el).addEventListener('click', () => pinModal(st));
    const tabs = $$('[data-tab]', m.el);
    tabs.forEach((b) => b.addEventListener('click', () => { tabs.forEach((x) => x.classList.toggle('active', x === b)); showTab(b.dataset.tab); }));
    async function showTab(tab) {
      const box = $('#d-tab', m.el);
      box.innerHTML = '<div class="empty">Loading…</div>';
      if (tab === 'fees') {
        const { fees } = await api('/api/admin/fees?student_id=' + id);
        box.innerHTML = `
          <div class="form-grid" style="margin-bottom:10px">
            <div class="field"><label>Title</label><input id="tf-title" placeholder="e.g. Monthly Fee — June" maxlength="100"></div>
            <div class="field"><label>Amount (₹)</label><input id="tf-amt" type="number" min="0" step="0.01"></div>
            <div class="field"><label>Due date</label><input id="tf-due" type="date"></div>
            <div class="field"><label>Status</label><select id="tf-status"><option value="due">Due</option><option value="paid">Paid</option></select></div>
            <div class="field full"><button class="btn btn-primary btn-sm" id="tf-add">${icon('plus', 15)} Add Fee Record</button></div>
          </div>
          ${table(['Title', 'Amount', 'Due', 'Status', ''], fees.map((f) => `<tr><td><b>${h(f.title)}</b>${f.note ? `<br><small style="color:var(--muted)">${h(f.note)}</small>` : ''}</td><td>${money(f.amount)}</td><td>${fmtDate(f.due_date)}</td><td>${f.status === 'paid' ? badge('Paid ' + fmtDate(f.paid_on), 'green') : badge('Due', 'yellow')}</td><td><div class="row-actions">${f.status === 'due' ? `<button class="btn btn-leaf btn-sm" data-paid="${f.id}">Mark Paid</button>` : ''}<button class="icon-btn danger" data-delfee="${f.id}">${icon('trash', 15)}</button></div></td></tr>`).join(''), 560)}`;
        $('#tf-add', box).addEventListener('click', async () => {
          try {
            await api('/api/admin/fees', { method: 'POST', body: { student_id: id, title: $('#tf-title', box).value.trim(), amount: $('#tf-amt', box).value, due_date: $('#tf-due', box).value || null, status: $('#tf-status', box).value } });
            toast('Fee added — visible to parent now.'); showTab('fees');
          } catch (e) { toast(e.message, 'bad'); }
        });
        $$('[data-paid]', box).forEach((b) => b.addEventListener('click', async () => {
          const f = fees.find((x) => x.id === Number(b.dataset.paid));
          try { await api('/api/admin/fees/' + f.id, { method: 'PUT', body: { ...f, status: 'paid', paid_on: today() } }); toast('Marked paid.'); showTab('fees'); } catch (e) { toast(e.message, 'bad'); }
        }));
        $$('[data-delfee]', box).forEach((b) => b.addEventListener('click', async () => {
          if (!(await confirmDlg('Delete this fee record?'))) return;
          try { await api('/api/admin/fees/' + b.dataset.delfee, { method: 'DELETE' }); toast('Fee deleted.'); showTab('fees'); } catch (e) { toast(e.message, 'bad'); }
        }));
      }
      if (tab === 'results') {
        const { results } = await api('/api/admin/results?student_id=' + id);
        box.innerHTML = `
          <div class="form-grid" style="margin-bottom:10px">
            <div class="field"><label>Exam</label><input id="tr-exam" placeholder="e.g. Unit Test 1" maxlength="80"></div>
            <div class="field"><label>Subject</label><input id="tr-sub" placeholder="e.g. English" maxlength="60"></div>
            <div class="field"><label>Marks</label><input id="tr-marks" type="number" min="0" step="0.5"></div>
            <div class="field"><label>Out of</label><input id="tr-max" type="number" min="1" step="0.5" value="100"></div>
            <div class="field full"><button class="btn btn-primary btn-sm" id="tr-add">${icon('plus', 15)} Add Result</button></div>
          </div>
          ${table(['Exam', 'Subject', 'Marks', ''], results.map((r) => `<tr><td><b>${h(r.exam)}</b>${r.term ? `<br><small style="color:var(--muted)">${h(r.term)}</small>` : ''}</td><td>${h(r.subject)}</td><td><b>${r.marks}</b> / ${r.max_marks}</td><td><div class="row-actions"><button class="icon-btn danger" data-delres="${r.id}">${icon('trash', 15)}</button></div></td></tr>`).join(''), 480)}`;
        $('#tr-add', box).addEventListener('click', async () => {
          try {
            await api('/api/admin/results', { method: 'POST', body: { student_id: id, exam: $('#tr-exam', box).value.trim(), subject: $('#tr-sub', box).value.trim(), marks: $('#tr-marks', box).value, max_marks: $('#tr-max', box).value } });
            toast('Result added — visible to parent now.'); showTab('results');
          } catch (e) { toast(e.message, 'bad'); }
        });
        $$('[data-delres]', box).forEach((b) => b.addEventListener('click', async () => {
          if (!(await confirmDlg('Delete this result entry?'))) return;
          try { await api('/api/admin/results/' + b.dataset.delres, { method: 'DELETE' }); toast('Result deleted.'); showTab('results'); } catch (e) { toast(e.message, 'bad'); }
        }));
      }
      if (tab === 'att') {
        const att = await fetchAttendanceFor(id);
        const total = att.length, present = att.filter((a) => a.status !== 'A').length;
        box.innerHTML = `
          <div class="alert ${total && present / total >= 0.85 ? 'ok' : 'info'}" style="margin-bottom:12px">${icon('calendar', 18)} ${total ? `<b>${present}/${total}</b> days present (${Math.round((present / total) * 100)}%)` : 'No attendance marked yet.'}</div>
          ${table(['Date', 'Status'], att.slice(0, 60).map((a) => `<tr><td>${fmtDate(a.date)}</td><td>${a.status === 'P' ? badge('Present', 'green') : a.status === 'L' ? badge('Late', 'yellow') : badge('Absent', 'red')}</td></tr>`).join(''), 300)}`;
      }
    }
    showTab('fees');
  }

  async function fetchAttendanceFor(studentId) {
    const { attendance } = await api(`/api/admin/student-attendance?student_id=${studentId}`);
    return attendance || [];
  }

  function pinModal(st) {
    const m = modal('Parent PIN — ' + st.name, `
      <p style="color:var(--muted);font-weight:600;margin-bottom:14px">Optional extra security. When set, parents need <b>admission number + DOB + this PIN</b>. Share it privately with the guardian.</p>
      <div class="field"><label>New PIN (4–8 digits)</label><input id="pin-val" inputmode="numeric" maxlength="8" placeholder="e.g. 4321"></div>
      ${st.has_pin ? `<div class="alert warn">${icon('info', 16)} A PIN is currently set. Saving a new one replaces it; "Remove PIN" goes back to DOB-only login.</div>` : ''}`);
    m.foot.innerHTML = `${st.has_pin ? '<button class="btn btn-danger" data-a="clear">Remove PIN</button>' : ''}<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">Save PIN</button>`;
    $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
    $('[data-a=clear]', m.foot)?.addEventListener('click', async () => {
      try { await api(`/api/admin/students/${st.id}/pin`, { method: 'POST', body: { pin: null } }); toast('PIN removed.'); m.close(); } catch (e) { toast(e.message, 'bad'); }
    });
    $('[data-a=save]', m.foot).addEventListener('click', async () => {
      try { await api(`/api/admin/students/${st.id}/pin`, { method: 'POST', body: { pin: $('#pin-val', m.el).value.trim() } }); toast('PIN saved. Existing parent sessions signed out.'); m.close(); } catch (e) { toast(e.message, 'bad'); }
    });
  }

  // ================= TEACHERS =================
  async function vTeachers() {
    const { teachers, teacher_classes } = await api('/api/admin/teachers');
    C().innerHTML = `
      <div class="toolbar"><span class="grow" style="font-weight:700;color:var(--muted)">Teachers sign in at <b>/teacher/</b> with the username you create here.</span><button class="btn btn-primary" id="t-add">${icon('plus', 16)} Add Teacher</button></div>
      ${table(['Teacher', 'Username', 'Phone', 'Classes', 'Status', 'Last Login', ''], teachers.map((t) => `<tr>
        <td><div class="who"><span class="avatar">${h(initials(t.name))}</span><span><b>${h(t.name)}</b><small>${h(t.qualification || '')}</small></span></div></td>
        <td><b>${h(t.username || '—')}</b></td><td>${h(t.phone || '—')}</td><td style="max-width:180px">${h(t.class_names || 'None')}</td>
        <td>${t.active && t.account_active ? badge('Active', 'green') : badge('Disabled', 'red')}</td>
        <td><small>${t.last_login ? h(t.last_login) : 'Never'}</small></td>
        <td><div class="row-actions">
          <button class="icon-btn" data-act="edit" data-id="${t.id}" title="Edit">${icon('edit', 16)}</button>
          <button class="icon-btn" data-act="pw" data-id="${t.id}" title="Reset password">${icon('key', 16)}</button>
          <button class="icon-btn danger" data-act="del" data-id="${t.id}" title="Remove">${icon('trash', 16)}</button>
        </div></td></tr>`).join(''), 820)}`;
    $('#t-add').addEventListener('click', () => teacherForm());
    $$('#content [data-act]').forEach((b) => b.addEventListener('click', async () => {
      const t = teachers.find((x) => x.id === Number(b.dataset.id));
      const assigned = teacher_classes.filter((x) => x.teacher_id === t.id).map((x) => x.class_id);
      if (b.dataset.act === 'edit') return teacherForm(t, assigned);
      if (b.dataset.act === 'pw') return resetPwModal('teacher', t.id, t.username);
      if (await confirmDlg(`Remove ${t.name}? Their login will stop working immediately.`)) {
        try { await api('/api/admin/teachers/' + t.id, { method: 'DELETE' }); toast('Teacher removed.'); nav('teachers'); } catch (e) { toast(e.message, 'bad'); }
      }
    }));
  }

  function teacherForm(t, assigned = []) {
    const isEdit = Boolean(t);
    const m = modal(isEdit ? 'Edit Teacher' : 'Add Teacher', `
      <div class="form-grid">
        <div class="field full"><label>Full name *</label><input id="t-name" maxlength="80" value="${h(t?.name || '')}"></div>
        <div class="field"><label>Phone</label><input id="t-phone" maxlength="18" value="${h(t?.phone || '')}"></div>
        <div class="field"><label>Email</label><input id="t-email" maxlength="120" value="${h(t?.email || '')}"></div>
        <div class="field full"><label>Qualification</label><input id="t-qual" maxlength="120" value="${h(t?.qualification || '')}" placeholder="e.g. B.Ed, NTT"></div>
        ${!isEdit ? `<div class="field"><label>Login username *</label><input id="t-user" maxlength="32" placeholder="e.g. teacher.sunita"></div>
        <div class="field"><label>Login password *</label><input id="t-pass" type="text" minlength="8" placeholder="Min 8 characters — share privately"></div>` : ''}
        <div class="field full"><label>Assigned classes</label>
          <div style="display:flex;gap:14px;flex-wrap:wrap">${CLASSES.map((c) => `<label class="check"><input type="checkbox" value="${c.id}" ${assigned.includes(c.id) ? 'checked' : ''}> ${h(c.name)}</label>`).join('')}</div>
        </div>
        ${isEdit ? `<div class="field full"><label class="check"><input id="t-active" type="checkbox" ${t.active ? 'checked' : ''}> Account active</label></div>` : ''}
      </div>`);
    m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">${isEdit ? 'Save' : 'Create Teacher'}</button>`;
    $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
    $('[data-a=save]', m.foot).addEventListener('click', async (ev) => {
      ev.target.disabled = true;
      const body = {
        name: $('#t-name', m.el).value.trim(), phone: $('#t-phone', m.el).value.trim(), email: $('#t-email', m.el).value.trim(),
        qualification: $('#t-qual', m.el).value.trim(),
        class_ids: $$('.field input[type=checkbox]:checked', m.el).map((c) => Number(c.value)),
      };
      if (isEdit) body.active = $('#t-active', m.el).checked;
      else { body.username = $('#t-user', m.el).value.trim(); body.password = $('#t-pass', m.el).value; }
      try {
        if (isEdit) await api('/api/admin/teachers/' + t.id, { method: 'PUT', body });
        else await api('/api/admin/teachers', { method: 'POST', body });
        toast(isEdit ? 'Teacher updated.' : 'Teacher created — they can sign in now.'); m.close(); nav('teachers');
      } catch (e) { toast(e.message, 'bad'); ev.target.disabled = false; }
    });
  }

  function resetPwModal(kind, id, username) {
    const m = modal('Reset Password — ' + username, `
      <div class="field"><label>New password (min 8 characters)</label><input id="rp-pass" type="text" minlength="8"></div>
      <div class="alert warn">${icon('info', 16)} All active sessions of this account will be signed out. Share the new password privately.</div>`);
    m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">Reset Password</button>`;
    $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
    $('[data-a=save]', m.foot).addEventListener('click', async () => {
      try {
        if (kind === 'teacher') await api(`/api/admin/teachers/${id}/reset-password`, { method: 'POST', body: { password: $('#rp-pass', m.el).value } });
        else { const t = await api('/api/admin/admins'); const acc = t.admins.find((a) => a.id === id); await api('/api/admin/admins/' + id, { method: 'PUT', body: { name: acc.name, active: true, password: $('#rp-pass', m.el).value } }); }
        toast('Password reset.'); m.close();
      } catch (e) { toast(e.message, 'bad'); }
    });
  }

  // ================= CLASSES =================
  async function vClasses() {
    CLASSES = (await api('/api/admin/classes')).classes;
    C().innerHTML = `
      <div class="toolbar"><span class="grow"></span><button class="btn btn-primary" id="c-add">${icon('plus', 16)} Add Class</button></div>
      ${table(['Order', 'Class', ''], CLASSES.map((c) => `<tr><td>${c.sort_order}</td><td><b>${h(c.name)}</b></td><td><div class="row-actions"><button class="icon-btn" data-edit="${c.id}">${icon('edit', 16)}</button><button class="icon-btn danger" data-del="${c.id}">${icon('trash', 16)}</button></div></td></tr>`).join(''), 360)}`;
    const form = (c) => {
      const m = modal(c ? 'Edit Class' : 'Add Class', `
        <div class="field"><label>Class name</label><input id="c-name" maxlength="40" value="${h(c?.name || '')}"></div>
        <div class="field"><label>Sort order</label><input id="c-order" type="number" min="0" max="999" value="${c?.sort_order ?? 99}"></div>`);
      m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">Save</button>`;
      $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
      $('[data-a=save]', m.foot).addEventListener('click', async () => {
        try {
          const body = { name: $('#c-name', m.el).value.trim(), sort_order: $('#c-order', m.el).value };
          if (c) await api('/api/admin/classes/' + c.id, { method: 'PUT', body }); else await api('/api/admin/classes', { method: 'POST', body });
          toast('Saved.'); m.close(); nav('classes');
        } catch (e) { toast(e.message, 'bad'); }
      });
    };
    $('#c-add').addEventListener('click', () => form());
    $$('[data-edit]').forEach((b) => b.addEventListener('click', () => form(CLASSES.find((c) => c.id === Number(b.dataset.edit)))));
    $$('[data-del]').forEach((b) => b.addEventListener('click', async () => {
      if (!(await confirmDlg('Delete this class? Only possible when it has no students.'))) return;
      try { await api('/api/admin/classes/' + b.dataset.del, { method: 'DELETE' }); toast('Class deleted.'); nav('classes'); } catch (e) { toast(e.message, 'bad'); }
    }));
  }

  // ================= ATTENDANCE =================
  async function vAttendance() {
    C().innerHTML = `
      <div class="toolbar">
        <select id="a-class">${classOpts(CLASSES[0]?.id)}</select>
        <input id="a-date" type="date" value="${today()}">
        <button class="btn btn-ghost" id="a-load">Load</button>
        <span class="grow"></span>
        <button class="btn btn-leaf btn-sm" id="a-allp">All Present</button>
        <button class="btn btn-primary" id="a-save">${icon('check', 16)} Save Attendance</button>
      </div>
      <div id="a-table"></div>`;
    let students = [], marks = {};
    const load = async () => {
      const cid = $('#a-class').value, date = $('#a-date').value;
      if (!cid) return;
      const d = await api(`/api/admin/attendance?class_id=${cid}&date=${date}`);
      students = d.students; marks = {};
      d.attendance.forEach((a) => { marks[a.student_id] = a.status; });
      draw();
    };
    const draw = () => {
      $('#a-table').innerHTML = table(['Child', 'Admission No', 'Attendance'], students.map((s) => `<tr>
        <td><div class="who"><span class="avatar">${h(initials(s.name))}</span><b>${h(s.name)}</b></div></td>
        <td>${h(s.admission_no)}</td>
        <td><div class="att-btns" data-sid="${s.id}">
          <button data-s="P" class="${marks[s.id] === 'P' ? 'on-P' : ''}" title="Present">P</button>
          <button data-s="A" class="${marks[s.id] === 'A' ? 'on-A' : ''}" title="Absent">A</button>
          <button data-s="L" class="${marks[s.id] === 'L' ? 'on-L' : ''}" title="Late">L</button>
        </div></td></tr>`).join(''), 480);
      $$('#a-table .att-btns button').forEach((b) => b.addEventListener('click', () => {
        const sid = Number(b.parentElement.dataset.sid);
        marks[sid] = b.dataset.s;
        [...b.parentElement.children].forEach((x) => x.className = x === b ? 'on-' + b.dataset.s : '');
      }));
    };
    $('#a-load').addEventListener('click', load);
    $('#a-class').addEventListener('change', load);
    $('#a-allp').addEventListener('click', () => { students.forEach((s) => { marks[s.id] = 'P'; }); draw(); });
    $('#a-save').addEventListener('click', async () => {
      const records = students.filter((s) => marks[s.id]).map((s) => ({ student_id: s.id, status: marks[s.id] }));
      if (!records.length) return toast('Mark at least one child first.', 'bad');
      try { await api('/api/admin/attendance', { method: 'POST', body: { class_id: Number($('#a-class').value), date: $('#a-date').value, records } }); toast(`Attendance saved for ${records.length} children — parents can see it now.`); } catch (e) { toast(e.message, 'bad'); }
    });
    await load();
  }

  // ================= HOMEWORK =================
  async function vHomework() {
    const { homework } = await api('/api/admin/homework');
    C().innerHTML = `
      <div class="toolbar"><span class="grow"></span><button class="btn btn-primary" id="hw-add">${icon('plus', 16)} Give Homework</button></div>
      ${table(['Title', 'Class', 'Due', 'Given On', ''], homework.map((x) => `<tr><td><b>${h(x.title)}</b>${x.details ? `<br><small style="color:var(--muted)">${h(x.details.slice(0, 90))}${x.details.length > 90 ? '…' : ''}</small>` : ''}</td><td>${badge(x.class_name, 'blue')}</td><td>${fmtDate(x.due_date)}</td><td>${fmtDate(x.created_at)}</td><td><div class="row-actions"><button class="icon-btn" data-edit="${x.id}">${icon('edit', 16)}</button><button class="icon-btn danger" data-del="${x.id}">${icon('trash', 16)}</button></div></td></tr>`).join(''), 620)}`;
    const form = (x) => {
      const m = modal(x ? 'Edit Homework' : 'Give Homework', `
        <div class="field"><label>Class</label><select id="hw-class">${classOpts(x?.class_id)}</select></div>
        <div class="field"><label>Title</label><input id="hw-title" maxlength="140" value="${h(x?.title || '')}" placeholder="e.g. Practice writing A–E"></div>
        <div class="field"><label>Details</label><textarea id="hw-details" maxlength="2000">${h(x?.details || '')}</textarea></div>
        <div class="field"><label>Due date</label><input id="hw-due" type="date" value="${h(x?.due_date || '')}"></div>`);
      m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">Save</button>`;
      $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
      $('[data-a=save]', m.foot).addEventListener('click', async () => {
        const body = { class_id: $('#hw-class', m.el).value, title: $('#hw-title', m.el).value.trim(), details: $('#hw-details', m.el).value.trim(), due_date: $('#hw-due', m.el).value || null };
        try { if (x) await api('/api/admin/homework/' + x.id, { method: 'PUT', body }); else await api('/api/admin/homework', { method: 'POST', body }); toast('Homework saved — parents see it instantly.'); m.close(); nav('homework'); } catch (e) { toast(e.message, 'bad'); }
      });
    };
    $('#hw-add').addEventListener('click', () => form());
    $$('[data-edit]').forEach((b) => b.addEventListener('click', () => form(homework.find((x) => x.id === Number(b.dataset.edit)))));
    $$('[data-del]').forEach((b) => b.addEventListener('click', async () => {
      if (!(await confirmDlg('Delete this homework?'))) return;
      try { await api('/api/admin/homework/' + b.dataset.del, { method: 'DELETE' }); toast('Deleted.'); nav('homework'); } catch (e) { toast(e.message, 'bad'); }
    }));
  }

  // ================= FEES =================
  async function vFees() {
    const list = await allStudents();
    C().innerHTML = `
      <div class="toolbar"><select id="fe-student" class="grow">${studentOpts(list)}</select><button class="btn btn-primary" id="fe-add" disabled>${icon('plus', 16)} Add Fee</button></div>
      <div id="fe-body"><div class="empty"><span class="big">💰</span>Choose a student to see and manage fee records.</div></div>`;
    const load = async () => {
      const sid = $('#fe-student').value;
      $('#fe-add').disabled = !sid;
      if (!sid) return;
      const { fees } = await api('/api/admin/fees?student_id=' + sid);
      const due = fees.filter((f) => f.status === 'due').reduce((a, f) => a + f.amount, 0);
      const paid = fees.filter((f) => f.status === 'paid').reduce((a, f) => a + f.amount, 0);
      $('#fe-body').innerHTML = `
        <div class="stats" style="grid-template-columns:1fr 1fr">
          ${stat('Pending', money(due), 'money', '#cf6f10', 'var(--tang-soft)')}
          ${stat('Collected', money(paid), 'check', '#2e7a3d', 'var(--leaf-soft)')}
        </div>
        ${table(['Title', 'Amount', 'Due Date', 'Status', ''], fees.map((f) => `<tr><td><b>${h(f.title)}</b>${f.note ? `<br><small style="color:var(--muted)">${h(f.note)}</small>` : ''}</td><td>${money(f.amount)}</td><td>${fmtDate(f.due_date)}</td><td>${f.status === 'paid' ? badge('Paid ' + fmtDate(f.paid_on), 'green') : badge('Due', 'yellow')}</td><td><div class="row-actions">${f.status === 'due' ? `<button class="btn btn-leaf btn-sm" data-paid="${f.id}">Mark Paid</button>` : `<button class="btn btn-ghost btn-sm" data-unpaid="${f.id}">Undo</button>`}<button class="icon-btn danger" data-del="${f.id}">${icon('trash', 15)}</button></div></td></tr>`).join(''), 620)}`;
      $$('[data-paid]').forEach((b) => b.addEventListener('click', async () => { const f = fees.find((x) => x.id === Number(b.dataset.paid)); try { await api('/api/admin/fees/' + f.id, { method: 'PUT', body: { ...f, status: 'paid', paid_on: today() } }); toast('Marked paid.'); load(); } catch (e) { toast(e.message, 'bad'); } }));
      $$('[data-unpaid]').forEach((b) => b.addEventListener('click', async () => { const f = fees.find((x) => x.id === Number(b.dataset.unpaid)); try { await api('/api/admin/fees/' + f.id, { method: 'PUT', body: { ...f, status: 'due', paid_on: null } }); load(); } catch (e) { toast(e.message, 'bad'); } }));
      $$('#fe-body [data-del]').forEach((b) => b.addEventListener('click', async () => { if (!(await confirmDlg('Delete this fee record?'))) return; try { await api('/api/admin/fees/' + b.dataset.del, { method: 'DELETE' }); toast('Deleted.'); load(); } catch (e) { toast(e.message, 'bad'); } }));
    };
    $('#fe-student').addEventListener('change', load);
    $('#fe-add').addEventListener('click', () => {
      const sid = Number($('#fe-student').value);
      const m = modal('Add Fee Record', `
        <div class="field"><label>Title</label><input id="nf-title" maxlength="100" placeholder="e.g. Monthly Fee — June"></div>
        <div class="form-grid">
          <div class="field"><label>Amount (₹)</label><input id="nf-amt" type="number" min="0" step="0.01"></div>
          <div class="field"><label>Due date</label><input id="nf-due" type="date"></div>
          <div class="field"><label>Status</label><select id="nf-status"><option value="due">Due</option><option value="paid">Already paid</option></select></div>
          <div class="field"><label>Note (optional)</label><input id="nf-note" maxlength="300"></div>
        </div>`);
      m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">Add Fee</button>`;
      $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
      $('[data-a=save]', m.foot).addEventListener('click', async () => {
        try { await api('/api/admin/fees', { method: 'POST', body: { student_id: sid, title: $('#nf-title', m.el).value.trim(), amount: $('#nf-amt', m.el).value, due_date: $('#nf-due', m.el).value || null, status: $('#nf-status', m.el).value, note: $('#nf-note', m.el).value.trim() } }); toast('Fee added — parent can see it now.'); m.close(); load(); } catch (e) { toast(e.message, 'bad'); }
      });
    });
  }

  // ================= RESULTS =================
  async function vResults() {
    const list = await allStudents();
    C().innerHTML = `
      <div class="toolbar">
        <select id="re-student" class="grow">${studentOpts(list)}</select>
        <button class="btn btn-ghost" id="re-bulk">${icon('students', 16)} Bulk Entry (whole class)</button>
      </div>
      <div id="re-body"><div class="empty"><span class="big">📈</span>Choose a student to see results, or use bulk entry for a full class.</div></div>`;
    const load = async () => {
      const sid = $('#re-student').value;
      if (!sid) return;
      const { results } = await api('/api/admin/results?student_id=' + sid);
      $('#re-body').innerHTML = `
        <div class="card"><h3>Add Result <span class="spacer"></span></h3>
          <div class="form-grid">
            <div class="field"><label>Exam</label><input id="nr-exam" maxlength="80" placeholder="e.g. Half Yearly"></div>
            <div class="field"><label>Subject</label><input id="nr-sub" maxlength="60" placeholder="e.g. English"></div>
            <div class="field"><label>Marks</label><input id="nr-marks" type="number" min="0" step="0.5"></div>
            <div class="field"><label>Out of</label><input id="nr-max" type="number" min="1" value="100"></div>
            <div class="field"><label>Term (optional)</label><input id="nr-term" maxlength="40" placeholder="e.g. Term 1"></div>
            <div class="field" style="display:flex;align-items:flex-end"><button class="btn btn-primary" id="nr-add">${icon('plus', 15)} Add</button></div>
          </div>
        </div>
        ${table(['Exam', 'Subject', 'Marks', 'Term', ''], results.map((r) => `<tr><td><b>${h(r.exam)}</b></td><td>${h(r.subject)}</td><td><b>${r.marks}</b> / ${r.max_marks} <small style="color:var(--muted)">(${Math.round((r.marks / r.max_marks) * 100)}%)</small></td><td>${h(r.term || '—')}</td><td><div class="row-actions"><button class="icon-btn danger" data-del="${r.id}">${icon('trash', 15)}</button></div></td></tr>`).join(''), 560)}`;
      $('#nr-add').addEventListener('click', async () => {
        try { await api('/api/admin/results', { method: 'POST', body: { student_id: Number(sid), exam: $('#nr-exam').value.trim(), subject: $('#nr-sub').value.trim(), marks: $('#nr-marks').value, max_marks: $('#nr-max').value, term: $('#nr-term').value.trim() } }); toast('Result added.'); load(); } catch (e) { toast(e.message, 'bad'); }
      });
      $$('#re-body [data-del]').forEach((b) => b.addEventListener('click', async () => { if (!(await confirmDlg('Delete this result?'))) return; try { await api('/api/admin/results/' + b.dataset.del, { method: 'DELETE' }); toast('Deleted.'); load(); } catch (e) { toast(e.message, 'bad'); } }));
    };
    $('#re-student').addEventListener('change', load);
    $('#re-bulk').addEventListener('click', async () => {
      const m = modal('Bulk Result Entry', `
        <div class="form-grid">
          <div class="field"><label>Class</label><select id="b-class">${classOpts('')}</select></div>
          <div class="field"><label>Exam</label><input id="b-exam" maxlength="80" placeholder="e.g. Unit Test 1"></div>
          <div class="field"><label>Subject</label><input id="b-sub" maxlength="60" placeholder="e.g. Maths"></div>
          <div class="field"><label>Maximum marks</label><input id="b-max" type="number" min="1" value="100"></div>
        </div>
        <button class="btn btn-ghost btn-sm" id="b-load" style="margin-bottom:12px">Load Students</button>
        <div id="b-list"></div>`, { wide: true });
      $('#b-load', m.el).addEventListener('click', async () => {
        const cid = $('#b-class', m.el).value;
        if (!cid) return toast('Choose a class.', 'bad');
        const { students } = await api('/api/admin/students?class_id=' + cid + '&status=active');
        $('#b-list', m.el).innerHTML = table(['Child', 'Marks'], students.map((s) => `<tr><td><b>${h(s.name)}</b> <small style="color:var(--muted)">${h(s.admission_no)}</small></td><td><input type="number" min="0" step="0.5" data-marks="${s.id}" style="width:100px;border:2px solid var(--line);border-radius:9px;padding:7px 10px;font-weight:700"></td></tr>`).join(''), 380);
      });
      m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">Save All</button>`;
      $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
      $('[data-a=save]', m.foot).addEventListener('click', async () => {
        const entries = $$('[data-marks]', m.el).filter((i) => i.value !== '').map((i) => ({ student_id: Number(i.dataset.marks), marks: i.value }));
        if (!entries.length) return toast('Enter marks for at least one child.', 'bad');
        try { await api('/api/admin/results/bulk', { method: 'POST', body: { class_id: Number($('#b-class', m.el).value), exam: $('#b-exam', m.el).value.trim(), subject: $('#b-sub', m.el).value.trim(), max_marks: $('#b-max', m.el).value, entries } }); toast(`Saved ${entries.length} results.`); m.close(); } catch (e) { toast(e.message, 'bad'); }
      });
    });
  }

  // ================= GALLERY =================
  async function vGallery() {
    const { gallery } = await api('/api/admin/gallery');
    C().innerHTML = `
      <div class="alert info">${icon('info', 18)} The website shows the <b>first 4 published photos</b> (lowest order number first). Upload, reorder, publish/unpublish — changes appear live.</div>
      <div class="toolbar"><span class="grow"></span><button class="btn btn-primary" id="g-add">${icon('camera', 16)} Upload Photo</button></div>
      <div class="gal-admin-grid" id="g-grid">
        ${gallery.map((g, i) => `
          <div class="gal-admin">
            <div class="ph"><img src="/img/${h(g.image_id)}" alt="${h(g.title)}" loading="lazy"></div>
            <div class="bd"><b>${h(g.title)}</b><small>${fmtDate(g.photo_date)} · order ${g.sort_order}</small></div>
            <div class="ft">
              ${g.published ? badge('Live', 'green') : badge('Hidden', 'gray')}
              <span style="flex:1"></span>
              <button class="icon-btn" data-up="${g.id}" title="Move up" ${i === 0 ? 'disabled' : ''}>${icon('up', 14)}</button>
              <button class="icon-btn" data-down="${g.id}" title="Move down" ${i === gallery.length - 1 ? 'disabled' : ''}>${icon('down', 14)}</button>
              <button class="icon-btn" data-pub="${g.id}" title="${g.published ? 'Unpublish' : 'Publish'}">${icon('eye', 14)}</button>
              <button class="icon-btn" data-edit="${g.id}" title="Edit">${icon('edit', 14)}</button>
              <button class="icon-btn danger" data-del="${g.id}" title="Delete">${icon('trash', 14)}</button>
            </div>
          </div>`).join('') || '<div class="empty" style="grid-column:1/-1"><span class="big">📸</span>No photos yet. Upload the first one!</div>'}
      </div>`;
    $('#g-add').addEventListener('click', () => galleryForm(null, gallery.length));
    const put = async (g, extra) => { await api('/api/admin/gallery/' + g.id, { method: 'PUT', body: { title: g.title, caption: g.caption, photo_date: g.photo_date, sort_order: g.sort_order, published: g.published, ...extra } }); };
    $$('[data-pub]').forEach((b) => b.addEventListener('click', async () => { const g = gallery.find((x) => x.id === Number(b.dataset.pub)); try { await put(g, { published: g.published ? 0 : 1 }); toast(g.published ? 'Photo hidden from website.' : 'Photo is live on the website!'); nav('gallery'); } catch (e) { toast(e.message, 'bad'); } }));
    $$('[data-edit]').forEach((b) => b.addEventListener('click', () => galleryForm(gallery.find((x) => x.id === Number(b.dataset.edit)))));
    $$('[data-del]').forEach((b) => b.addEventListener('click', async () => { if (!(await confirmDlg('Delete this photo permanently?'))) return; try { await api('/api/admin/gallery/' + b.dataset.del, { method: 'DELETE' }); toast('Photo deleted.'); nav('gallery'); } catch (e) { toast(e.message, 'bad'); } }));
    const move = async (g, dir) => {
      const idx = gallery.findIndex((x) => x.id === g.id);
      const other = gallery[idx + dir];
      if (!other) return;
      try {
        await put(g, { sort_order: other.sort_order === g.sort_order ? g.sort_order + dir : other.sort_order });
        await put(other, { sort_order: g.sort_order });
        nav('gallery');
      } catch (e) { toast(e.message, 'bad'); }
    };
    $$('[data-up]').forEach((b) => b.addEventListener('click', () => move(gallery.find((x) => x.id === Number(b.dataset.up)), -1)));
    $$('[data-down]').forEach((b) => b.addEventListener('click', () => move(gallery.find((x) => x.id === Number(b.dataset.down)), 1)));
  }

  async function galleryForm(g, count = 0) {
    const m = modal(g ? 'Edit Photo' : 'Upload Photo', `
      <div class="field"><label>Photo ${g ? '(leave empty to keep current)' : '*'}</label>
        <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">
          <img class="photo-preview" id="g-prev" style="width:110px;height:84px;border-radius:12px" ${g ? `src="/img/${h(g.image_id)}"` : 'hidden'}>
          <input id="g-file" type="file" accept="image/jpeg,image/png,image/webp">
        </div><div class="hint">Auto-compressed for fast loading. JPG/PNG/WebP.</div></div>
      <div class="field"><label>Event title *</label><input id="g-title" maxlength="120" value="${h(g?.title || '')}" placeholder="e.g. Independence Day celebration"></div>
      <div class="field"><label>Caption</label><textarea id="g-caption" maxlength="300">${h(g?.caption || '')}</textarea></div>
      <div class="form-grid">
        <div class="field"><label>Photo date</label><input id="g-date" type="date" value="${h(g?.photo_date || today())}"></div>
        <div class="field"><label>Sort order (smaller = first)</label><input id="g-order" type="number" min="0" max="9999" value="${g?.sort_order ?? (count + 1) * 10}"></div>
      </div>
      <label class="check"><input id="g-pub" type="checkbox" ${!g || g.published ? 'checked' : ''}> Publish on website now</label>`);
    let img = null;
    $('#g-file', m.el).addEventListener('change', async (ev) => {
      const f = ev.target.files[0]; if (!f) return;
      try { img = await compressImage(f, { maxDim: 1400 }); const p = $('#g-prev', m.el); p.src = img; p.hidden = false; } catch (e) { toast(e.message, 'bad'); ev.target.value = ''; }
    });
    m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">${g ? 'Save Changes' : 'Upload'}</button>`;
    $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
    $('[data-a=save]', m.foot).addEventListener('click', async (ev) => {
      ev.target.disabled = true;
      const body = { title: $('#g-title', m.el).value.trim(), caption: $('#g-caption', m.el).value.trim(), photo_date: $('#g-date', m.el).value || null, sort_order: $('#g-order', m.el).value, published: $('#g-pub', m.el).checked };
      if (img) body.image = img;
      if (!g && !img) { toast('Please choose a photo.', 'bad'); ev.target.disabled = false; return; }
      try {
        if (g) await api('/api/admin/gallery/' + g.id, { method: 'PUT', body });
        else await api('/api/admin/gallery', { method: 'POST', body });
        toast(body.published ? 'Photo saved & live on the website!' : 'Photo saved (hidden).'); m.close(); nav('gallery');
      } catch (e) { toast(e.message, 'bad'); ev.target.disabled = false; }
    });
  }

  // ================= NOTICES =================
  async function vNotices() {
    const { notices, server_time } = await api('/api/admin/notices');
    const state = (n) => {
      if (n.status !== 'published') return badge('Draft', 'gray');
      if (n.publish_at && n.publish_at > server_time) return badge('Scheduled', 'blue');
      if (n.expires_at && n.expires_at <= server_time) return badge('Expired', 'red');
      return badge('Live', 'green');
    };
    C().innerHTML = `
      <div class="toolbar"><span class="grow" style="font-weight:700;color:var(--muted)">Published notices appear on the website & parent portal automatically.</span><button class="btn btn-primary" id="n-add">${icon('plus', 16)} New Notice</button></div>
      ${notices.map((n) => `
        <div class="notice-admin">
          <div class="bd">
            <b>${h(n.title)} ${n.pinned ? badge('Pinned', 'yellow') : ''}</b>
            <p>${h(n.body.slice(0, 160))}${n.body.length > 160 ? '…' : ''}</p>
            <div class="meta">${state(n)}
              ${n.publish_at ? `<span class="badge blue">From ${fmtDateTime(n.publish_at)}</span>` : ''}
              ${n.expires_at ? `<span class="badge gray">Until ${fmtDateTime(n.expires_at)}</span>` : ''}
            </div>
          </div>
          <div class="row-actions">
            <button class="icon-btn" data-edit="${n.id}" title="Edit">${icon('edit', 16)}</button>
            <button class="icon-btn danger" data-del="${n.id}" title="Delete">${icon('trash', 16)}</button>
          </div>
        </div>`).join('') || '<div class="empty"><span class="big">📢</span>No notices yet.</div>'}`;
    $('#n-add').addEventListener('click', () => noticeForm());
    $$('[data-edit]').forEach((b) => b.addEventListener('click', () => noticeForm(notices.find((x) => x.id === Number(b.dataset.edit)))));
    $$('[data-del]').forEach((b) => b.addEventListener('click', async () => { if (!(await confirmDlg('Delete this notice?'))) return; try { await api('/api/admin/notices/' + b.dataset.del, { method: 'DELETE' }); toast('Notice deleted.'); nav('notices'); } catch (e) { toast(e.message, 'bad'); } }));
  }

  function noticeForm(n) {
    const m = modal(n ? 'Edit Notice' : 'New Notice', `
      <div class="field"><label>Title *</label><input id="n-title" maxlength="140" value="${h(n?.title || '')}"></div>
      <div class="field"><label>Notice text</label><textarea id="n-body" maxlength="2000" style="min-height:120px">${h(n?.body || '')}</textarea></div>
      <div class="form-grid">
        <div class="field"><label>Status</label><select id="n-status"><option value="published" ${n?.status !== 'draft' ? 'selected' : ''}>Published</option><option value="draft" ${n?.status === 'draft' ? 'selected' : ''}>Draft (hidden)</option></select></div>
        <div class="field"><label>Pin as important</label><select id="n-pinned"><option value="0" ${!n?.pinned ? 'selected' : ''}>No</option><option value="1" ${n?.pinned ? 'selected' : ''}>Yes — show on top</option></select></div>
        <div class="field"><label>Publish from (optional — schedule)</label><input id="n-from" type="datetime-local" value="${epochToLocal(n?.publish_at)}"></div>
        <div class="field"><label>Expires on (optional)</label><input id="n-until" type="datetime-local" value="${epochToLocal(n?.expires_at)}"></div>
      </div>`);
    m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">${n ? 'Save Changes' : 'Publish Notice'}</button>`;
    $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
    $('[data-a=save]', m.foot).addEventListener('click', async (ev) => {
      ev.target.disabled = true;
      const body = { title: $('#n-title', m.el).value.trim(), body: $('#n-body', m.el).value.trim(), status: $('#n-status', m.el).value, pinned: $('#n-pinned', m.el).value === '1', publish_at: $('#n-from', m.el).value ? new Date($('#n-from', m.el).value).toISOString() : null, expires_at: $('#n-until', m.el).value ? new Date($('#n-until', m.el).value).toISOString() : null };
      try { if (n) await api('/api/admin/notices/' + n.id, { method: 'PUT', body }); else await api('/api/admin/notices', { method: 'POST', body }); toast('Notice saved — website updates instantly.'); m.close(); nav('notices'); } catch (e) { toast(e.message, 'bad'); ev.target.disabled = false; }
    });
  }

  // ================= WEBSITE CONTENT =================
  async function vContent() {
    const { settings: s, turnstile_secret_set } = await api('/api/admin/content');
    const F = (id, label, val, type = 'text', max = 200) => type === 'textarea'
      ? `<div class="field full"><label>${label}</label><textarea id="${id}" maxlength="${max}" style="min-height:110px">${h(val || '')}</textarea></div>`
      : `<div class="field"><label>${label}</label><input id="${id}" type="${type}" maxlength="${max}" value="${h(val || '')}"></div>`;
    C().innerHTML = `
      <div class="alert ok">${icon('check', 18)} Everything here updates the live website <b>immediately</b> — no code changes, no redeployment.</div>
      <div class="card"><h3>Logo & Brand</h3>
        <div style="display:flex;gap:16px;align-items:center;margin-bottom:16px;flex-wrap:wrap">
          <img id="logo-prev" src="${s.logo_image_id ? '/img/' + h(s.logo_image_id) : '/assets/img/logo-256.png'}" style="width:86px;height:86px;object-fit:contain;background:#fff;border:2px solid var(--line);border-radius:18px;padding:6px">
          <div><input id="logo-file" type="file" accept="image/jpeg,image/png,image/webp"><div class="hint" style="font-size:.78rem;color:var(--muted);font-weight:600;margin-top:5px">Upload replaces the logo everywhere. PNG with transparency works best.</div></div>
          ${s.logo_image_id ? '<button class="btn btn-ghost btn-sm" id="logo-reset">Restore default logo</button>' : ''}
        </div>
        <div class="form-grid">
          ${F('c-name', 'School name', s.school_name, 'text', 100)}
          ${F('c-slogan', 'Slogan (English)', s.slogan, 'text', 120)}
          ${F('c-sloganhi', 'Slogan (Hindi)', s.slogan_hi, 'text', 120)}
          ${F('c-footnote', 'Footer note', s.footer_note, 'text', 200)}
          <div class="field full"><label>Hero subtitle</label><textarea id="c-herosub" maxlength="300">${h(s.hero_subtitle || '')}</textarea></div>
        </div>
        <button class="btn btn-primary btn-sm" data-save="brand">Save Brand</button>
      </div>
      <div class="card"><h3>About Section</h3>
        <div class="field"><label>About text (blank line = new paragraph)</label><textarea id="c-about" maxlength="3000" style="min-height:140px">${h(s.about || '')}</textarea></div>
        <button class="btn btn-primary btn-sm" data-save="about">Save About</button>
      </div>
      <div class="grid-2">
        <div class="card"><h3>Director's Message</h3>
          ${F('c-dname', 'Name', s.director_name, 'text', 80)}
          ${F('c-drole', 'Designation line', s.director_role, 'text', 140)}
          <div class="field"><label>Message</label><textarea id="c-dmsg" maxlength="2000" style="min-height:130px">${h(s.director_message || '')}</textarea></div>
          <button class="btn btn-primary btn-sm" data-save="director">Save Director</button>
        </div>
        <div class="card"><h3>Principal's Message</h3>
          ${F('c-pname', 'Name', s.principal_name, 'text', 80)}
          ${F('c-prole', 'Designation line', s.principal_role, 'text', 140)}
          <div class="field"><label>Message</label><textarea id="c-pmsg" maxlength="2000" style="min-height:130px">${h(s.principal_message || '')}</textarea></div>
          <button class="btn btn-primary btn-sm" data-save="principal">Save Principal</button>
        </div>
      </div>
      <div class="card"><h3>Learning Philosophy (pillars)</h3><div id="ed-philosophy"></div><button class="btn btn-primary btn-sm" data-save="philosophy" style="margin-top:10px">Save Philosophy</button></div>
      <div class="card"><h3>Activities</h3><div id="ed-activities"></div><button class="btn btn-primary btn-sm" data-save="activities" style="margin-top:10px">Save Activities</button></div>
      <div class="card"><h3>Facilities (only list what the school actually has)</h3><div id="ed-facilities"></div><button class="btn btn-primary btn-sm" data-save="facilities" style="margin-top:10px">Save Facilities</button></div>
      <div class="card"><h3>Contact & Location</h3>
        <div class="form-grid">
          ${F('c-phone', 'Contact number', s.contact_phone, 'text', 25)}
          ${F('c-email', 'Email (leave empty to hide)', s.contact_email, 'text', 120)}
          <div class="field full"><label>Address</label><input id="c-addr" maxlength="300" value="${h(s.address || '')}"></div>
          <div class="field full"><label>Google Maps link (verified location — paste the share link)</label><input id="c-mapurl" maxlength="500" value="${h(s.maps_url || '')}" placeholder="https://maps.app.goo.gl/…"></div>
          <div class="field full"><label>Google Maps embed link (optional — shows live map on website)</label><input id="c-mapembed" maxlength="1000" value="${h(s.maps_embed || '')}" placeholder="https://www.google.com/maps/embed?pb=…"><div class="hint">Google Maps → Share → Embed a map → copy the src link.</div></div>
        </div>
        <button class="btn btn-primary btn-sm" data-save="contact">Save Contact</button>
      </div>
      <div class="card"><h3>Announcement Banner</h3>
        <div class="alert warn">${icon('info', 16)} Keep this <b>off</b> until the owner approves an announcement. No launch/opening-date text is shown by default.</div>
        <label class="check" style="margin-bottom:12px"><input id="c-anon" type="checkbox" ${s.announcement_enabled ? 'checked' : ''}> Show announcement banner on website</label>
        <div class="field"><label>Announcement text</label><input id="c-antext" maxlength="300" value="${h(s.announcement_text || '')}"></div>
        <button class="btn btn-primary btn-sm" data-save="announce">Save Announcement</button>
      </div>
      ${ME.role === 'admin' ? `
      <div class="card"><h3>Bot Protection (Cloudflare Turnstile — optional)</h3>
        <p style="color:var(--muted);font-size:.9rem;font-weight:600;margin-bottom:14px">Free from Cloudflare dashboard → Turnstile. When both keys are saved, login & enquiry forms get bot verification. Rate limiting works even without it.</p>
        <div class="form-grid">
          ${F('c-tssite', 'Site key (public)', s.turnstile_site_key, 'text', 200)}
          <div class="field"><label>Secret key ${turnstile_secret_set ? '(saved — leave blank to keep)' : ''}</label><input id="c-tssecret" type="password" maxlength="200" placeholder="${turnstile_secret_set ? '•••••••• (saved)' : 'Secret key'}"></div>
        </div>
        <button class="btn btn-primary btn-sm" data-save="turnstile">Save Turnstile</button>
      </div>` : ''}`;

    // rows editors
    rowsEditor($('#ed-philosophy'), s.philosophy || [], [{ k: 'title', l: 'Title', max: 80 }, { k: 'text', l: 'Text', max: 400, area: true }], { title: '', text: '' }, 8);
    rowsEditor($('#ed-activities'), s.activities || [], [{ k: 'icon', l: 'Icon', type: 'select', options: ['book', 'palette', 'music', 'blocks', 'ball', 'star', 'heart', 'sun'] }, { k: 'title', l: 'Title', max: 80 }, { k: 'text', l: 'Text', max: 300, area: true }], { icon: 'star', title: '', text: '' }, 12);
    rowsEditor($('#ed-facilities'), (s.facilities || []).map((f) => ({ v: f })), [{ k: 'v', l: 'Facility', max: 120 }], { v: '' }, 10);

    // logo upload
    $('#logo-file').addEventListener('change', async (ev) => {
      const f = ev.target.files[0]; if (!f) return;
      try {
        const img = await compressImage(f, { maxDim: 700, keepPng: true });
        await api('/api/admin/logo', { method: 'POST', body: { image: img } });
        toast('Logo updated everywhere!'); nav('content');
      } catch (e) { toast(e.message, 'bad'); }
    });
    $('#logo-reset')?.addEventListener('click', async () => { try { await api('/api/admin/logo', { method: 'DELETE' }); toast('Default logo restored.'); nav('content'); } catch (e) { toast(e.message, 'bad'); } });

    const v = (id) => $('#' + id).value.trim();
    const SAVES = {
      brand: () => ({ school_name: v('c-name'), slogan: v('c-slogan'), slogan_hi: v('c-sloganhi'), footer_note: v('c-footnote'), hero_subtitle: v('c-herosub') }),
      about: () => ({ about: v('c-about') }),
      director: () => ({ director_name: v('c-dname'), director_role: v('c-drole'), director_message: v('c-dmsg') }),
      principal: () => ({ principal_name: v('c-pname'), principal_role: v('c-prole'), principal_message: v('c-pmsg') }),
      philosophy: () => ({ philosophy: collectRows($('#ed-philosophy'), ['title', 'text']).filter((r) => r.title) }),
      activities: () => ({ activities: collectRows($('#ed-activities'), ['icon', 'title', 'text']).filter((r) => r.title) }),
      facilities: () => ({ facilities: collectRows($('#ed-facilities'), ['v']).map((r) => r.v).filter(Boolean) }),
      contact: () => ({ contact_phone: v('c-phone'), contact_email: v('c-email'), address: v('c-addr'), maps_url: v('c-mapurl'), maps_embed: v('c-mapembed') }),
      announce: () => ({ announcement_enabled: $('#c-anon').checked, announcement_text: v('c-antext') }),
      turnstile: () => { const o = { turnstile_site_key: v('c-tssite') }; if (v('c-tssecret')) o.turnstile_secret = v('c-tssecret'); return o; },
    };
    $$('[data-save]').forEach((b) => b.addEventListener('click', async () => {
      b.disabled = true;
      try { await api('/api/admin/content', { method: 'PUT', body: SAVES[b.dataset.save]() }); toast('Saved — live on the website now!'); } catch (e) { toast(e.message, 'bad'); }
      b.disabled = false;
    }));
  }

  function rowsEditor(el, items, fields, blank, max) {
    const draw = () => {
      el.innerHTML = items.map((it, i) => `
        <div class="ed-row" style="border:1.5px solid var(--line);border-radius:14px;padding:14px;margin-bottom:10px;background:var(--paper)">
          <div class="form-grid">${fields.map((f) => f.type === 'select'
            ? `<div class="field"><label>${f.l}</label><select data-k="${f.k}">${f.options.map((o) => `<option ${it[f.k] === o ? 'selected' : ''}>${o}</option>`).join('')}</select></div>`
            : f.area
              ? `<div class="field full"><label>${f.l}</label><textarea data-k="${f.k}" maxlength="${f.max}">${h(it[f.k] || '')}</textarea></div>`
              : `<div class="field ${fields.length === 1 ? 'full' : ''}"><label>${f.l}</label><input data-k="${f.k}" maxlength="${f.max}" value="${h(it[f.k] || '')}"></div>`).join('')}
          </div>
          <button class="btn btn-danger btn-sm" data-rm="${i}">${icon('trash', 14)} Remove</button>
        </div>`).join('') +
        (items.length < max ? `<button class="btn btn-ghost btn-sm" id="ed-add">${icon('plus', 14)} Add Item</button>` : '');
      $$('[data-rm]', el).forEach((b) => b.addEventListener('click', () => { items = collect(); items.splice(Number(b.dataset.rm), 1); draw(); }));
      $('#ed-add', el)?.addEventListener('click', () => { items = collect(); items.push({ ...blank }); draw(); });
    };
    const collect = () => collectRows(el, fields.map((f) => f.k));
    draw();
  }
  function collectRows(el, keys) {
    return $$('.ed-row', el).map((row) => { const o = {}; keys.forEach((k) => { o[k] = $(`[data-k="${k}"]`, row).value.trim(); }); return o; });
  }

  // ================= INQUIRIES =================
  async function vInquiries() {
    const { inquiries } = await api('/api/admin/inquiries');
    C().innerHTML = table(['Received', 'Parent', 'Phone', 'Child Age', 'Message', 'Status', ''],
      inquiries.map((q) => `<tr>
        <td><small>${h(q.created_at)}</small></td>
        <td><b>${h(q.parent_name)}</b></td>
        <td><a href="tel:${h(q.phone.replace(/[^+0-9]/g, ''))}">${h(q.phone)}</a></td>
        <td>${h(q.child_age || '—')}</td>
        <td style="max-width:260px"><small>${h(q.message || '—')}</small></td>
        <td><select data-status="${q.id}" style="border:2px solid var(--line);border-radius:9px;padding:6px 9px;font-weight:800;font-size:.8rem"><option value="new" ${q.status === 'new' ? 'selected' : ''}>New</option><option value="read" ${q.status === 'read' ? 'selected' : ''}>Read</option><option value="archived" ${q.status === 'archived' ? 'selected' : ''}>Archived</option></select></td>
        <td><button class="icon-btn danger" data-del="${q.id}">${icon('trash', 15)}</button></td>
      </tr>`).join(''), 860);
    $$('[data-status]').forEach((sel) => sel.addEventListener('change', async () => {
      try { await api('/api/admin/inquiries/' + sel.dataset.status, { method: 'PUT', body: { status: sel.value } }); toast('Updated.'); refreshBadge(); } catch (e) { toast(e.message, 'bad'); }
    }));
    $$('#content [data-del]').forEach((b) => b.addEventListener('click', async () => { if (!(await confirmDlg('Delete this enquiry?'))) return; try { await api('/api/admin/inquiries/' + b.dataset.del, { method: 'DELETE' }); toast('Deleted.'); nav('inquiries'); refreshBadge(); } catch (e) { toast(e.message, 'bad'); } }));
    refreshBadge();
  }

  // ================= AI SETTINGS =================
  async function vAi() {
    const a = await api('/api/admin/ai');
    C().innerHTML = `
      <div class="alert info">${icon('robot', 18)} Optional helper for the website. Get a free API key from <b>Google AI Studio</b> (aistudio.google.com). The key is stored only on the server — never shown to visitors.</div>
      <div class="card" style="max-width:640px">
        <h3>Gemini Assistant</h3>
        <label class="check" style="margin-bottom:16px"><input id="ai-on" type="checkbox" ${a.ai_enabled ? 'checked' : ''}> Enable chat assistant on the website</label>
        <div class="field"><label>API key ${a.key_set ? `(saved: ${h(a.key_masked)})` : ''}</label><input id="ai-key" type="password" maxlength="200" placeholder="${a.key_set ? 'Paste a new key to replace, or leave blank' : 'Paste Gemini API key'}"></div>
        <div class="form-grid">
          <div class="field"><label>Model</label><input id="ai-model" maxlength="60" value="${h(a.model)}"><div class="hint">Recommended: gemini-3.5-flash (fast chat model)</div></div>
          <div class="field"><label>Daily message cap (cost protection)</label><input id="ai-cap" type="number" min="10" max="2000" value="${a.daily_cap}"></div>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn btn-primary" id="ai-save">Save Settings</button>
          <button class="btn btn-sun" id="ai-test">Test Connection</button>
        </div>
        <div id="ai-result" style="margin-top:14px"></div>
      </div>`;
    $('#ai-save').addEventListener('click', async () => {
      const body = { ai_enabled: $('#ai-on').checked, model: $('#ai-model').value.trim(), daily_cap: $('#ai-cap').value };
      if ($('#ai-key').value.trim()) body.api_key = $('#ai-key').value.trim();
      try { await api('/api/admin/ai', { method: 'PUT', body }); toast('AI settings saved.'); nav('ai'); } catch (e) { toast(e.message, 'bad'); }
    });
    $('#ai-test').addEventListener('click', async () => {
      const box = $('#ai-result');
      box.innerHTML = '<div class="alert info">Testing…</div>';
      try {
        const r = await api('/api/admin/ai/test', { method: 'POST', body: { api_key: $('#ai-key').value.trim() || undefined, model: $('#ai-model').value.trim() } });
        box.innerHTML = r.ok ? `<div class="alert ok">${icon('check', 16)} Connected! Model replied: “${h(r.reply)}”</div>` : `<div class="alert bad">${icon('info', 16)} Failed: ${h(r.error)}</div>`;
      } catch (e) { box.innerHTML = `<div class="alert bad">${h(e.message)}</div>`; }
    });
  }

  // ================= ADMIN ACCOUNTS =================
  async function vAdmins() {
    const { admins } = await api('/api/admin/admins');
    C().innerHTML = `
      <div class="alert info">${icon('shield', 18)} Co-admins can manage students, teachers, fees, results, gallery, notices and website content. They <b>cannot</b> manage admin accounts, AI keys or security settings.</div>
      <div class="toolbar"><span class="grow"></span><button class="btn btn-primary" id="ad-add">${icon('plus', 16)} Add Co-Admin</button></div>
      ${table(['Name', 'Username', 'Role', 'Status', 'Last Login', ''], admins.map((a) => `<tr>
        <td><div class="who"><span class="avatar">${h(initials(a.name))}</span><b>${h(a.name)}</b></div></td>
        <td><b>${h(a.username)}</b></td>
        <td>${a.role === 'admin' ? badge('Owner', 'yellow') : badge('Co-Admin', 'blue')}</td>
        <td>${a.active ? badge('Active', 'green') : badge('Disabled', 'red')}</td>
        <td><small>${a.last_login ? h(a.last_login) : 'Never'}</small></td>
        <td>${a.role === 'coadmin' ? `<div class="row-actions"><button class="icon-btn" data-edit="${a.id}" title="Edit">${icon('edit', 16)}</button><button class="icon-btn" data-pw="${a.id}" title="Reset password">${icon('key', 16)}</button><button class="icon-btn danger" data-del="${a.id}" title="Remove">${icon('trash', 16)}</button></div>` : '<small style="color:var(--muted)">Protected</small>'}</td>
      </tr>`).join(''), 700)}`;
    $('#ad-add').addEventListener('click', () => {
      const m = modal('Add Co-Admin', `
        <div class="field"><label>Name</label><input id="a-name" maxlength="80"></div>
        <div class="field"><label>Username</label><input id="a-user" maxlength="32"></div>
        <div class="field"><label>Password (min 8 chars)</label><input id="a-pass" type="text" minlength="8"></div>
        <div class="alert warn">${icon('info', 16)} Share these credentials privately. The co-admin can change their own password after signing in.</div>`);
      m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">Create Co-Admin</button>`;
      $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
      $('[data-a=save]', m.foot).addEventListener('click', async () => {
        try { await api('/api/admin/admins', { method: 'POST', body: { name: $('#a-name', m.el).value.trim(), username: $('#a-user', m.el).value.trim(), password: $('#a-pass', m.el).value } }); toast('Co-admin created.'); m.close(); nav('admins'); } catch (e) { toast(e.message, 'bad'); }
      });
    });
    $$('[data-edit]').forEach((b) => b.addEventListener('click', () => {
      const a = admins.find((x) => x.id === Number(b.dataset.edit));
      const m = modal('Edit Co-Admin — ' + a.username, `
        <div class="field"><label>Name</label><input id="e-name" maxlength="80" value="${h(a.name)}"></div>
        <label class="check"><input id="e-active" type="checkbox" ${a.active ? 'checked' : ''}> Account active</label>`);
      m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">Save</button>`;
      $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
      $('[data-a=save]', m.foot).addEventListener('click', async () => {
        try { await api('/api/admin/admins/' + a.id, { method: 'PUT', body: { name: $('#e-name', m.el).value.trim(), active: $('#e-active', m.el).checked } }); toast('Saved.'); m.close(); nav('admins'); } catch (e) { toast(e.message, 'bad'); }
      });
    }));
    $$('[data-pw]').forEach((b) => b.addEventListener('click', () => { const a = admins.find((x) => x.id === Number(b.dataset.pw)); resetPwModal('admin', a.id, a.username); }));
    $$('[data-del]').forEach((b) => b.addEventListener('click', async () => { if (!(await confirmDlg('Remove this co-admin? Their login stops immediately.'))) return; try { await api('/api/admin/admins/' + b.dataset.del, { method: 'DELETE' }); toast('Co-admin removed.'); nav('admins'); } catch (e) { toast(e.message, 'bad'); } }));
  }

  // ================= AUDIT =================
  async function vAudit() {
    const { logs } = await api('/api/admin/audit');
    C().innerHTML = table(['When (UTC)', 'Who', 'Role', 'Action', 'Details', 'IP'],
      logs.map((l) => `<tr><td><small>${h(l.created_at)}</small></td><td><b>${h(l.actor)}</b></td><td>${badge(l.role || '—', l.role === 'admin' ? 'yellow' : l.role === 'parent' ? 'green' : 'blue')}</td><td><code style="font-size:.8rem">${h(l.action)}</code></td><td style="max-width:280px"><small>${h(l.detail)}</small></td><td><small>${h(l.ip)}</small></td></tr>`).join(''), 860);
  }

  // ================= HEALTH =================
  async function vHealth() {
    const d = await api('/api/admin/health');
    const mb = (b) => (b / 1048576).toFixed(1) + ' MB';
    C().innerHTML = `
      <div class="stats">
        ${stat('Students', d.students, 'students', '#1e3a6e', 'var(--sky)')}
        ${stat('Photos Stored', d.images, 'camera', '#c98f00', 'var(--sun-soft)')}
        ${stat('Media Size', mb(d.media_bytes), 'chart', '#cf6f10', 'var(--tang-soft)')}
        ${stat('Active Sessions', d.active_sessions, 'shield', '#2e7a3d', 'var(--leaf-soft)')}
      </div>
      <div class="grid-2">
        <div class="card"><h3>Database</h3>
          <dl class="kv">
            <dt>Engine</dt><dd>Cloudflare D1 (SQLite)</dd>
            ${d.db_bytes ? `<dt>DB size</dt><dd>${mb(d.db_bytes)}</dd>` : ''}
            <dt>Notices</dt><dd>${d.notices}</dd>
            <dt>Gallery items</dt><dd>${d.gallery_items}</dd>
            <dt>Audit entries</dt><dd>${d.audit_entries}</dd>
          </dl>
        </div>
        <div class="card"><h3>Free Tier Allowances (checked Nov 2026)</h3>
          <dl class="kv">
            <dt>D1 reads</dt><dd>5 million rows / day</dd>
            <dt>D1 writes</dt><dd>100,000 rows / day</dd>
            <dt>D1 storage</dt><dd>5 GB total · 500 MB per database</dd>
            <dt>Workers</dt><dd>100,000 requests / day</dd>
          </dl>
          <div class="alert warn" style="margin-top:14px">${icon('info', 16)} Cloudflare can change limits. For 400 students with normal use this is comfortable, but keep an eye here and take backups.</div>
        </div>
      </div>
      <div class="card"><h3>Backups</h3>
        <p style="color:var(--muted);font-weight:600;margin-bottom:12px">Run <code>npm run db:backup</code> in Codespaces/terminal to export the full database to a local SQL file. Do this weekly. See docs/BACKUP.md for restore steps. Automated backup is <b>not</b> enabled unless you configure it.</p>
      </div>`;
  }

  // ================= CHANGE PASSWORD =================
  function passwordModal() {
    const m = modal('Change My Password', `
      <div class="field"><label>Current password</label><input id="pw-cur" type="password" maxlength="128"></div>
      <div class="field"><label>New password (min 8 characters)</label><input id="pw-new" type="password" maxlength="128"></div>
      <div class="field"><label>Repeat new password</label><input id="pw-new2" type="password" maxlength="128"></div>
      <div class="alert info">${icon('info', 16)} You will be signed out everywhere and need to sign in again.</div>`);
    m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">Change Password</button>`;
    $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
    $('[data-a=save]', m.foot).addEventListener('click', async () => {
      if ($('#pw-new', m.el).value !== $('#pw-new2', m.el).value) return toast('New passwords do not match.', 'bad');
      try { await api('/api/auth/change-password', { method: 'POST', body: { current: $('#pw-cur', m.el).value, password: $('#pw-new', m.el).value } }); toast('Password changed. Please sign in again.'); setTimeout(() => location.reload(), 1200); } catch (e) { toast(e.message, 'bad'); }
    });
  }

  const VIEWS = { dashboard: vDashboard, students: vStudents, teachers: vTeachers, classes: vClasses, attendance: vAttendance, homework: vHomework, fees: vFees, results: vResults, gallery: vGallery, notices: vNotices, content: vContent, inquiries: vInquiries, ai: vAi, admins: vAdmins, audit: vAudit, health: vHealth };
  await boot();

})();
