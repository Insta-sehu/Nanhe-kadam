// Teacher Portal — my classes, attendance, homework, notices.
(async function () {
  'use strict';
  const { api, esc: h, toast, modal, confirmDlg, fmtDate, initials, today, icon, shell, maybeTurnstile, setLogo } = P;
  const $ = (s, el) => (el || document).querySelector(s);
  const $$ = (s, el) => [...(el || document).querySelectorAll(s)];
  const C = () => document.getElementById('content');
  let ME = null, MY = null, SHELL = null;

  async function boot() {
  const me = await api('/api/auth/me').catch(() => ({ authenticated: false }));
  if (me.authenticated && me.role === 'teacher') { ME = me; await startApp(); }
  else {
    $('#login-view').hidden = false;
    maybeTurnstile();
    $('#login-form').addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const errBox = $('#login-error'); errBox.classList.remove('show');
      const btn = ev.target.querySelector('button'); btn.disabled = true;
      try {
        const body = { username: $('#l-user').value.trim(), password: $('#l-pass').value };
        if (window.turnstile && window.__tsWidget != null) body.turnstile = window.turnstile.getResponse(window.__tsWidget);
        const r = await api('/api/auth/login', { method: 'POST', body });
        if (r.role !== 'teacher') { await api('/api/auth/logout', { method: 'POST' }); throw new Error('This is the Teacher Portal. Admins please sign in at /admin/, parents at /parent/'); }
        location.reload();
      } catch (e) { errBox.textContent = e.message; errBox.classList.add('show'); btn.disabled = false; if (window.turnstile && window.__tsWidget != null) window.turnstile.reset(window.__tsWidget); }
    });
  }
  }

  async function startApp() {
    $('#login-view').hidden = true; $('#app-view').hidden = false;
    MY = await api('/api/teacher/me');
    api('/api/public/content').then((d) => setLogo(d.settings?.logo_image_id)).catch(() => {});
    SHELL = shell({
      groups: [
        { items: [
          { id: 'classes', label: 'My Classes', icon: 'classes' },
          { id: 'attendance', label: 'Attendance', icon: 'calendar' },
          { id: 'homework', label: 'Homework', icon: 'book' },
          { id: 'notices', label: 'Notices', icon: 'bell' },
          { id: 'profile', label: 'My Profile', icon: 'user' }] },
      ],
      onNav: nav, user: { name: MY.teacher?.name || ME.name }, roleLabel: 'Teacher', portalName: 'Teacher Portal',
    });
    nav('classes');
  }

  const TITLES = { classes: ['My Classes', 'Students in your assigned classes'], attendance: ['Attendance', 'Mark today\'s attendance'], homework: ['Homework', 'Give & manage homework'], notices: ['Notices', 'School notice board'], profile: ['My Profile', 'Your account details'] };
  function nav(id) {
    if (id === 'password') return passwordModal();
    SHELL.setActive(id, ...(TITLES[id] || ['', '']));
    C().innerHTML = '<div class="empty">Loading…</div>';
    (VIEWS[id] || (() => {}))().catch((e) => { C().innerHTML = `<div class="alert bad">${h(e.message)}</div>`; });
  }
  const classOpts = (sel) => (MY.classes || []).map((c) => `<option value="${c.id}" ${String(sel) === String(c.id) ? 'selected' : ''}>${h(c.name)}</option>`).join('');
  const table = (head, rows) => `<div class="table-wrap"><table><thead><tr>${head.map((x) => `<th>${x}</th>`).join('')}</tr></thead><tbody>${rows || `<tr><td colspan="${head.length}"><div class="empty">Nothing here yet.</div></td></tr>`}</tbody></table></div>`;
  const badge = (t, k) => `<span class="badge ${k}">${h(t)}</span>`;
  const noClasses = () => { C().innerHTML = `<div class="alert warn">${icon('info', 18)} No classes are assigned to you yet. Please ask the admin to assign your classes.</div>`; };

  async function vClasses() {
    if (!MY.classes?.length) return noClasses();
    C().innerHTML = `
      <div class="toolbar"><select id="cl-sel">${classOpts(MY.classes[0].id)}</select><button class="btn btn-ghost" id="cl-load">Show Students</button></div>
      <div id="cl-body"></div>`;
    const load = async () => {
      const { students } = await api('/api/teacher/students?class_id=' + $('#cl-sel').value);
      $('#cl-body').innerHTML = `
        <div class="alert info">${icon('students', 18)} <b>${students.length}</b> active children in this class.</div>
        ${table(['Child', 'Admission No', 'Guardian', 'Guardian Phone'], students.map((s) => `<tr>
          <td><div class="who">${s.photo_id ? `<img class="avatar" src="/img/${h(s.photo_id)}">` : `<span class="avatar">${h(initials(s.name))}</span>`}<b>${h(s.name)}</b></div></td>
          <td>${h(s.admission_no)}</td><td>${h(s.guardian_name || '—')}</td><td>${h(s.guardian_phone || '—')}</td></tr>`).join(''))}`;
    };
    $('#cl-load').addEventListener('click', load);
    $('#cl-sel').addEventListener('change', load);
    await load();
  }

  async function vAttendance() {
    if (!MY.classes?.length) return noClasses();
    C().innerHTML = `
      <div class="toolbar">
        <select id="a-class">${classOpts(MY.classes[0].id)}</select>
        <input id="a-date" type="date" value="${today()}">
        <button class="btn btn-ghost" id="a-load">Load</button>
        <span class="grow"></span>
        <button class="btn btn-leaf btn-sm" id="a-allp">All Present</button>
        <button class="btn btn-primary" id="a-save">${icon('check', 16)} Save</button>
      </div><div id="a-table"></div>`;
    let students = [], marks = {};
    const draw = () => {
      $('#a-table').innerHTML = table(['Child', 'Admission No', 'P / A / L'], students.map((s) => `<tr>
        <td><div class="who"><span class="avatar">${h(initials(s.name))}</span><b>${h(s.name)}</b></div></td>
        <td>${h(s.admission_no)}</td>
        <td><div class="att-btns" data-sid="${s.id}">
          <button data-s="P" class="${marks[s.id] === 'P' ? 'on-P' : ''}">P</button>
          <button data-s="A" class="${marks[s.id] === 'A' ? 'on-A' : ''}">A</button>
          <button data-s="L" class="${marks[s.id] === 'L' ? 'on-L' : ''}">L</button>
        </div></td></tr>`).join(''));
      $$('#a-table .att-btns button').forEach((b) => b.addEventListener('click', () => {
        marks[Number(b.parentElement.dataset.sid)] = b.dataset.s;
        [...b.parentElement.children].forEach((x) => x.className = x === b ? 'on-' + b.dataset.s : '');
      }));
    };
    const load = async () => {
      const d = await api(`/api/teacher/attendance?class_id=${$('#a-class').value}&date=${$('#a-date').value}`);
      students = d.students; marks = {};
      d.attendance.forEach((a) => { marks[a.student_id] = a.status; });
      draw();
    };
    $('#a-load').addEventListener('click', load);
    $('#a-class').addEventListener('change', load);
    $('#a-allp').addEventListener('click', () => { students.forEach((s) => { marks[s.id] = 'P'; }); draw(); });
    $('#a-save').addEventListener('click', async () => {
      const records = students.filter((s) => marks[s.id]).map((s) => ({ student_id: s.id, status: marks[s.id] }));
      if (!records.length) return toast('Mark at least one child.', 'bad');
      try { await api('/api/teacher/attendance', { method: 'POST', body: { class_id: Number($('#a-class').value), date: $('#a-date').value, records } }); toast(`Saved for ${records.length} children.`); } catch (e) { toast(e.message, 'bad'); }
    });
    await load();
  }

  async function vHomework() {
    if (!MY.classes?.length) return noClasses();
    const { homework } = await api('/api/teacher/homework');
    C().innerHTML = `
      <div class="toolbar"><span class="grow"></span><button class="btn btn-primary" id="hw-add">${icon('plus', 16)} Give Homework</button></div>
      ${table(['Title', 'Class', 'Due', ''], homework.map((x) => `<tr><td><b>${h(x.title)}</b>${x.details ? `<br><small style="color:var(--muted)">${h(x.details.slice(0, 80))}</small>` : ''}</td><td>${badge(x.class_name, 'blue')}</td><td>${fmtDate(x.due_date)}</td><td><div class="row-actions"><button class="icon-btn" data-edit="${x.id}">${icon('edit', 15)}</button><button class="icon-btn danger" data-del="${x.id}">${icon('trash', 15)}</button></div></td></tr>`).join(''))}`;
    const form = (x) => {
      const m = modal(x ? 'Edit Homework' : 'Give Homework', `
        <div class="field"><label>Class</label><select id="hw-class">${classOpts(x?.class_id)}</select></div>
        <div class="field"><label>Title</label><input id="hw-title" maxlength="140" value="${h(x?.title || '')}"></div>
        <div class="field"><label>Details</label><textarea id="hw-details" maxlength="2000">${h(x?.details || '')}</textarea></div>
        <div class="field"><label>Due date</label><input id="hw-due" type="date" value="${h(x?.due_date || '')}"></div>`);
      m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">Save</button>`;
      $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
      $('[data-a=save]', m.foot).addEventListener('click', async () => {
        const body = { class_id: $('#hw-class', m.el).value, title: $('#hw-title', m.el).value.trim(), details: $('#hw-details', m.el).value.trim(), due_date: $('#hw-due', m.el).value || null };
        try { if (x) await api('/api/teacher/homework/' + x.id, { method: 'PUT', body }); else await api('/api/teacher/homework', { method: 'POST', body }); toast('Homework saved.'); m.close(); nav('homework'); } catch (e) { toast(e.message, 'bad'); }
      });
    };
    $('#hw-add').addEventListener('click', () => form());
    $$('[data-edit]').forEach((b) => b.addEventListener('click', () => form(homework.find((x) => x.id === Number(b.dataset.edit)))));
    $$('[data-del]').forEach((b) => b.addEventListener('click', async () => { if (!(await confirmDlg('Delete this homework?'))) return; try { await api('/api/teacher/homework/' + b.dataset.del, { method: 'DELETE' }); toast('Deleted.'); nav('homework'); } catch (e) { toast(e.message, 'bad'); } }));
  }

  async function vNotices() {
    const { notices } = await api('/api/teacher/notices');
    C().innerHTML = notices.map((n) => `
      <div class="notice-admin"><div class="bd"><b>${h(n.title)} ${n.pinned ? badge('Important', 'yellow') : ''}</b><p>${h(n.body)}</p><div class="meta"><span class="badge gray">${fmtDate(new Date(n.publish_at * 1000).toISOString().slice(0, 10))}</span></div></div></div>`).join('') || '<div class="empty">No notices right now.</div>';
  }

  async function vProfile() {
    const t = MY.teacher || {};
    C().innerHTML = `
      <div class="card" style="max-width:560px">
        <h3>${icon('user', 20)} ${h(t.name || ME.name)}</h3>
        <dl class="kv">
          <dt>Username</dt><dd>${h(MY.username || ME.username)}</dd>
          <dt>Phone</dt><dd>${h(t.phone || '—')}</dd>
          <dt>Email</dt><dd>${h(t.email || '—')}</dd>
          <dt>Qualification</dt><dd>${h(t.qualification || '—')}</dd>
          <dt>My classes</dt><dd>${(MY.classes || []).map((c) => h(c.name)).join(', ') || 'None assigned yet'}</dd>
        </dl>
        <button class="btn btn-primary btn-sm" id="pw-btn" style="margin-top:18px">${icon('key', 15)} Change Password</button>
      </div>`;
    $('#pw-btn').addEventListener('click', passwordModal);
  }

  function passwordModal() {
    const m = modal('Change My Password', `
      <div class="field"><label>Current password</label><input id="pw-cur" type="password" maxlength="128"></div>
      <div class="field"><label>New password (min 8)</label><input id="pw-new" type="password" maxlength="128"></div>
      <div class="alert info">${icon('info', 16)} You will be signed out and need to sign in again.</div>`);
    m.foot.innerHTML = `<button class="btn btn-ghost" data-a="cancel">Cancel</button><button class="btn btn-primary" data-a="save">Change</button>`;
    $('[data-a=cancel]', m.foot).addEventListener('click', m.close);
    $('[data-a=save]', m.foot).addEventListener('click', async () => {
      try { await api('/api/auth/change-password', { method: 'POST', body: { current: $('#pw-cur', m.el).value, password: $('#pw-new', m.el).value } }); toast('Changed. Sign in again.'); setTimeout(() => location.reload(), 1100); } catch (e) { toast(e.message, 'bad'); }
    });
  }

  const VIEWS = { classes: vClasses, attendance: vAttendance, homework: vHomework, notices: vNotices, profile: vProfile };
  await boot();

})();
