// Parent Portal — my child: attendance, homework, fees, results, notices.
(async function () {
  'use strict';
  const { api, esc: h, toast, fmtDate, money, initials, icon, shell, maybeTurnstile, setLogo, MONTHS } = P;
  const $ = (s, el) => (el || document).querySelector(s);
  const $$ = (s, el) => [...(el || document).querySelectorAll(s)];
  const C = () => document.getElementById('content');
  let ME = null, OV = null, SHELL = null;

  async function boot() {
  const me = await api('/api/auth/me').catch(() => ({ authenticated: false }));
  if (me.authenticated && me.role === 'parent') { ME = me; await startApp(); }
  else {
    $('#login-view').hidden = false;
    maybeTurnstile();
    $('#login-form').addEventListener('submit', async (ev) => {
      ev.preventDefault();
      const errBox = $('#login-error'); errBox.classList.remove('show');
      const btn = ev.target.querySelector('button'); btn.disabled = true;
      try {
        const body = { admission_no: $('#l-adm').value.trim(), dob: $('#l-dob').value, pin: $('#l-pin').value.trim() || undefined };
        if (window.turnstile && window.__tsWidget != null) body.turnstile = window.turnstile.getResponse(window.__tsWidget);
        await api('/api/auth/parent-login', { method: 'POST', body });
        location.reload();
      } catch (e) {
        if (e.code === 'PIN_REQUIRED') { $('#pin-field').hidden = false; $('#l-pin').focus(); }
        errBox.textContent = e.message; errBox.classList.add('show'); btn.disabled = false;
        if (window.turnstile && window.__tsWidget != null) window.turnstile.reset(window.__tsWidget);
      }
    });
  }
  }

  async function startApp() {
    $('#login-view').hidden = true; $('#app-view').hidden = false;
    OV = await api('/api/parent/overview');
    api('/api/public/content').then((d) => setLogo(d.settings?.logo_image_id)).catch(() => {});
    SHELL = shell({
      groups: [{ items: [
        { id: 'home', label: 'My Child', icon: 'home' },
        { id: 'attendance', label: 'Attendance', icon: 'calendar' },
        { id: 'homework', label: 'Homework', icon: 'book' },
        { id: 'fees', label: 'Fees', icon: 'money' },
        { id: 'results', label: 'Results', icon: 'chart' },
        { id: 'notices', label: 'Notices', icon: 'bell' }] }],
      onNav: nav, user: { name: OV.student.guardian_name || ('Parent of ' + OV.student.name) }, roleLabel: 'Parent', portalName: 'Parent Portal',
    });
    nav('home');
  }

  const TITLES = { home: ['My Child', 'Profile & summary'], attendance: ['Attendance', 'Day-by-day record'], homework: ['Homework', 'Class homework & due dates'], fees: ['Fees', 'Fee records & payment status'], results: ['Results', 'Exam performance'], notices: ['Notices', 'School notice board'] };
  function nav(id) {
    SHELL.setActive(id, ...(TITLES[id] || ['', '']));
    C().innerHTML = '<div class="empty">Loading…</div>';
    (VIEWS[id] || (() => {}))().catch((e) => { C().innerHTML = `<div class="alert bad">${h(e.message)}</div>`; });
  }
  const table = (head, rows, minW) => `<div class="table-wrap"><table ${minW ? `style="min-width:${minW}px"` : ''}><thead><tr>${head.map((x) => `<th>${x}</th>`).join('')}</tr></thead><tbody>${rows || `<tr><td colspan="${head.length}"><div class="empty">Nothing here yet.</div></td></tr>`}</tbody></table></div>`;
  const badge = (t, k) => `<span class="badge ${k}">${h(t)}</span>`;
  const stat = (label, n, ic, color, bg) => `<div class="stat" style="--sc:${color};--scbg:${bg}"><span class="ic">${icon(ic, 20, color)}</span><div class="n">${n}</div><div class="l">${h(label)}</div></div>`;

  async function vHome() {
    OV = await api('/api/parent/overview');
    const s = OV.student, a = OV.attendance_summary || {};
    const pct = a.total ? Math.round(((a.present + a.late) / a.total) * 100) : null;
    C().innerHTML = `
      <div class="card" style="display:flex;gap:20px;align-items:center;flex-wrap:wrap">
        ${s.photo_id ? `<img src="/img/${h(s.photo_id)}" style="width:92px;height:92px;border-radius:24px;object-fit:cover;border:3px solid var(--sun)">` : `<span class="avatar" style="width:92px;height:92px;font-size:1.7rem;border-radius:24px;background:var(--sun-soft)">${h(initials(s.name))}</span>`}
        <div style="flex:1;min-width:220px">
          <h2 class="serif" style="font-size:1.6rem">${h(s.name)}</h2>
          <div style="color:var(--muted);font-weight:800">${badge(s.class_name || 'Class', 'blue')} &nbsp; Admission No: <b>${h(s.admission_no)}</b></div>
        </div>
        <div style="text-align:right"><small style="color:var(--muted);font-weight:800">Admitted on</small><div style="font-weight:900;color:var(--navy)">${fmtDate(s.admission_date)}</div></div>
      </div>
      <div class="stats">
        ${stat('Attendance', pct === null ? '—' : pct + '%', 'calendar', '#2e7a3d', 'var(--leaf-soft)')}
        ${stat('Fees Pending', money(OV.fees_due), 'money', '#cf6f10', 'var(--tang-soft)')}
        ${stat('Active Homework', OV.active_homework, 'book', '#1e3a6e', 'var(--sky)')}
        ${stat('Days Recorded', a.total || 0, 'check', '#c98f00', 'var(--sun-soft)')}
      </div>
      <div class="grid-2">
        <div class="card"><h3>Child Details</h3>
          <dl class="kv">
            <dt>Date of birth</dt><dd>${fmtDate(s.dob)}</dd>
            <dt>Class</dt><dd>${h(s.class_name || '—')}</dd>
            <dt>Guardian</dt><dd>${h(s.guardian_name || '—')}</dd>
            <dt>Guardian phone</dt><dd>${h(s.guardian_phone || '—')}</dd>
          </dl>
        </div>
        <div class="card"><h3>Good to know</h3>
          <p style="color:var(--muted);font-weight:600;font-size:.93rem">This portal is only for parents/guardians. Attendance, homework, fees and results are updated by the school and appear here instantly. If something looks wrong, please call the school office.</p>
        </div>
      </div>`;
  }

  async function vAttendance() {
    const now = new Date();
    const monthVal = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    C().innerHTML = `
      <div class="toolbar"><input type="month" id="at-month" value="${monthVal}"><button class="btn btn-ghost" id="at-load">Show</button></div>
      <div id="at-body"></div>`;
    const load = async () => {
      const { attendance } = await api('/api/parent/attendance?month=' + $('#at-month').value);
      const present = attendance.filter((x) => x.status !== 'A').length;
      $('#at-body').innerHTML = `
        <div class="alert ${attendance.length && present / attendance.length >= 0.85 ? 'ok' : 'info'}">${icon('calendar', 18)} ${attendance.length ? `<b>${present} of ${attendance.length}</b> days present this month (${Math.round((present / attendance.length) * 100)}%)` : 'No attendance recorded for this month yet.'}</div>
        ${table(['Date', 'Day', 'Status'], attendance.map((x) => {
          const d = new Date(x.date + 'T00:00:00');
          return `<tr><td><b>${fmtDate(x.date)}</b></td><td>${['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][d.getDay()]}</td><td>${x.status === 'P' ? badge('Present', 'green') : x.status === 'L' ? badge('Late', 'yellow') : badge('Absent', 'red')}</td></tr>`;
        }).join(''), 380)}`;
    };
    $('#at-load').addEventListener('click', load);
    await load();
  }

  async function vHomework() {
    const { homework } = await api('/api/parent/homework');
    C().innerHTML = homework.map((x) => `
      <div class="notice-admin">
        <div class="bd">
          <b>${h(x.title)} ${x.due_date ? badge('Due ' + fmtDate(x.due_date), 'yellow') : ''}</b>
          ${x.details ? `<p>${h(x.details)}</p>` : ''}
          <div class="meta"><span class="badge blue">${h(x.class_name)}</span><span class="badge gray">Given ${fmtDate(x.created_at)}</span></div>
        </div>
      </div>`).join('') || '<div class="empty"><span class="big">📚</span>No homework right now. Enjoy play time!</div>';
  }

  async function vFees() {
    const { fees } = await api('/api/parent/fees');
    const due = fees.filter((f) => f.status === 'due').reduce((a, f) => a + f.amount, 0);
    const paid = fees.filter((f) => f.status === 'paid').reduce((a, f) => a + f.amount, 0);
    C().innerHTML = `
      <div class="stats" style="grid-template-columns:1fr 1fr">
        ${stat('Pending', money(due), 'money', '#cf6f10', 'var(--tang-soft)')}
        ${stat('Paid', money(paid), 'check', '#2e7a3d', 'var(--leaf-soft)')}
      </div>
      ${due > 0 ? `<div class="alert warn">${icon('info', 18)} Please pay pending fees at the school office. This portal shows records only — no online payment.</div>` : ''}
      ${table(['Fee', 'Amount', 'Due Date', 'Status'], fees.map((f) => `<tr>
        <td><b>${h(f.title)}</b>${f.note ? `<br><small style="color:var(--muted)">${h(f.note)}</small>` : ''}</td>
        <td><b>${money(f.amount)}</b></td><td>${fmtDate(f.due_date)}</td>
        <td>${f.status === 'paid' ? badge('Paid on ' + fmtDate(f.paid_on), 'green') : badge('Due', 'yellow')}</td></tr>`).join(''), 520)}`;
  }

  async function vResults() {
    const { results } = await api('/api/parent/results');
    if (!results.length) { C().innerHTML = '<div class="empty"><span class="big">📈</span>No results published yet. They will appear here after exams.</div>'; return; }
    const byExam = {};
    for (const r of results) { const k = r.exam + (r.term ? ' · ' + r.term : ''); (byExam[k] = byExam[k] || []).push(r); }
    C().innerHTML = Object.entries(byExam).map(([exam, rows]) => {
      const tot = rows.reduce((a, r) => a + r.marks, 0), max = rows.reduce((a, r) => a + r.max_marks, 0);
      const pct = Math.round((tot / max) * 100);
      return `<div class="card">
        <h3>${h(exam)} <span class="spacer"></span> ${badge(pct + '% overall', pct >= 60 ? 'green' : pct >= 35 ? 'yellow' : 'red')}</h3>
        ${table(['Subject', 'Marks', 'Score'], rows.map((r) => {
          const p = Math.round((r.marks / r.max_marks) * 100);
          return `<tr><td><b>${h(r.subject)}</b></td><td>${r.marks} / ${r.max_marks}</td><td style="min-width:140px"><div class="progress" style="max-width:160px"><i style="width:${p}%;background:${p >= 60 ? 'var(--leaf)' : p >= 35 ? 'var(--sun)' : 'var(--red)'}"></i></div></td></tr>`;
        }).join(''), 420)}
        <div style="text-align:right;font-weight:900;color:var(--navy);margin-top:10px">Total: ${tot} / ${max}</div>
      </div>`;
    }).join('');
  }

  async function vNotices() {
    const { notices } = await api('/api/parent/notices');
    C().innerHTML = notices.map((n) => `
      <div class="notice-admin">
        <div class="bd">
          <b>${h(n.title)} ${n.pinned ? badge('Important', 'yellow') : ''}</b>
          <p>${h(n.body)}</p>
          <div class="meta"><span class="badge gray">${fmtDate(new Date((n.publish_at || 0) * 1000).toISOString().slice(0, 10))}</span></div>
        </div>
      </div>`).join('') || '<div class="empty">No notices right now.</div>';
  }

  const VIEWS = { home: vHome, attendance: vAttendance, homework: vHomework, fees: vFees, results: vResults, notices: vNotices };
  await boot();

})();
