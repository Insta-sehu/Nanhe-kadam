// Shared portal helpers (Admin / Teacher / Parent). No frameworks, no build step.
window.P = (function () {
  'use strict';
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  async function api(path, opts = {}) {
    const res = await fetch(path, {
      method: opts.method || 'GET',
      headers: { 'Content-Type': 'application/json', 'X-NKPS-Client': 'fetch' },
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
      credentials: 'same-origin',
    });
    let data = {};
    try { data = await res.json(); } catch {}
    if (!res.ok) {
      const e = new Error(data.error || `Request failed (${res.status})`);
      e.status = res.status; e.code = data.code;
      if (res.status === 401 && !location.pathname.endsWith('login')) {
        // session expired → back to portal home (login screen)
        setTimeout(() => location.reload(), 900);
      }
      throw e;
    }
    return data;
  }

  // ---------- toasts ----------
  function toast(msg, kind = 'ok', ms = 3600) {
    let box = document.querySelector('.toasts');
    if (!box) { box = document.createElement('div'); box.className = 'toasts'; document.body.appendChild(box); }
    const t = document.createElement('div');
    t.className = 'toast ' + kind;
    t.textContent = msg;
    box.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; setTimeout(() => t.remove(), 320); }, ms);
  }

  // ---------- modal ----------
  function modal(title, bodyHTML, opts = {}) {
    const scrim = document.createElement('div');
    scrim.className = 'modal-scrim';
    scrim.innerHTML = `<div class="modal" style="${opts.wide ? 'width:min(860px,100%)' : ''}" role="dialog" aria-modal="true">
      <div class="modal-head"><h3>${esc(title)}</h3><button class="x" aria-label="Close">✕</button></div>
      <div class="modal-body">${bodyHTML}</div>
      <div class="modal-foot"></div></div>`;
    document.body.appendChild(scrim);
    requestAnimationFrame(() => scrim.classList.add('show'));
    const close = () => { scrim.classList.remove('show'); setTimeout(() => scrim.remove(), 200); };
    scrim.querySelector('.x').addEventListener('click', close);
    scrim.addEventListener('click', (e) => { if (e.target === scrim && !opts.locked) close(); });
    const foot = scrim.querySelector('.modal-foot');
    return { el: scrim, body: scrim.querySelector('.modal-body'), foot, close };
  }

  function confirmDlg(message, { danger = true, okText = 'Yes, continue' } = {}) {
    return new Promise((resolve) => {
      const m = modal('Please confirm', `<p style="font-weight:600;color:var(--muted)">${esc(message)}</p>`);
      m.foot.innerHTML = `<button class="btn btn-ghost" data-a="no">Cancel</button><button class="btn ${danger ? 'btn-danger' : 'btn-primary'}" data-a="yes">${esc(okText)}</button>`;
      m.foot.querySelector('[data-a=no]').addEventListener('click', () => { m.close(); resolve(false); });
      m.foot.querySelector('[data-a=yes]').addEventListener('click', () => { m.close(); resolve(true); });
    });
  }

  // ---------- formatting ----------
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function fmtDate(s) {
    if (!s) return '—';
    const d = new Date(String(s).length === 10 ? s + 'T00:00:00' : s);
    return isNaN(d) ? '—' : `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
  }
  function fmtDateTime(sec) {
    if (!sec) return '—';
    const d = new Date(sec * 1000);
    return `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}, ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  }
  const money = (n) => '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
  const initials = (name) => String(name || '?').trim().split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() || '').join('') || '?';
  const today = () => new Date().toISOString().slice(0, 10);
  const epochToLocal = (sec) => { if (!sec) return ''; const d = new Date(sec * 1000); const p = (n) => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`; };

  // ---------- image compression (client-side, keeps D1 rows small) ----------
  function compressImage(file, { maxDim = 1400, quality = 0.82, keepPng = false } = {}) {
    return new Promise((resolve, reject) => {
      if (!file || !/^image\/(jpeg|png|webp)$/.test(file.type)) return reject(new Error('Please choose a JPG, PNG or WebP image.'));
      if (file.size > 12 * 1024 * 1024) return reject(new Error('Image is too large (max 12 MB).'));
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        URL.revokeObjectURL(url);
        const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale)), h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#ffffff';
        if (!keepPng) ctx.fillRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
        let out = keepPng && file.type === 'image/png' ? canvas.toDataURL('image/png') : canvas.toDataURL('image/jpeg', quality);
        // step down quality until under ~850KB
        let q = quality;
        while (out.length > 850_000 * 1.37 && q > 0.4 && !keepPng) { q -= 0.12; out = canvas.toDataURL('image/jpeg', q); }
        if (out.length > 900_000 * 1.37) return reject(new Error('Could not compress this image enough. Try a smaller photo.'));
        resolve(out);
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Could not read that image.')); };
      img.src = url;
    });
  }

  // ---------- icons ----------
  const IC = {
    dashboard: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
    students: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    teacher: '<path d="M22 10 12 5 2 10l10 5 10-5z"/><path d="M6 12v5c0 1.7 2.7 3 6 3s6-1.3 6-3v-5"/>',
    classes: '<path d="M3 21h18M5 21V7l7-4 7 4v14"/><path d="M9 21v-6h6v6"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V2H6.5A2.5 2.5 0 0 0 4 4.5v15z"/><path d="M4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5"/>',
    money: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/><path d="M6 12h.01M18 12h.01"/>',
    chart: '<path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 5-7"/>',
    camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
    bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3.5 12h17M12 3.5c2.6 2.3 3.9 5.2 3.9 8.5s-1.3 6.2-3.9 8.5c-2.6-2.3-3.9-5.2-3.9-8.5s1.3-6.2 3.9-8.5z"/>',
    mail: '<rect x="2" y="4" width="20" height="16" rx="3"/><path d="m3 6 9 7 9-7"/>',
    robot: '<rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 8V4M8 4h8"/><circle cx="9" cy="14" r="1"/><circle cx="15" cy="14" r="1"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
    heart: '<path d="M12 21s-7.5-4.6-9.3-9A5.4 5.4 0 0 1 12 6.3 5.4 5.4 0 0 1 21.3 12c-1.8 4.4-9.3 9-9.3 9z"/>',
    home: '<path d="M3 9.5 12 3l9 6.5V21a1 1 0 0 1-1 1h-5v-7h-6v7H4a1 1 0 0 1-1-1z"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4z"/>',
    trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>',
    eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
    up: '<path d="M12 19V5M5 12l7-7 7 7"/>',
    down: '<path d="M12 5v14M19 12l-7 7-7-7"/>',
    key: '<path d="M21 2l-2 2m-7.6 7.6a5.5 5.5 0 1 1-7.8 7.8 5.5 5.5 0 0 1 7.8-7.8zm0 0L15.5 7.5m0 0 3 3L22 7l-3-3m-3.5 3.5L19 4"/>',
    user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3-8.7A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.8a2 2 0 0 1-.5 2.1L8 10a16 16 0 0 0 6 6l1.4-1.3a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
    star: '<path d="M12 2.5l2.9 5.9 6.6 1-4.7 4.6 1.1 6.5L12 17.4 6.1 20.5l1.1-6.5L2.5 9.4l6.6-1z"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/>',
  };
  const icon = (name, size = 18, color = 'currentColor') => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${IC[name] || IC.star}</svg>`;

  // ---------- app shell ----------
  function shell({ groups, onNav, user, roleLabel, portalName }) {
    const side = document.getElementById('side');
    const nav = groups.map((g) => `
      ${g.label ? `<div class="side-group">${esc(g.label)}</div>` : ''}
      ${g.items.map((it) => `<button class="side-link" data-nav="${esc(it.id)}">${icon(it.icon)}<span>${esc(it.label)}</span>${it.badge ? `<span class="count" data-badge="${esc(it.id)}" hidden></span>` : ''}</button>`).join('')}`).join('');
    side.innerHTML = `
      <div class="side-brand"><span class="ring"><img src="/assets/img/logo-96.png" alt="logo" id="side-logo"></span><span><b>Nanhe Kadam</b><small>${esc(portalName)}</small></span></div>
      <nav class="side-nav">${nav}</nav>
      <div class="side-user">
        <span class="av">${esc(initials(user.name))}</span>
        <span style="min-width:0"><b>${esc(user.name)}</b><small>${esc(roleLabel)}</small></span>
        <button id="logout-btn" title="Sign out" aria-label="Sign out">${icon('logout', 17)}</button>
      </div>`;
    const scrim = document.createElement('div');
    scrim.className = 'scrim';
    document.body.appendChild(scrim);
    const closeSide = () => { side.classList.remove('open'); scrim.classList.remove('show'); };
    scrim.addEventListener('click', closeSide);
    document.getElementById('menu-btn')?.addEventListener('click', () => { side.classList.add('open'); scrim.classList.add('show'); });
    side.querySelectorAll('[data-nav]').forEach((b) => b.addEventListener('click', () => { closeSide(); onNav(b.dataset.nav); }));
    document.getElementById('logout-btn').addEventListener('click', async () => {
      try { await api('/api/auth/logout', { method: 'POST' }); } catch {}
      location.reload();
    });
    return {
      setActive(id, title, sub) {
        side.querySelectorAll('[data-nav]').forEach((b) => b.classList.toggle('active', b.dataset.nav === id));
        document.getElementById('page-title').textContent = title || '';
        document.getElementById('page-sub').textContent = sub || '';
      },
      setBadge(id, n) {
        const el = side.querySelector(`[data-badge="${id}"]`);
        if (el) { el.hidden = !n; el.textContent = n; }
      },
    };
  }

  // ---------- login binder ----------
  function bindLogin({ formId, endpoint, payload, onSuccess, errorId }) {
    const form = document.getElementById(formId);
    const errBox = document.getElementById(errorId || 'login-error');
    form.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      errBox.classList.remove('show');
      const btn = form.querySelector('button[type=submit]');
      btn.disabled = true;
      try {
        const body = payload();
        if (window.turnstile && window.__tsWidget !== undefined && window.__tsWidget !== null) body.turnstile = window.turnstile.getResponse(window.__tsWidget);
        const r = await api(endpoint, { method: 'POST', body });
        onSuccess(r);
      } catch (e) {
        errBox.textContent = e.message;
        errBox.classList.add('show');
        if (window.turnstile && window.__tsWidget !== null && window.__tsWidget !== undefined) window.turnstile.reset(window.__tsWidget);
        btn.disabled = false;
      }
    });
  }

  async function maybeTurnstile(siteKeyPromise) {
    try {
      const { settings } = await api('/api/public/content');
      const key = settings?.turnstile_site_key;
      if (!key) return;
      await new Promise((res, rej) => {
        const sc = document.createElement('script');
        sc.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
        sc.onload = res; sc.onerror = rej;
        document.head.appendChild(sc);
      });
      document.querySelectorAll('.turnstile-box').forEach((box) => {
        window.__tsWidget = window.turnstile.render(box, { sitekey: key, theme: 'light', size: 'flexible' });
      });
    } catch {}
  }

  function setLogo(logoId) { if (logoId) document.querySelectorAll('#side-logo, .login-logo img').forEach((i) => { i.src = '/img/' + encodeURIComponent(logoId); }); }

  return { api, esc, toast, modal, confirmDlg, fmtDate, fmtDateTime, money, initials, today, epochToLocal, compressImage, icon, shell, bindLogin, maybeTurnstile, setLogo, MONTHS };
})();
