// Public website: live content, animations, inquiry form, optional AI assistant.
(function () {
  'use strict';
  const $ = (s, el) => (el || document).querySelector(s);
  const $$ = (s, el) => [...(el || document).querySelectorAll(s)];
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const api = async (path, opts = {}) => {
    const res = await fetch(path, { ...opts, headers: { 'Content-Type': 'application/json', 'X-NKPS-Client': 'fetch', ...(opts.headers || {}) }, credentials: 'same-origin' });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || 'Something went wrong.');
    return data;
  };

  // Respect reduced motion + weaker devices
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (reduced || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 3)) document.body.classList.add('low-motion');

  // Loader
  const loader = $('#loader');
  const hideLoader = () => { loader.classList.add('done'); setTimeout(() => loader.remove(), 600); };
  window.addEventListener('load', () => setTimeout(hideLoader, reduced ? 0 : 350));
  setTimeout(hideLoader, 2600); // never block the page

  // Mobile nav
  const nav = $('#nav'), burger = $('#burger');
  burger.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    burger.setAttribute('aria-expanded', String(open));
  });
  $$('#nav-links a').forEach((a) => a.addEventListener('click', () => { nav.classList.remove('open'); burger.setAttribute('aria-expanded', 'false'); }));

  // Scroll reveals
  const io = new IntersectionObserver((entries) => {
    for (const e of entries) if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }, { threshold: 0.12, rootMargin: '0px 0px -30px 0px' });
  const watch = () => $$('.reveal:not(.in), .reveal-l:not(.in), .reveal-r:not(.in)').forEach((el) => io.observe(el));
  watch();

  $('#year').textContent = new Date().getFullYear();

  // ---------- icons ----------
  const ICONS = {
    book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V2H6.5A2.5 2.5 0 0 0 4 4.5v15z"/><path d="M4 19.5A2.5 2.5 0 0 0 6.5 22H20v-5"/>',
    palette: '<circle cx="13.5" cy="6.5" r=".8"/><circle cx="17.5" cy="10.5" r=".8"/><circle cx="8.5" cy="7.5" r=".8"/><circle cx="6.5" cy="12.5" r=".8"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.6-.7 1.6-1.7 0-.4-.2-.8-.4-1.1-.3-.3-.4-.7-.4-1.1a1.6 1.6 0 0 1 1.6-1.6h2c3 0 5.6-2.5 5.6-5.6C22 6 17.5 2 12 2z"/>',
    music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    blocks: '<rect x="3" y="13" width="8" height="8" rx="1.5"/><rect x="13" y="13" width="8" height="8" rx="1.5"/><rect x="8" y="3" width="8" height="8" rx="1.5"/>',
    ball: '<circle cx="12" cy="12" r="9.5"/><path d="M12 2.5c3 2.5 4.5 5.7 4.5 9.5s-1.5 7-4.5 9.5c-3-2.5-4.5-5.7-4.5-9.5s1.5-7 4.5-9.5zM2.5 12h19"/>',
    star: '<path d="M12 2.5l2.9 5.9 6.6 1-4.7 4.6 1.1 6.5L12 17.4 6.1 20.5l1.1-6.5L2.5 9.4l6.6-1z"/>',
    heart: '<path d="M12 21s-7.5-4.6-9.3-9A5.4 5.4 0 0 1 12 6.3 5.4 5.4 0 0 1 21.3 12c-1.8 4.4-9.3 9-9.3 9z"/>',
    sun: '<circle cx="12" cy="12" r="4.5"/><path d="M12 1.5v3M12 19.5v3M1.5 12h3M19.5 12h3M4.6 4.6l2.1 2.1M17.3 17.3l2.1 2.1M4.6 19.4l2.1-2.1M17.3 6.7l2.1-2.1"/>',
    camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
  };
  const icon = (name, color, size = 26) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[name] || ICONS.star}</svg>`;
  const ACT_COLORS = [
    ['var(--sun)', 'var(--sun-soft)', '#c98f00'], ['var(--tang)', 'var(--tang-soft)', '#cf6f10'],
    ['var(--navy)', 'var(--sky)', '#1e3a6e'], ['var(--leaf)', 'var(--leaf-soft)', '#2e7a3d'],
    ['var(--tang)', 'var(--tang-soft)', '#cf6f10'], ['var(--sun)', 'var(--sun-soft)', '#c98f00'],
  ];

  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const fmtDate = (s) => { if (!s) return ''; const d = new Date(s + (String(s).length === 10 ? 'T00:00:00' : '')); return isNaN(d) ? '' : `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`; };
  const initials = (name) => String(name || '').replace(/^(Mr|Mrs|Ms|Dr)\.?\s+/i, '').split(/\s+/).filter((w) => /^[A-Za-z]/.test(w)).slice(0, 2).map((w) => w[0].toUpperCase()).join('') || '★';
  const telHref = (p) => 'tel:' + String(p || '').replace(/[^+0-9]/g, '');

  let CONTENT = null;
  let turnstileWidget = null;

  function render(data) {
    CONTENT = data;
    const s = data.settings || {};
    const name = s.school_name || 'Nanhe Kadam Public School';
    document.title = `${name} — ${s.slogan || 'Little Steps. Big Dreams.'}`;
    $('#hero-name').textContent = name;
    $('#brand-name').textContent = name.replace(/\s*Public School\s*$/i, '') || name;
    $('#foot-name').innerHTML = esc(name).replace(/ (Public School)$/i, '<br>$1');
    $('#foot-name2').textContent = name;
    $('#hero-slogan').textContent = s.slogan || '';
    $('#hero-slogan-hi').textContent = s.slogan_hi || '';
    $('#hero-sub').textContent = s.hero_subtitle || '';
    $('#about-text').innerHTML = String(s.about || '').split(/\n+/).filter(Boolean).map((p) => `<p>${esc(p)}</p>`).join('');
    $('#director-msg').textContent = s.director_message || '';
    $('#director-name').textContent = s.director_name || '';
    $('#director-role').textContent = s.director_role || '';
    $('#director-mono').textContent = initials(s.director_name);
    $('#principal-msg').textContent = s.principal_message || '';
    $('#principal-name').textContent = s.principal_name || '';
    $('#principal-role').textContent = s.principal_role || '';
    $('#principal-mono').textContent = initials(s.principal_name);
    $('#foot-note').textContent = s.footer_note || '';

    // contact
    const phone = s.contact_phone || '';
    for (const idn of ['tb-phone', 'cc-phone', 'foot-phone']) {
      const el = $('#' + idn);
      el.setAttribute('href', telHref(phone));
      const span = el.querySelector('span');
      if (span) span.textContent = phone; else el.textContent = phone;
    }
    $('#tb-addr').textContent = s.address || '';
    $('#cc-addr').textContent = s.address || '';
    $('#foot-addr').textContent = s.address || '';
    $('#map-addr').textContent = s.address || '';
    if (s.contact_email) {
      $('#cc-email-row').hidden = false;
      const em = $('#cc-email'); em.textContent = s.contact_email; em.href = 'mailto:' + s.contact_email;
    } else $('#cc-email-row').hidden = true;

    // map: verified embed > owner link > address search
    const panel = $('#map-panel');
    if (s.maps_embed && /^https:\/\/www\.google\.com\/maps\/embed/.test(s.maps_embed)) {
      panel.innerHTML = `<iframe src="${esc(s.maps_embed)}" loading="lazy" title="School location on Google Maps" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>`;
    } else {
      const link = $('#map-link');
      if (link) link.href = (s.maps_url && /^https:\/\//.test(s.maps_url)) ? s.maps_url : 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(s.address || name);
    }

    // logo override (owner can replace from admin without redeploy)
    if (s.logo_image_id) for (const idn of ['nav-logo', 'foot-logo', 'loader-logo']) { const el = $('#' + idn); if (el) el.src = '/img/' + encodeURIComponent(s.logo_image_id); }

    // announcement (disabled by default — owner enables explicitly)
    const an = $('#announce');
    if (s.announcement_enabled && s.announcement_text) { an.textContent = s.announcement_text; an.hidden = false; } else an.hidden = true;

    // philosophy
    const pillars = Array.isArray(s.philosophy) ? s.philosophy : [];
    $('#pillars').innerHTML = pillars.map((p, i) => `
      <div class="pillar reveal" style="--d:${(i * 0.08).toFixed(2)}s">
        <div class="num">${String(i + 1).padStart(2, '0')}</div>
        <h3>${esc(p.title)}</h3><p>${esc(p.text)}</p>
      </div>`).join('');

    // activities
    const acts = Array.isArray(s.activities) ? s.activities : [];
    $('#act-grid').innerHTML = acts.map((a, i) => {
      const c = ACT_COLORS[i % ACT_COLORS.length];
      return `<div class="act-card reveal" style="--ac:${c[0]};--acbg:${c[1]};--d:${(i * 0.07).toFixed(2)}s">
        <span class="ic">${icon(a.icon, c[2], 28)}</span><h3>${esc(a.title)}</h3><p>${esc(a.text)}</p></div>`;
    }).join('');

    // facilities
    const facs = Array.isArray(s.facilities) ? s.facilities : [];
    $('#fac-row').innerHTML = facs.map((f) => `<div class="fac"><span class="tick"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg></span>${esc(f)}</div>`).join('');

    renderGallery(data.gallery || []);
    renderNotices(data.notices || []);

    // AI assistant
    $('#chat-fab').hidden = !s.ai_enabled;
    if (!s.ai_enabled) $('#chat-panel').classList.remove('open');

    // Turnstile (only when owner configured it)
    if (s.turnstile_site_key && !turnstileWidget) loadTurnstile(s.turnstile_site_key);
    watch();
  }

  function renderGallery(items) {
    const grid = $('#gal-grid');
    if (!items.length) {
      grid.innerHTML = `<div class="gal-empty">
        <span class="ic">${icon('camera', '#c98f00', 30)}</span>
        <b>Photos are on their way!</b>
        Moments from our school will appear here as the office adds them.</div>`;
      return;
    }
    grid.innerHTML = items.slice(0, 4).map((g, i) => `
      <article class="gal-card reveal" style="--d:${(i * 0.08).toFixed(2)}s">
        <div class="ph"><img src="/img/${esc(g.image_id)}" alt="${esc(g.title)}" loading="lazy" width="640" height="480"></div>
        <div class="gal-body">
          <span class="gal-date">${esc(fmtDate(g.photo_date))}</span>
          <h3>${esc(g.title)}</h3>
          ${g.caption ? `<p>${esc(g.caption)}</p>` : ''}
        </div>
      </article>`).join('');
  }

  function renderNotices(items) {
    const list = $('#notice-list');
    if (!items.length) { list.innerHTML = '<div class="notice-empty">No notices right now. Please check back soon.</div>'; return; }
    list.innerHTML = items.map((n, i) => {
      const d = n.publish_at ? new Date(n.publish_at * 1000) : new Date();
      return `<article class="notice reveal" style="--d:${(i * 0.05).toFixed(2)}s">
        <div class="notice-date"><b>${d.getDate()}</b><small>${MONTHS[d.getMonth()]}</small></div>
        <div class="notice-body">
          <h3>${esc(n.title)} ${n.pinned ? '<span class="pin-badge">Important</span>' : ''}</h3>
          <p>${esc(n.body)}</p>
        </div>
      </article>`;
    }).join('');
  }

  async function loadContent() {
    try { render(await api('/api/public/content')); }
    catch (e) { console.warn('Content fetch failed:', e.message); }
  }
  loadContent();
  // Refresh live content when the tab regains focus (admin changes appear without redeploy)
  document.addEventListener('visibilitychange', () => { if (!document.hidden) loadContent(); });

  // ---------- inquiry ----------
  const form = $('#inquiry-form');
  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const msg = $('#inquiry-msg');
    msg.className = 'form-msg';
    const btn = $('#inquiry-btn');
    const payload = {
      parent_name: $('#f-name').value.trim(),
      phone: $('#f-phone').value.trim(),
      child_age: $('#f-age').value,
      message: $('#f-msg').value.trim(),
    };
    if (payload.parent_name.length < 2) return showMsg('Please enter the parent\'s name.', false);
    if (!/^\+?[0-9 ()-]{8,18}$/.test(payload.phone)) return showMsg('Please enter a valid contact number.', false);
    if (window.turnstile && turnstileWidget !== null) payload.turnstile = window.turnstile.getResponse(turnstileWidget);
    btn.disabled = true; btn.style.opacity = '.7';
    try {
      const r = await api('/api/public/inquiry', { method: 'POST', body: JSON.stringify(payload) });
      showMsg(r.message || 'Thank you! We will contact you soon.', true);
      form.reset();
    } catch (e) { showMsg(e.message, false); }
    finally { btn.disabled = false; btn.style.opacity = '1'; if (window.turnstile && turnstileWidget !== null) window.turnstile.reset(turnstileWidget); }
    function showMsg(t, ok) { msg.textContent = t; msg.className = 'form-msg ' + (ok ? 'ok' : 'bad'); }
  });

  // ---------- Turnstile ----------
  function loadTurnstile(siteKey) {
    const sc = document.createElement('script');
    sc.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
    sc.onload = () => {
      turnstileWidget = window.turnstile.render('#turnstile-box', { sitekey: siteKey, theme: 'light', size: 'flexible' });
      turnstileSiteKey = siteKey;
    };
    document.head.appendChild(sc);
  }
  let turnstileSiteKey = null;

  // ---------- AI chat ----------
  const fab = $('#chat-fab'), panel = $('#chat-panel'), body = $('#chat-body');
  const history = [];
  let greeted = false, busy = false;
  fab.addEventListener('click', () => {
    panel.classList.toggle('open');
    if (panel.classList.contains('open')) {
      if (!greeted) { addMsg('bot', `Namaste! 🙏 I can answer questions about ${CONTENT?.settings?.school_name || 'our school'} — admissions, our teachers, activities and more. How can I help?`); greeted = true; }
      $('#chat-text').focus();
    }
  });
  $('#chat-close').addEventListener('click', () => panel.classList.remove('open'));
  function addMsg(role, text) {
    const div = document.createElement('div');
    div.className = 'chat-msg ' + role;
    div.textContent = text;
    body.appendChild(div);
    body.scrollTop = body.scrollHeight;
    return div;
  }
  $('#chat-form').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const input = $('#chat-text');
    const text = input.value.trim();
    if (!text || busy) return;
    input.value = '';
    addMsg('user', text);
    busy = true;
    const typing = addMsg('bot typing', 'Thinking…');
    try {
      const r = await api('/api/public/assistant', { method: 'POST', body: JSON.stringify({ message: text, history: history.slice(-6) }) });
      typing.remove();
      addMsg('bot', r.reply);
      history.push({ role: 'user', text }, { role: 'assistant', text: r.reply });
      while (history.length > 6) history.shift();
    } catch (e) {
      typing.remove();
      addMsg('bot', e.message || 'The school assistant is temporarily unavailable. Please try again in a little while.');
    } finally { busy = false; }
  });
})();
